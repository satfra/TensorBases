(* Created with the Wolfram Language : www.wolfram.com *)
{(I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
   TBsp[Global`p3, Global`p3]*
   (TBdeltaLorentz[Global`mui$11937, Global`nui$11940]*
     (-TBvec[Global`p1, Global`rhoi$11943] + TBvec[Global`p2, 
       Global`rhoi$11943]) + TBdeltaLorentz[Global`nui$11940, 
      Global`rhoi$11943]*(-TBvec[Global`p2, Global`mui$11937] + 
      TBvec[Global`p3, Global`mui$11937]) + 
    TBdeltaLorentz[Global`mui$11937, Global`rhoi$11943]*
     (TBvec[Global`p1, Global`nui$11940] - TBvec[Global`p3, 
       Global`nui$11940]))*Global`transProj[Global`p1, Global`mu, 
    Global`mui$11937]*Global`transProj[Global`p2, Global`nu, 
    Global`nui$11940]*Global`transProj[Global`p3, Global`rho, 
    Global`rhoi$11943])/(Global`Nc*(-1 + Global`Nc^2)*
   (2*TBsp[Global`p1, Global`p2]*TBsp[Global`p1, Global`p3]*
     TBsp[Global`p2, Global`p2]*TBsp[Global`p2, Global`p3] - 
    4*TBsp[Global`p1, Global`p1]^2*TBsp[Global`p2, Global`p2]*
     TBsp[Global`p3, Global`p3] + 
    ((TBsp[Global`p1, Global`p2]^2 - 6*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p1, Global`p3] + TBsp[Global`p1, Global`p3]^2)*
       TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p1, Global`p2]*
       TBsp[Global`p1, Global`p3]*TBsp[Global`p2, Global`p3])*
     TBsp[Global`p3, Global`p3] + TBsp[Global`p1, Global`p1]*
     (TBsp[Global`p1, Global`p3]^2*TBsp[Global`p2, Global`p2] - 
      4*TBsp[Global`p2, Global`p2]^2*TBsp[Global`p3, Global`p3] + 
      (TBsp[Global`p1, Global`p2]^2 - 6*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p2, Global`p3] + TBsp[Global`p2, Global`p3]^2)*
       TBsp[Global`p3, Global`p3] + TBsp[Global`p2, Global`p2]*
       (TBsp[Global`p2, Global`p3]^2 + 6*(TBsp[Global`p1, Global`p2] + 
          TBsp[Global`p2, Global`p3])*TBsp[Global`p3, Global`p3] - 
        4*TBsp[Global`p3, Global`p3]^2) + 2*TBsp[Global`p1, Global`p3]*
       (TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p3] + 
        3*TBsp[Global`p2, Global`p2]*(-TBsp[Global`p2, Global`p3] + 
          TBsp[Global`p3, Global`p3])))))}
