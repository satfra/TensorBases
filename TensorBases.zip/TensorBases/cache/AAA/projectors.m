(* Created with the Wolfram Language : www.wolfram.com *)
{((I/32)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (4*(TBsp[Global`p1, Global`p1] + TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(-TBsp[Global`p1, Global`p2]^2 + 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (TBsp[Global`p1, Global`p1]^3*TBsp[Global`p2, Global`p2] + 
      2*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]^2*TBsp[Global`p1, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + 5*TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(4*TBsp[Global`p1, Global`p2]^3 + 
        12*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2] + 
        5*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2]^2 + 
        TBsp[Global`p2, Global`p2]^3))*
     (TBdeltaLorentz[Global`nui$2372, Global`rhoi$2375]*
       (TBvec[Global`p1, Global`mui$2369] + 
        2*TBvec[Global`p2, Global`mui$2369]) - 
      TBdeltaLorentz[Global`mui$2369, Global`rhoi$2375]*
       (2*TBvec[Global`p1, Global`nui$2372] + TBvec[Global`p2, 
         Global`nui$2372]) + TBdeltaLorentz[Global`mui$2369, Global`nui$2372]*
       (TBvec[Global`p1, Global`rhoi$2375] - TBvec[Global`p2, 
         Global`rhoi$2375]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$2369]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$2375]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2372] - (TBsp[Global`p1, Global`p1]^2 + 
      4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
       (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
      2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
      TBsp[Global`p2, Global`p2]^2)*(TBsp[Global`p1, Global`p1]^3*
       TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p1, Global`p2]^2*
       TBsp[Global`p2, Global`p2]*(2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]^2*
       TBsp[Global`p1, Global`p2]*(2*TBsp[Global`p1, Global`p2] + 
        5*TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]*
       (4*TBsp[Global`p1, Global`p2]^3 + 12*TBsp[Global`p1, Global`p2]^2*
         TBsp[Global`p2, Global`p2] + 5*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p2, Global`p2]^2 + TBsp[Global`p2, Global`p2]^3))*
     (TBvec[Global`p1, Global`mui$2389] + 
      2*TBvec[Global`p2, Global`mui$2389])*
     (2*TBvec[Global`p1, Global`nui$2392] + TBvec[Global`p2, 
       Global`nui$2392])*(TBvec[Global`p1, Global`rhoi$2395] - 
      TBvec[Global`p2, Global`rhoi$2395])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$2389]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$2395]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2392] + 6*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (TBsp[Global`p1, Global`p1]^3*TBsp[Global`p2, Global`p2] + 
      2*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]^2*TBsp[Global`p1, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + 5*TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(4*TBsp[Global`p1, Global`p2]^3 + 
        12*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2] + 
        5*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2]^2 + 
        TBsp[Global`p2, Global`p2]^3))*
     (TBdeltaLorentz[Global`nui$2412, Global`rhoi$2415]*
       TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$2409] + 
        2*TBvec[Global`p2, Global`mui$2409]) - 
      TBdeltaLorentz[Global`mui$2409, Global`rhoi$2415]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$2412] + 
        TBvec[Global`p2, Global`nui$2412]) + 
      TBdeltaLorentz[Global`mui$2409, Global`nui$2412]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(TBvec[Global`p1, Global`rhoi$2415] - 
        TBvec[Global`p2, Global`rhoi$2415]))*Global`transProj[Global`p1, 
      Global`mu, Global`mui$2409]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$2415]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2412] + 2*(TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2])*(TBsp[Global`p1, Global`p1] - 
      TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p1] + 
      TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
     (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
     (-TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*
     (TBdeltaLorentz[Global`nui$2432, Global`rhoi$2435]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
       (TBvec[Global`p1, Global`mui$2429] + 
        2*TBvec[Global`p2, Global`mui$2429]) + 
      TBdeltaLorentz[Global`mui$2429, Global`rhoi$2435]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
       (2*TBvec[Global`p1, Global`nui$2432] + TBvec[Global`p2, 
         Global`nui$2432]) - TBdeltaLorentz[Global`mui$2429, Global`nui$2432]*
       (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
       (TBvec[Global`p1, Global`rhoi$2435] - TBvec[Global`p2, 
         Global`rhoi$2435]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$2429]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$2435]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2432]))/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2*(TBsp[Global`p1, Global`p1]^2 + 
     4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
     2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
     TBsp[Global`p2, Global`p2]^2)^2), 
 ((I/128)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (-4*(1 - Global`Nc^2)*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (TBsp[Global`p1, Global`p1]^3*TBsp[Global`p2, Global`p2] + 
      2*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]^2*TBsp[Global`p1, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + 5*TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(4*TBsp[Global`p1, Global`p2]^3 + 
        12*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2] + 
        5*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2]^2 + 
        TBsp[Global`p2, Global`p2]^3))*
     (-(TBdeltaLorentz[Global`nui$1926, Global`rhoi$1929]*
        (TBvec[Global`p1, Global`mui$1923] + 
         2*TBvec[Global`p2, Global`mui$1923])) + 
      TBdeltaLorentz[Global`mui$1923, Global`rhoi$1929]*
       (2*TBvec[Global`p1, Global`nui$1926] + TBvec[Global`p2, 
         Global`nui$1926]) + TBdeltaLorentz[Global`mui$1923, Global`nui$1926]*
       (-TBvec[Global`p1, Global`rhoi$1929] + TBvec[Global`p2, 
         Global`rhoi$1929]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$1923]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$1929]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$1926] + (1 - Global`Nc)*(1 + Global`Nc)*
     (TBsp[Global`p1, Global`p1]^2 + 4*TBsp[Global`p1, Global`p2]^2 + 
      TBsp[Global`p1, Global`p1]*(2*TBsp[Global`p1, Global`p2] - 
        TBsp[Global`p2, Global`p2]) + 2*TBsp[Global`p1, Global`p2]*
       TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p2]^2)*
     (3*TBsp[Global`p1, Global`p1]^2*TBsp[Global`p2, Global`p2] + 
      2*TBsp[Global`p1, Global`p2]^2*(TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]*
       (2*TBsp[Global`p1, Global`p2]^2 + 8*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p2, Global`p2] + 3*TBsp[Global`p2, Global`p2]^2))*
     (TBvec[Global`p1, Global`mui$1943] + 
      2*TBvec[Global`p2, Global`mui$1943])*
     (2*TBvec[Global`p1, Global`nui$1946] + TBvec[Global`p2, 
       Global`nui$1946])*(TBvec[Global`p1, Global`rhoi$1949] - 
      TBvec[Global`p2, Global`rhoi$1949])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$1943]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$1949]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$1946] + 2*(1 - Global`Nc)*(1 + Global`Nc)*
     (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p1]^2*
       TBsp[Global`p2, Global`p2] + 8*TBsp[Global`p1, Global`p2]^2*
       (TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(8*TBsp[Global`p1, Global`p2]^2 + 
        10*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
        TBsp[Global`p2, Global`p2]^2))*
     (-(TBdeltaLorentz[Global`nui$1966, Global`rhoi$1969]*
        TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$1963] + 
         2*TBvec[Global`p2, Global`mui$1963])) + 
      TBdeltaLorentz[Global`mui$1963, Global`rhoi$1969]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$1966] + 
        TBvec[Global`p2, Global`nui$1966]) + 
      TBdeltaLorentz[Global`mui$1963, Global`nui$1966]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(-TBvec[Global`p1, Global`rhoi$1969] + 
        TBvec[Global`p2, Global`rhoi$1969]))*Global`transProj[Global`p1, 
      Global`mu, Global`mui$1963]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$1969]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$1966] - 2*(1 - Global`Nc)*(1 + Global`Nc)*
     (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
     (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
     (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
     (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*
     (-(TBdeltaLorentz[Global`nui$1986, Global`rhoi$1989]*
        (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
        (TBvec[Global`p1, Global`mui$1983] + 
         2*TBvec[Global`p2, Global`mui$1983])) - 
      TBdeltaLorentz[Global`mui$1983, Global`rhoi$1989]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
       (2*TBvec[Global`p1, Global`nui$1986] + TBvec[Global`p2, 
         Global`nui$1986]) + TBdeltaLorentz[Global`mui$1983, Global`nui$1986]*
       (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
       (TBvec[Global`p1, Global`rhoi$1989] - TBvec[Global`p2, 
         Global`rhoi$1989]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$1983]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$1989]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$1986]))/((-1 + Global`Nc)*Global`Nc*(1 + Global`Nc)*
   (-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p2]^2 - 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])^3*
   (TBsp[Global`p1, Global`p1]^2 + 4*TBsp[Global`p1, Global`p2]^2 + 
    TBsp[Global`p1, Global`p1]*(2*TBsp[Global`p1, Global`p2] - 
      TBsp[Global`p2, Global`p2]) + 2*TBsp[Global`p1, Global`p2]*
     TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p2]^2)), 
 ((-1/64*I)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (-12*(TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p1]^3*
       TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p1, Global`p2]^2*
       TBsp[Global`p2, Global`p2]*(2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]^2*
       TBsp[Global`p1, Global`p2]*(2*TBsp[Global`p1, Global`p2] + 
        5*TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]*
       (4*TBsp[Global`p1, Global`p2]^3 + 12*TBsp[Global`p1, Global`p2]^2*
         TBsp[Global`p2, Global`p2] + 5*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p2, Global`p2]^2 + TBsp[Global`p2, Global`p2]^3))*
     (TBdeltaLorentz[Global`nui$2393, Global`rhoi$2396]*
       (TBvec[Global`p1, Global`mui$2390] + 
        2*TBvec[Global`p2, Global`mui$2390]) - 
      TBdeltaLorentz[Global`mui$2390, Global`rhoi$2396]*
       (2*TBvec[Global`p1, Global`nui$2393] + TBvec[Global`p2, 
         Global`nui$2393]) + TBdeltaLorentz[Global`mui$2390, Global`nui$2393]*
       (TBvec[Global`p1, Global`rhoi$2396] - TBvec[Global`p2, 
         Global`rhoi$2396]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$2390]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$2396]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2393] - (TBsp[Global`p1, Global`p1]^2 + 
      4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
       (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
      2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
      TBsp[Global`p2, Global`p2]^2)*(TBsp[Global`p1, Global`p1]^2*
       TBsp[Global`p2, Global`p2] + 8*TBsp[Global`p1, Global`p2]^2*
       (TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(8*TBsp[Global`p1, Global`p2]^2 + 
        10*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
        TBsp[Global`p2, Global`p2]^2))*(TBvec[Global`p1, Global`mui$2410] + 
      2*TBvec[Global`p2, Global`mui$2410])*
     (2*TBvec[Global`p1, Global`nui$2413] + TBvec[Global`p2, 
       Global`nui$2413])*(TBvec[Global`p1, Global`rhoi$2416] - 
      TBvec[Global`p2, Global`rhoi$2416])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$2410]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$2416]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2413] + 2*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (2*TBsp[Global`p1, Global`p1]^3 + 3*TBsp[Global`p1, Global`p1]^2*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      3*TBsp[Global`p1, Global`p1]*(12*TBsp[Global`p1, Global`p2]^2 + 
        12*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
        TBsp[Global`p2, Global`p2]^2) + 2*(16*TBsp[Global`p1, Global`p2]^3 + 
        18*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2] + 
        3*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2]^2 + 
        TBsp[Global`p2, Global`p2]^3))*
     (TBdeltaLorentz[Global`nui$2433, Global`rhoi$2436]*
       TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$2430] + 
        2*TBvec[Global`p2, Global`mui$2430]) - 
      TBdeltaLorentz[Global`mui$2430, Global`rhoi$2436]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$2433] + 
        TBvec[Global`p2, Global`nui$2433]) + 
      TBdeltaLorentz[Global`mui$2430, Global`nui$2433]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(TBvec[Global`p1, Global`rhoi$2436] - 
        TBvec[Global`p2, Global`rhoi$2436]))*Global`transProj[Global`p1, 
      Global`mu, Global`mui$2430]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$2436]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2433] + 6*(TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2])*(TBsp[Global`p1, Global`p1] - 
      TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(-TBsp[Global`p1, Global`p2]^2 + 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (TBdeltaLorentz[Global`nui$2453, Global`rhoi$2456]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
       (TBvec[Global`p1, Global`mui$2450] + 
        2*TBvec[Global`p2, Global`mui$2450]) + 
      TBdeltaLorentz[Global`mui$2450, Global`rhoi$2456]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
       (2*TBvec[Global`p1, Global`nui$2453] + TBvec[Global`p2, 
         Global`nui$2453]) - TBdeltaLorentz[Global`mui$2450, Global`nui$2453]*
       (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
       (TBvec[Global`p1, Global`rhoi$2456] - TBvec[Global`p2, 
         Global`rhoi$2456]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$2450]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$2456]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2453]))/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2*(TBsp[Global`p1, Global`p1]^2 + 
     4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
     2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
     TBsp[Global`p2, Global`p2]^2)^2), 
 ((I/64)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (4*(TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
     (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
     (TBsp[Global`p1, Global`p1] + TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (-(TBdeltaLorentz[Global`nui$2302, Global`rhoi$2305]*
        (TBvec[Global`p1, Global`mui$2299] + 
         2*TBvec[Global`p2, Global`mui$2299])) + 
      TBdeltaLorentz[Global`mui$2299, Global`rhoi$2305]*
       (2*TBvec[Global`p1, Global`nui$2302] + TBvec[Global`p2, 
         Global`nui$2302]) + TBdeltaLorentz[Global`mui$2299, Global`nui$2302]*
       (-TBvec[Global`p1, Global`rhoi$2305] + TBvec[Global`p2, 
         Global`rhoi$2305]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$2299]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$2305]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2302] - (TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2])*(TBsp[Global`p1, Global`p1] - 
      TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p1]^2 + 
      4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
       (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
      2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
      TBsp[Global`p2, Global`p2]^2)*(TBvec[Global`p1, Global`mui$2319] + 
      2*TBvec[Global`p2, Global`mui$2319])*
     (2*TBvec[Global`p1, Global`nui$2322] + TBvec[Global`p2, 
       Global`nui$2322])*(TBvec[Global`p1, Global`rhoi$2325] - 
      TBvec[Global`p2, Global`rhoi$2325])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$2319]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$2325]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2322] - 6*(TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2])*(TBsp[Global`p1, Global`p1] - 
      TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (-(TBdeltaLorentz[Global`nui$2342, Global`rhoi$2345]*
        TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$2339] + 
         2*TBvec[Global`p2, Global`mui$2339])) + 
      TBdeltaLorentz[Global`mui$2339, Global`rhoi$2345]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$2342] + 
        TBvec[Global`p2, Global`nui$2342]) + 
      TBdeltaLorentz[Global`mui$2339, Global`nui$2342]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(-TBvec[Global`p1, Global`rhoi$2345] + 
        TBvec[Global`p2, Global`rhoi$2345]))*Global`transProj[Global`p1, 
      Global`mu, Global`mui$2339]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$2345]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2342] + 2*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (2*TBsp[Global`p1, Global`p1]^3 + TBsp[Global`p1, Global`p1]^2*
       (6*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(4*TBsp[Global`p1, Global`p2]^2 - 
        4*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] - 
        TBsp[Global`p2, Global`p2]^2) + 2*TBsp[Global`p2, Global`p2]*
       (2*TBsp[Global`p1, Global`p2]^2 + 3*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p2]^2))*
     (-(TBdeltaLorentz[Global`nui$2362, Global`rhoi$2365]*
        (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
        (TBvec[Global`p1, Global`mui$2359] + 
         2*TBvec[Global`p2, Global`mui$2359])) - 
      TBdeltaLorentz[Global`mui$2359, Global`rhoi$2365]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
       (2*TBvec[Global`p1, Global`nui$2362] + TBvec[Global`p2, 
         Global`nui$2362]) + TBdeltaLorentz[Global`mui$2359, Global`nui$2362]*
       (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
       (TBvec[Global`p1, Global`rhoi$2365] - TBvec[Global`p2, 
         Global`rhoi$2365]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$2359]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$2365]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2362]))/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2*(TBsp[Global`p1, Global`p1]^2 + 
     4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
     2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
     TBsp[Global`p2, Global`p2]^2)^2), 
 ((-1/8*I)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
    TBsp[Global`p2, Global`p2])*
   (4*Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi$4286]*
     (-(TBdeltaLorentz[Global`nui$4283, Global`rhoi$4286]*
        (TBvec[Global`p1, Global`mui$4280] + 
         2*TBvec[Global`p2, Global`mui$4280])) + 
      TBdeltaLorentz[Global`mui$4280, Global`rhoi$4286]*
       (2*TBvec[Global`p1, Global`nui$4283] + TBvec[Global`p2, 
         Global`nui$4283]) + TBdeltaLorentz[Global`mui$4280, Global`nui$4283]*
       (-TBvec[Global`p1, Global`rhoi$4286] + TBvec[Global`p2, 
         Global`rhoi$4286]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$4280]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$4283] + (Global`longProj[-Global`p1 - Global`p2, Global`rho, 
       Global`rhoi$4386]*TBsp[Global`p1, Global`p2]*
      (TBvec[Global`p1, Global`mui$4380] + 
       2*TBvec[Global`p2, Global`mui$4380])*
      (2*TBvec[Global`p1, Global`nui$4383] + TBvec[Global`p2, 
        Global`nui$4383])*(TBvec[Global`p1, Global`rhoi$4386] - 
       TBvec[Global`p2, Global`rhoi$4386])*Global`transProj[Global`p1, 
       Global`mu, Global`mui$4380]*Global`transProj[Global`p2, Global`nu, 
       Global`nui$4383])/(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])))/
  (Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] - 
     TBsp[Global`p2, Global`p2])^2), 
 ((-1/8*I)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p2, Global`p2]*
   (4*Global`longProj[Global`p2, Global`nu, Global`nui$2088]*
     (-(TBdeltaLorentz[Global`nui$2088, Global`rhoi$2091]*
        (TBvec[Global`p1, Global`mui$2085] + 
         2*TBvec[Global`p2, Global`mui$2085])) + 
      TBdeltaLorentz[Global`mui$2085, Global`rhoi$2091]*
       (2*TBvec[Global`p1, Global`nui$2088] + TBvec[Global`p2, 
         Global`nui$2088]) + TBdeltaLorentz[Global`mui$2085, Global`nui$2088]*
       (-TBvec[Global`p1, Global`rhoi$2091] + TBvec[Global`p2, 
         Global`rhoi$2091]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$2085]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$2091] + (Global`longProj[Global`p2, Global`nu, 
       Global`nui$2188]*(TBsp[Global`p1, Global`p1] + 
       TBsp[Global`p1, Global`p2])*(TBvec[Global`p1, Global`mui$2185] + 
       2*TBvec[Global`p2, Global`mui$2185])*
      (2*TBvec[Global`p1, Global`nui$2188] + TBvec[Global`p2, 
        Global`nui$2188])*(TBvec[Global`p1, Global`rhoi$2191] - 
       TBvec[Global`p2, Global`rhoi$2191])*Global`transProj[Global`p1, 
       Global`mu, Global`mui$2185]*Global`transProj[-Global`p1 - Global`p2, 
       Global`rho, Global`rhoi$2191])/(-TBsp[Global`p1, Global`p2]^2 + 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])))/
  (Global`Nc*(-1 + Global`Nc^2)*(2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])^2), 
 (I*Global`longProj[Global`p1, Global`mu, Global`mui$1990]*
   Global`longProj[Global`p2, Global`nu, Global`nui$1993]*
   TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
   (TBdeltaLorentz[Global`nui$1993, Global`rhoi$1996]*
     (TBvec[Global`p1, Global`mui$1990] + 
      2*TBvec[Global`p2, Global`mui$1990]) - 
    TBdeltaLorentz[Global`mui$1990, Global`rhoi$1996]*
     (2*TBvec[Global`p1, Global`nui$1993] + TBvec[Global`p2, 
       Global`nui$1993]) + TBdeltaLorentz[Global`mui$1990, Global`nui$1993]*
     (TBvec[Global`p1, Global`rhoi$1996] - TBvec[Global`p2, 
       Global`rhoi$1996]))*Global`transProj[-Global`p1 - Global`p2, 
    Global`rho, Global`rhoi$1996])/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
    TBsp[Global`p2, Global`p2])*(-TBsp[Global`p1, Global`p2]^2 + 
    TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])), 
 (I*Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi$1997]*
   Global`longProj[Global`p2, Global`nu, Global`nui$1994]*
   TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
    2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
   (TBdeltaLorentz[Global`nui$1994, Global`rhoi$1997]*
     (TBvec[Global`p1, Global`mui$1991] + 
      2*TBvec[Global`p2, Global`mui$1991]) - 
    TBdeltaLorentz[Global`mui$1991, Global`rhoi$1997]*
     (2*TBvec[Global`p1, Global`nui$1994] + TBvec[Global`p2, 
       Global`nui$1994]) + TBdeltaLorentz[Global`mui$1991, Global`nui$1994]*
     (TBvec[Global`p1, Global`rhoi$1997] - TBvec[Global`p2, 
       Global`rhoi$1997]))*Global`transProj[Global`p1, Global`mu, 
    Global`mui$1991])/(Global`Nc*(-1 + Global`Nc^2)*
   TBsp[Global`p1, Global`p1]*(-TBsp[Global`p1, Global`p2]^2 + 
    TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])), 
 (I*Global`longProj[Global`p1, Global`mu, Global`mui$2017]*
   Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi$2023]*
   TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p1, Global`p1]*(TBsp[Global`p1, Global`p1] + 
    2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
   (TBdeltaLorentz[Global`nui$2020, Global`rhoi$2023]*
     (TBvec[Global`p1, Global`mui$2017] + 
      2*TBvec[Global`p2, Global`mui$2017]) - 
    TBdeltaLorentz[Global`mui$2017, Global`rhoi$2023]*
     (2*TBvec[Global`p1, Global`nui$2020] + TBvec[Global`p2, 
       Global`nui$2020]) + TBdeltaLorentz[Global`mui$2017, Global`nui$2020]*
     (TBvec[Global`p1, Global`rhoi$2023] - TBvec[Global`p2, 
       Global`rhoi$2023]))*Global`transProj[Global`p2, Global`nu, 
    Global`nui$2020])/(Global`Nc*(-1 + Global`Nc^2)*
   TBsp[Global`p2, Global`p2]*(-TBsp[Global`p1, Global`p2]^2 + 
    TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])), 
 ((I/32)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
    TBsp[Global`p2, Global`p2])*
   (4*Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi$2028]*
     TBsp[Global`p1, Global`p2]*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (-(TBdeltaLorentz[Global`nui$2025, Global`rhoi$2028]*
        (TBvec[Global`p1, Global`mui$2022] + 
         2*TBvec[Global`p2, Global`mui$2022])) + 
      TBdeltaLorentz[Global`mui$2022, Global`rhoi$2028]*
       (2*TBvec[Global`p1, Global`nui$2025] + TBvec[Global`p2, 
         Global`nui$2025]) + TBdeltaLorentz[Global`mui$2022, Global`nui$2025]*
       (-TBvec[Global`p1, Global`rhoi$2028] + TBvec[Global`p2, 
         Global`rhoi$2028]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$2022]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2025] + Global`longProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$2128]*(TBsp[Global`p1, Global`p2]^2 + 
      2*TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (TBvec[Global`p1, Global`mui$2122] + 
      2*TBvec[Global`p2, Global`mui$2122])*
     (2*TBvec[Global`p1, Global`nui$2125] + TBvec[Global`p2, 
       Global`nui$2125])*(TBvec[Global`p1, Global`rhoi$2128] - 
      TBvec[Global`p2, Global`rhoi$2128])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$2122]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2125]))/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])^2*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2), 
 ((-1/32*I)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p2, Global`p2]*
   (4*Global`longProj[Global`p2, Global`nu, Global`nui$2030]*
     (TBsp[Global`p1, Global`p1] + TBsp[Global`p1, Global`p2])*
     (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*
     (-(TBdeltaLorentz[Global`nui$2030, Global`rhoi$2033]*
        (TBvec[Global`p1, Global`mui$2027] + 
         2*TBvec[Global`p2, Global`mui$2027])) + 
      TBdeltaLorentz[Global`mui$2027, Global`rhoi$2033]*
       (2*TBvec[Global`p1, Global`nui$2030] + TBvec[Global`p2, 
         Global`nui$2030]) + TBdeltaLorentz[Global`mui$2027, Global`nui$2030]*
       (-TBvec[Global`p1, Global`rhoi$2033] + TBvec[Global`p2, 
         Global`rhoi$2033]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$2027]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$2033] - Global`longProj[Global`p2, Global`nu, 
      Global`nui$2130]*(3*TBsp[Global`p1, Global`p1]^2 + 
      TBsp[Global`p1, Global`p2]^2 + 2*TBsp[Global`p1, Global`p1]*
       (3*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]))*
     (TBvec[Global`p1, Global`mui$2127] + 
      2*TBvec[Global`p2, Global`mui$2127])*
     (2*TBvec[Global`p1, Global`nui$2130] + TBvec[Global`p2, 
       Global`nui$2130])*(TBvec[Global`p1, Global`rhoi$2133] - 
      TBvec[Global`p2, Global`rhoi$2133])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$2127]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$2133]))/(Global`Nc*(-1 + Global`Nc^2)*
   (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])^2*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2), 
 ((I/32)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (Global`longProj[Global`p1, Global`mu, Global`mui$2261]*
     (4*TBsp[Global`p1, Global`p2]^4 + 2*TBsp[Global`p1, Global`p1]^3*
       TBsp[Global`p2, Global`p2] - 4*TBsp[Global`p1, Global`p1]*
       TBsp[Global`p1, Global`p2]^2*(TBsp[Global`p1, Global`p2] + 
        3*TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]^2*
       (TBsp[Global`p1, Global`p2]^2 + 10*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p2, Global`p2] + 11*TBsp[Global`p2, Global`p2]^2))*
     (TBvec[Global`p1, Global`mui$2261] + 
      2*TBvec[Global`p2, Global`mui$2261])*
     (2*TBvec[Global`p1, Global`nui$2264] + TBvec[Global`p2, 
       Global`nui$2264])*(TBvec[Global`p1, Global`rhoi$2267] - 
      TBvec[Global`p2, Global`rhoi$2267])*Global`transProj[
      -Global`p1 - Global`p2, Global`rho, Global`rhoi$2267]*
     Global`transProj[Global`p2, Global`nu, Global`nui$2264] + 
    4*Global`longProj[Global`p1, Global`mu, Global`mui$2301]*
     (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*(TBsp[Global`p1, Global`p2] + 
        3*TBsp[Global`p2, Global`p2]))*
     (-(TBdeltaLorentz[Global`nui$2304, Global`rhoi$2307]*
        TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$2301] + 
         2*TBvec[Global`p2, Global`mui$2301])) + 
      TBdeltaLorentz[Global`mui$2301, Global`rhoi$2307]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$2304] + 
        TBvec[Global`p2, Global`nui$2304]) + 
      TBdeltaLorentz[Global`mui$2301, Global`nui$2304]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(-TBvec[Global`p1, Global`rhoi$2307] + 
        TBvec[Global`p2, Global`rhoi$2307]))*Global`transProj[
      -Global`p1 - Global`p2, Global`rho, Global`rhoi$2307]*
     Global`transProj[Global`p2, Global`nu, Global`nui$2304]))/
  (Global`Nc*(-1 + Global`Nc^2)*TBsp[Global`p1, Global`p1]*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])^2*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2), 
 (I*Global`longProj[Global`p1, Global`mu, Global`mui$2119]*
   Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi$2125]*
   Global`longProj[Global`p2, Global`nu, Global`nui$2122]*
   TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
    TBsp[Global`p2, Global`p2])*(TBvec[Global`p1, Global`mui$2119] + 
    2*TBvec[Global`p2, Global`mui$2119])*
   (2*TBvec[Global`p1, Global`nui$2122] + TBvec[Global`p2, Global`nui$2122])*
   (TBvec[Global`p1, Global`rhoi$2125] - TBvec[Global`p2, Global`rhoi$2125]))/
  (Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2])^2*
   (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])^2*
   (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])^2), 
 ((I/8)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   ((Global`longProj[Global`p1, Global`mu, Global`mui$2397]*
      (-2*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
        (TBsp[Global`p1, Global`p2] + 3*TBsp[Global`p2, Global`p2]))*
      (TBvec[Global`p1, Global`mui$2397] + 
       2*TBvec[Global`p2, Global`mui$2397])*
      (2*TBvec[Global`p1, Global`nui$2400] + TBvec[Global`p2, 
        Global`nui$2400])*(TBvec[Global`p1, Global`rhoi$2403] - 
       TBvec[Global`p2, Global`rhoi$2403])*Global`transProj[
       -Global`p1 - Global`p2, Global`rho, Global`rhoi$2403]*
      Global`transProj[Global`p2, Global`nu, Global`nui$2400])/
     (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2]) - 4*Global`longProj[Global`p1, Global`mu, 
      Global`mui$2437]*(-(TBdeltaLorentz[Global`nui$2440, Global`rhoi$2443]*
        TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$2437] + 
         2*TBvec[Global`p2, Global`mui$2437])) + 
      TBdeltaLorentz[Global`mui$2437, Global`rhoi$2443]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$2440] + 
        TBvec[Global`p2, Global`nui$2440]) + 
      TBdeltaLorentz[Global`mui$2437, Global`nui$2440]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(-TBvec[Global`p1, Global`rhoi$2443] + 
        TBvec[Global`p2, Global`rhoi$2443]))*Global`transProj[
      -Global`p1 - Global`p2, Global`rho, Global`rhoi$2443]*
     Global`transProj[Global`p2, Global`nu, Global`nui$2440]))/
  (Global`Nc*(-1 + Global`Nc^2)*TBsp[Global`p1, Global`p1]*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])^2)}
