(* Created with the Wolfram Language : www.wolfram.com *)
{{(Global`Nc*(-1 + Global`Nc^2)*(2*TBsp[Global`p1, Global`p2]*
      TBsp[Global`p1, Global`p3]*TBsp[Global`p2, Global`p2]*
      TBsp[Global`p2, Global`p3] - 4*TBsp[Global`p1, Global`p1]^2*
      TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3] + 
     ((TBsp[Global`p1, Global`p2]^2 - 6*TBsp[Global`p1, Global`p2]*
          TBsp[Global`p1, Global`p3] + TBsp[Global`p1, Global`p3]^2)*
        TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p1, Global`p2]*
        TBsp[Global`p1, Global`p3]*TBsp[Global`p2, Global`p3])*
      TBsp[Global`p3, Global`p3] + TBsp[Global`p1, Global`p1]*
      (TBsp[Global`p1, Global`p3]^2*TBsp[Global`p2, Global`p2] - 
       4*TBsp[Global`p2, Global`p2]^2*TBsp[Global`p3, Global`p3] + 
       (TBsp[Global`p1, Global`p2]^2 - 6*TBsp[Global`p1, Global`p2]*
          TBsp[Global`p2, Global`p3] + TBsp[Global`p2, Global`p3]^2)*
        TBsp[Global`p3, Global`p3] + TBsp[Global`p2, Global`p2]*
        (TBsp[Global`p2, Global`p3]^2 + 6*(TBsp[Global`p1, Global`p2] + 
           TBsp[Global`p2, Global`p3])*TBsp[Global`p3, Global`p3] - 
         4*TBsp[Global`p3, Global`p3]^2) + 2*TBsp[Global`p1, Global`p3]*
        (TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p3] + 
         3*TBsp[Global`p2, Global`p2]*(-TBsp[Global`p2, Global`p3] + 
           TBsp[Global`p3, Global`p3])))))/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3])}}
