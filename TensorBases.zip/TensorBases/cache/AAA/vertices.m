(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (TBdeltaLorentz[Global`mui, Global`nui]*(-TBvec[Global`p1, Global`rhoi] + 
     TBvec[Global`p2, Global`rhoi]) + TBdeltaLorentz[Global`nui, Global`rhoi]*
    (-TBvec[Global`p2, Global`mui] + TBvec[Global`p3, Global`mui]) + 
   TBdeltaLorentz[Global`mui, Global`rhoi]*(TBvec[Global`p1, Global`nui] - 
     TBvec[Global`p3, Global`nui]))*Global`transProj[Global`p1, Global`mu, 
   Global`mui]*Global`transProj[Global`p2, Global`nu, Global`nui]*
  Global`transProj[Global`p3, Global`rho, Global`rhoi]}
