(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho, Global`d2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3]*Global`transProj[-Global`p2 - Global`p3, Global`mu, 
   Global`rho], TBdeltaDirac[Global`d2, Global`d3]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$13553, Global`d2, Global`md]*
  TBgamma[Global`rho, Global`md, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3]*(TBvec[Global`p2, Global`mu$13553] - 
   TBvec[Global`p3, Global`mu$13553])*Global`transProj[
   -Global`p2 - Global`p3, Global`mu, Global`rho], 
 -(TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBgamma[Global`mu$13555, Global`d2, Global`md]*
   TBgamma[Global`rho, Global`md, Global`d3]*TBT[Global`color, Global`a1, 
    Global`A2, Global`A3]*(TBvec[Global`p2, Global`mu$13555] + 
    TBvec[Global`p3, Global`mu$13555])*Global`transProj[
    -Global`p2 - Global`p3, Global`mu, Global`rho]), 
 I*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$13557, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$13557] + TBvec[Global`p3, Global`mu$13557])*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 (-1/3*I)*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  ((4*TBgamma[Global`rho, Global`d2, Global`d3]*
     (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3]))/(TBsp[Global`p2, Global`p2] + 
     2*TBsp[Global`p2, Global`p3] + TBsp[Global`p3, Global`p3]) + 
   3*TBgamma[Global`mu$13559, Global`d2, Global`d3]*
    (TBvec[Global`p2, Global`mu$13559] - TBvec[Global`p3, Global`mu$13559])*
    (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]))*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 (I/2)*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho, Global`dint2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3]*
  (-(TBgamma[Global`mu$13561, Global`dint1, Global`dint2]*
     TBgamma[Global`mu$13563, Global`d2, Global`dint1]*
     TBvec[Global`p2, Global`mu$13561]*TBvec[Global`p3, Global`mu$13563]) + 
   TBgamma[Global`mu$13565, Global`d2, Global`dint1]*
    TBgamma[Global`mu$13567, Global`dint1, Global`dint2]*
    TBvec[Global`p2, Global`mu$13565]*TBvec[Global`p3, Global`mu$13567])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 (TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$13569, Global`md1, Global`d3]*
      TBgamma[Global`mu$13571, Global`d2, Global`md1]*
      TBvec[Global`p2, Global`mu$13569]*TBvec[Global`p3, Global`mu$13571]) + 
    TBgamma[Global`mu$13573, Global`d2, Global`md1]*
     TBgamma[Global`mu$13575, Global`md1, Global`d3]*
     TBvec[Global`p2, Global`mu$13573]*TBvec[Global`p3, Global`mu$13575])*
   (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
   Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho])/2, 
 I*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho, Global`d2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3], Global`longProj[-Global`p2 - Global`p3, Global`mu, 
   Global`rho]*TBdeltaDirac[Global`d2, Global`d3]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]), 
 (-I)*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$13577, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$13577] - TBvec[Global`p3, Global`mu$13577])*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]), 
 (Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
   TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$13579, Global`md1, Global`d3]*
      TBgamma[Global`mu$13581, Global`d2, Global`md1]*
      TBvec[Global`p2, Global`mu$13579]*TBvec[Global`p3, Global`mu$13581]) + 
    TBgamma[Global`mu$13583, Global`d2, Global`md1]*
     TBgamma[Global`mu$13585, Global`md1, Global`d3]*
     TBvec[Global`p2, Global`mu$13583]*TBvec[Global`p3, Global`mu$13585])*
   (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]))/2}
