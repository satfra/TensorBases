(* Created with the Wolfram Language : www.wolfram.com *)
{
 (((-(TBdeltaLorentz[Global`v1$2920, Global`v4$2929]*TBdeltaLorentz[
         Global`v2$2923, Global`v3$2926]) + 
      TBdeltaLorentz[Global`v1$2920, Global`v3$2926]*
       TBdeltaLorentz[Global`v2$2923, Global`v4$2929])*
     TBF[Global`color, Global`i$2932, Global`a1, Global`a2]*
     TBF[Global`color, Global`i$2932, Global`a3, Global`a4] + 
    (-(TBdeltaLorentz[Global`v1$2920, Global`v4$2929]*
        TBdeltaLorentz[Global`v2$2923, Global`v3$2926]) + 
      TBdeltaLorentz[Global`v1$2920, Global`v2$2923]*
       TBdeltaLorentz[Global`v3$2926, Global`v4$2929])*
     TBF[Global`color, Global`i$2935, Global`a1, Global`a3]*
     TBF[Global`color, Global`i$2935, Global`a2, Global`a4] + 
    (-(TBdeltaLorentz[Global`v1$2920, Global`v3$2926]*
        TBdeltaLorentz[Global`v2$2923, Global`v4$2929]) + 
      TBdeltaLorentz[Global`v1$2920, Global`v2$2923]*
       TBdeltaLorentz[Global`v3$2926, Global`v4$2929])*
     TBF[Global`color, Global`i$2938, Global`a1, Global`a4]*
     TBF[Global`color, Global`i$2938, Global`a2, Global`a3])*
   TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
   TBsp[Global`p3, Global`p3]*TBsp[Global`p4, Global`p4]*
   Global`transProj[Global`p1, Global`mu, Global`v1$2920]*
   Global`transProj[Global`p2, Global`nu, Global`v2$2923]*
   Global`transProj[Global`p3, Global`rho, Global`v3$2926]*
   Global`transProj[Global`p4, Global`sig, Global`v4$2929])/
  (3*Global`Nc^2*(-1 + Global`Nc^2)*
   (-(TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p4]^2*
      TBsp[Global`p3, Global`p3]) + TBsp[Global`p1, Global`p4]^2*
     (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3]) + 3*TBsp[Global`p1, Global`p1]*
     TBsp[Global`p2, Global`p3]*TBsp[Global`p2, Global`p4]*
     TBsp[Global`p3, Global`p4] + TBsp[Global`p1, Global`p2]^2*
     TBsp[Global`p3, Global`p4]^2 - TBsp[Global`p1, Global`p1]*
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p4]^2 - 
    TBsp[Global`p1, Global`p4]*(TBsp[Global`p1, Global`p3]*
       (TBsp[Global`p2, Global`p3]*TBsp[Global`p2, Global`p4] - 
        3*TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p4]) + 
      TBsp[Global`p1, Global`p2]*(-3*TBsp[Global`p2, Global`p4]*
         TBsp[Global`p3, Global`p3] + TBsp[Global`p2, Global`p3]*
         TBsp[Global`p3, Global`p4])) - 
    (TBsp[Global`p1, Global`p2]^2*TBsp[Global`p3, Global`p3] + 
      TBsp[Global`p1, Global`p1]*(TBsp[Global`p2, Global`p3]^2 - 
        12*TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3]))*
     TBsp[Global`p4, Global`p4] + TBsp[Global`p1, Global`p3]^2*
     (TBsp[Global`p2, Global`p4]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p4, Global`p4]) + TBsp[Global`p1, Global`p2]*
     TBsp[Global`p1, Global`p3]*
     (-(TBsp[Global`p2, Global`p4]*TBsp[Global`p3, Global`p4]) + 
      3*TBsp[Global`p2, Global`p3]*TBsp[Global`p4, Global`p4])))}
