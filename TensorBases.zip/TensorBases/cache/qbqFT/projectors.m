(* Created with the Wolfram Language : www.wolfram.com *)
{((-1/12*I)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBgamma[0, Global`d1, Global`d2])/Global`Nf, 
 ((I/12)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBgamma[Global`mu$23392, Global`d1, Global`d2]*
   TBvecs[Global`p1, Global`mu$23392])/
  (Global`Nf*TBsps[Global`p1, Global`p1]), 
 (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaFund[Global`color, Global`A1, 
    Global`A2]*TBdeltaFund[Global`flavor, Global`F1, Global`F2])/
  (12*Global`Nf)}
