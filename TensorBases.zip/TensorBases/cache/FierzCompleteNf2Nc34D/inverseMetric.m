(* Created with the Wolfram Language : www.wolfram.com *)
{{(Global`Nf*(2 - 2*Global`Nc^2 - 4*Global`Nc*Global`Nf + 
     7*Global`Nc^3*Global`Nf))/(192*Global`Nc^3*(-1 + Global`Nc^2)*
    (-1 + Global`Nf^2)), 
  -1/192*(Global`Nf*(2 - 2*Global`Nc^2 - 4*Global`Nc*Global`Nf + 
      Global`Nc^3*Global`Nf))/(Global`Nc^3*(-1 + Global`Nc^2)*
     (-1 + Global`Nf^2)), -1/48*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2)), 
  0, Global`Nf^3/(128*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 0, 
  (Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2))/
   (96*Global`Nc^3*(-1 + Global`Nf^2)), 
  Global`Nf/(48*Global`Nc^2*(-1 + Global`Nf^2)), 
  (-2 + Global`Nf^2)/(64*Global`Nc^2*(-1 + Global`Nf^2)), 
  -1/32*(-2 + Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*
     (-1 + Global`Nf^2))}, 
 {-1/192*(Global`Nf*(2 - 2*Global`Nc^2 - 4*Global`Nc*Global`Nf + 
      Global`Nc^3*Global`Nf))/(Global`Nc^3*(-1 + Global`Nc^2)*
     (-1 + Global`Nf^2)), 
  (Global`Nf*(2 - 2*Global`Nc^2 - 4*Global`Nc*Global`Nf + 
     7*Global`Nc^3*Global`Nf))/(192*Global`Nc^3*(-1 + Global`Nc^2)*
    (-1 + Global`Nf^2)), Global`Nf/(48*Global`Nc^2*(-1 + Global`Nf^2)), 0, 
  Global`Nf^3/(128*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 0, 
  -1/96*(Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2))/
    (Global`Nc^3*(-1 + Global`Nf^2)), 
  -1/48*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2)), 
  (-2 + Global`Nf^2)/(64*Global`Nc^2*(-1 + Global`Nf^2)), 
  -1/32*(-2 + Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*
     (-1 + Global`Nf^2))}, {-1/48*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2)), 
  Global`Nf/(48*Global`Nc^2*(-1 + Global`Nf^2)), 
  (Global`Nf*(1 + 2*Global`Nc*Global`Nf))/(24*Global`Nc*(-1 + Global`Nc^2)*
    (-1 + Global`Nf^2)), 0, 0, 0, 
  Global`Nf/(48*Global`Nc^2*(-1 + Global`Nf^2)), 
  -1/24*(Global`Nf - 2*Global`Nc*(-2 + Global`Nf^2))/
    (Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 0, 0}, 
 {0, 0, 0, (Global`Nf*(-1 + Global`Nc*Global`Nf))/
   (64*Global`Nc^3*(-1 + Global`Nf^2)), 0, 
  -1/32*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2)), 0, 0, 0, 0}, 
 {Global`Nf^3/(128*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 
  Global`Nf^3/(128*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 0, 0, 
  Global`Nf^4/(256*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 0, 0, 0, 0, 
  -1/64*(Global`Nf*(-2 + Global`Nf^2))/((-1 + Global`Nc^2)*
     (-1 + Global`Nf^2))}, 
 {0, 0, 0, -1/32*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2)), 0, 
  (Global`Nf*(1 + Global`Nc*Global`Nf))/(16*Global`Nc*(-1 + Global`Nc^2)*
    (-1 + Global`Nf^2)), 0, 0, 0, 0}, 
 {(Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2))/
   (96*Global`Nc^3*(-1 + Global`Nf^2)), 
  -1/96*(Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2))/
    (Global`Nc^3*(-1 + Global`Nf^2)), 
  Global`Nf/(48*Global`Nc^2*(-1 + Global`Nf^2)), 0, 0, 0, 
  (-4 + 3*Global`Nf^2 + 2*Global`Nc*Global`Nf^3)/(96*Global`Nc^3*Global`Nf*
    (-1 + Global`Nf^2)), (4 - 3*Global`Nf^2)/(48*Global`Nc^2*Global`Nf - 
    48*Global`Nc^2*Global`Nf^3), 0, 0}, 
 {Global`Nf/(48*Global`Nc^2*(-1 + Global`Nf^2)), 
  -1/48*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2)), 
  -1/24*(Global`Nf - 2*Global`Nc*(-2 + Global`Nf^2))/
    (Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 0, 0, 0, 
  (4 - 3*Global`Nf^2)/(48*Global`Nc^2*Global`Nf - 
    48*Global`Nc^2*Global`Nf^3), 
  (4 - 3*Global`Nf^2 + 2*Global`Nc*Global`Nf^3)/
   (24*Global`Nc*(-1 + Global`Nc^2)*Global`Nf*(-1 + Global`Nf^2)), 0, 0}, 
 {(-2 + Global`Nf^2)/(64*Global`Nc^2*(-1 + Global`Nf^2)), 
  (-2 + Global`Nf^2)/(64*Global`Nc^2*(-1 + Global`Nf^2)), 0, 0, 0, 0, 0, 0, 
  Global`Nf^2/(64*Global`Nc^2*(-1 + Global`Nf^2)), 0}, 
 {-1/32*(-2 + Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 
  -1/32*(-2 + Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 
  0, 0, -1/64*(Global`Nf*(-2 + Global`Nf^2))/((-1 + Global`Nc^2)*
     (-1 + Global`Nf^2)), 0, 0, 0, 0, 
  Global`Nf^2/(16*(-1 + Global`Nc^2)*(-1 + Global`Nf^2))}}
