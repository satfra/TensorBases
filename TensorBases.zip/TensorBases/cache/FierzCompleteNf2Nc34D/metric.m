(* Created with the Wolfram Language : www.wolfram.com *)
{{(-8*Global`Nc)/Global`Nf + 2*Global`Nc*Global`Nf*
    (3 + 4*Global`Nc*Global`Nf), Global`Nc*(8/Global`Nf - 6*Global`Nf), 
  (2*(-1 + Global`Nc^2)*(-4 + 3*Global`Nf^2))/Global`Nf, 0, 
  -16*Global`Nc*Global`Nf, 0, -4*Global`Nc*
   (Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2)), 
  -2*(-1 + Global`Nc^2)*Global`Nf, -8*Global`Nc^2*(-2 + Global`Nf^2), 0}, 
 {Global`Nc*(8/Global`Nf - 6*Global`Nf), (-8*Global`Nc)/Global`Nf + 
   2*Global`Nc*Global`Nf*(3 + 4*Global`Nc*Global`Nf), 
  (-2*(-1 + Global`Nc^2)*(-4 + 3*Global`Nf^2))/Global`Nf, 0, 
  -16*Global`Nc*Global`Nf, 0, 4*Global`Nc*
   (Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2)), 
  2*(-1 + Global`Nc^2)*Global`Nf, -8*Global`Nc^2*(-2 + Global`Nf^2), 0}, 
 {(2*(-1 + Global`Nc^2)*(-4 + 3*Global`Nf^2))/Global`Nf, 
  (-2*(-1 + Global`Nc^2)*(-4 + 3*Global`Nf^2))/Global`Nf, 
  (2*(-1 + Global`Nc^2)*(4 + Global`Nf^2*(-3 + 2*Global`Nc*Global`Nf)))/
   (Global`Nc*Global`Nf), 0, 0, 0, -4*(-1 + Global`Nc^2)*Global`Nf, 
  (-2*(-1 + Global`Nc^2)*(-Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2)))/
   Global`Nc, 0, 0}, {0, 0, 0, (64*Global`Nc*(1 + Global`Nc*Global`Nf))/
   Global`Nf, 0, (32*(-1 + Global`Nc^2))/Global`Nf, 0, 0, 0, 0}, 
 {-16*Global`Nc*Global`Nf, -16*Global`Nc*Global`Nf, 0, 0, 64*Global`Nc^2, 0, 
  0, 0, (32*Global`Nc*(-2 + Global`Nf^2))/Global`Nf, 
  (16*(-1 + Global`Nc^2)*(-2 + Global`Nf^2))/Global`Nf}, 
 {0, 0, 0, (32*(-1 + Global`Nc^2))/Global`Nf, 0, 
  (16*(-1 + Global`Nc^2)*(-1 + Global`Nc*Global`Nf))/(Global`Nc*Global`Nf), 
  0, 0, 0, 0}, {-4*Global`Nc*(Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2)), 
  4*Global`Nc*(Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2)), 
  -4*(-1 + Global`Nc^2)*Global`Nf, 0, 0, 0, 8*Global`Nc*Global`Nf*
   (-1 + 2*Global`Nc*Global`Nf), -4*(-1 + Global`Nc^2)*Global`Nf, 0, 0}, 
 {-2*(-1 + Global`Nc^2)*Global`Nf, 2*(-1 + Global`Nc^2)*Global`Nf, 
  (-2*(-1 + Global`Nc^2)*(-Global`Nf + 2*Global`Nc*(-2 + Global`Nf^2)))/
   Global`Nc, 0, 0, 0, -4*(-1 + Global`Nc^2)*Global`Nf, 
  (2*(-1 + Global`Nc^2)*Global`Nf*(1 + 2*Global`Nc*Global`Nf))/Global`Nc, 0, 
  0}, {-8*Global`Nc^2*(-2 + Global`Nf^2), -8*Global`Nc^2*(-2 + Global`Nf^2), 
  0, 0, (32*Global`Nc*(-2 + Global`Nf^2))/Global`Nf, 0, 0, 0, 
  16*Global`Nc^2*Global`Nf^2, 0}, 
 {0, 0, 0, 0, (16*(-1 + Global`Nc^2)*(-2 + Global`Nf^2))/Global`Nf, 0, 0, 0, 
  0, 4*(-1 + Global`Nc^2)*Global`Nf^2}}
