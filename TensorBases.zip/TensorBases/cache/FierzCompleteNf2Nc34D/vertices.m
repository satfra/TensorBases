(* Created with the Wolfram Language : www.wolfram.com *)
{(TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4]*TBdeltaFund[Global`flavor, 
       Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, 
       Global`F4] - 2*Global`Nf*TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4]*TBT[Global`flavor, Global`f$11065, 
       Global`F1, Global`F2]*TBT[Global`flavor, Global`f$11065, Global`F3, 
       Global`F4]) + TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (-(TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2]*
       TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F2]) + 
     2*Global`Nf*TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, 
       Global`d2]*TBT[Global`flavor, Global`f$11081, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$11081, Global`F3, Global`F2]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*
    (-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
     2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$3460, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3460, Global`F3, Global`F4]) + 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
      TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2] - 
     2*Global`Nf*TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, 
       Global`d2]*TBT[Global`flavor, Global`f$3476, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$3476, Global`F3, Global`F2]))/Global`Nf, 
 ((TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    TBT[Global`color, Global`a$3491, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$3491, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$3494, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3494, Global`F3, Global`F4]) - 
   (TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2] + 
     TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2])*
    TBT[Global`color, Global`a$3510, Global`A1, Global`A4]*
    TBT[Global`color, Global`a$3510, Global`A3, Global`A2]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F2] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$3513, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$3513, Global`F3, Global`F2]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[Global`\[Mu]$4150, Global`d1, Global`d2]*
      TBgamma[Global`\[Mu]$4150, Global`d3, Global`d4] + 
     TBgamma[Global`\[Mu]$4150, Global`d1, Global`dc$4153]*
      TBgamma[Global`\[Mu]$4150, Global`d3, Global`dc$4156]*
      TBgamma5[Global`dc$4153, Global`d2]*TBgamma5[Global`dc$4156, 
       Global`d4]) - TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (TBgamma[Global`\[Mu]$4172, Global`d1, Global`d4]*
      TBgamma[Global`\[Mu]$4172, Global`d3, Global`d2] + 
     TBgamma[Global`\[Mu]$4172, Global`d1, Global`dc$4178]*
      TBgamma[Global`\[Mu]$4172, Global`d3, Global`dc$4175]*
      TBgamma5[Global`dc$4175, Global`d2]*TBgamma5[Global`dc$4178, 
       Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[Global`\[Mu]$4463, Global`d1, Global`d2]*
      TBgamma[Global`\[Mu]$4463, Global`d3, Global`d4] - 
     TBgamma[Global`\[Mu]$4463, Global`d1, Global`dc$4466]*
      TBgamma[Global`\[Mu]$4463, Global`d3, Global`dc$4469]*
      TBgamma5[Global`dc$4466, Global`d2]*TBgamma5[Global`dc$4469, 
       Global`d4]) + TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (-(TBgamma[Global`\[Mu]$4485, Global`d1, Global`d4]*
       TBgamma[Global`\[Mu]$4485, Global`d3, Global`d2]) + 
     TBgamma[Global`\[Mu]$4485, Global`d1, Global`dc$4491]*
      TBgamma[Global`\[Mu]$4485, Global`d3, Global`dc$4488]*
      TBgamma5[Global`dc$4488, Global`d2]*TBgamma5[Global`dc$4491, 
       Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[Global`\[Mu]$4141, Global`d1, Global`d2]*
      TBgamma[Global`\[Mu]$4141, Global`d3, Global`d4] + 
     TBgamma[Global`\[Mu]$4141, Global`d1, Global`dc$4144]*
      TBgamma[Global`\[Mu]$4141, Global`d3, Global`dc$4147]*
      TBgamma5[Global`dc$4144, Global`d2]*TBgamma5[Global`dc$4147, 
       Global`d4])*TBT[Global`color, Global`a$4150, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$4150, Global`A3, Global`A4] - 
   TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (TBgamma[Global`\[Mu]$4166, Global`d1, Global`d4]*
      TBgamma[Global`\[Mu]$4166, Global`d3, Global`d2] + 
     TBgamma[Global`\[Mu]$4166, Global`d1, Global`dc$4172]*
      TBgamma[Global`\[Mu]$4166, Global`d3, Global`dc$4169]*
      TBgamma5[Global`dc$4169, Global`d2]*TBgamma5[Global`dc$4172, 
       Global`d4])*TBT[Global`color, Global`a$4175, Global`A1, Global`A4]*
    TBT[Global`color, Global`a$4175, Global`A3, Global`A2])/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4] + TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4])*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     2*Global`Nf*TBT[Global`flavor, Global`f$3490, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3490, Global`F3, Global`F4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2] + 
     TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2])*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F2] + 
     2*Global`Nf*TBT[Global`flavor, Global`f$3506, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$3506, Global`F3, Global`F2]))/Global`Nf, 
 ((TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] + 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    TBT[Global`color, Global`a$3515, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$3515, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     2*Global`Nf*TBT[Global`flavor, Global`f$3518, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3518, Global`F3, Global`F4]) - 
   (TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2] + 
     TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2])*
    TBT[Global`color, Global`a$3534, Global`A1, Global`A4]*
    TBT[Global`color, Global`a$3534, Global`A3, Global`A2]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F2] + 
     2*Global`Nf*TBT[Global`flavor, Global`f$3537, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$3537, Global`F3, Global`F2]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4] - TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4])*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$3061, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3061, Global`F3, Global`F4]) + 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    (TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2] - 
     TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2])*
    (-(TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F2]) + 
     2*Global`Nf*TBT[Global`flavor, Global`f$3077, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$3077, Global`F3, Global`F2]))/Global`Nf, 
 ((TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    TBT[Global`color, Global`a$2708, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$2708, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$2711, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$2711, Global`F3, Global`F4]) - 
   (TBdeltaDirac[Global`d1, Global`d4]*TBdeltaDirac[Global`d3, Global`d2] - 
     TBgamma5[Global`d1, Global`d4]*TBgamma5[Global`d3, Global`d2])*
    TBT[Global`color, Global`a$2727, Global`A1, Global`A4]*
    TBT[Global`color, Global`a$2727, Global`A3, Global`A2]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F2] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$2730, Global`F1, Global`F4]*
      TBT[Global`flavor, Global`f$2730, Global`F3, Global`F2]))/Global`Nf}
