(* Created with the Wolfram Language : www.wolfram.com *)
{((I/4)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBgamma[Global`mu$363354, Global`d1, Global`d2]*
   TBvec[Global`p1, Global`mu$363354])/
  (Global`Nc*TBsp[Global`p1, Global`p1]), 
 (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaFund[Global`color, Global`A1, 
    Global`A2])/(4*Global`Nc)}
