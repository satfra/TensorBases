(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBdeltaFund[Global`color, Global`A1, Global`A2]*
  TBgamma[Global`mu$363320, Global`d1, Global`d2]*
  TBvec[Global`p1, Global`mu$363320], TBdeltaDirac[Global`d1, Global`d2]*
  TBdeltaFund[Global`color, Global`A1, Global`A2]}
