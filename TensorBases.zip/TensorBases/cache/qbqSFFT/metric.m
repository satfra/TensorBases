(* Created with the Wolfram Language : www.wolfram.com *)
{{-12, 0, 0}, {0, 12*TBsps[Global`p1, Global`p1], 0}, {0, 0, 12}}
