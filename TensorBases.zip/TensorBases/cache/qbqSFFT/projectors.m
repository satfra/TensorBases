(* Created with the Wolfram Language : www.wolfram.com *)
{(-1/12*I)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
  TBgamma[0, Global`d1, Global`d2], 
 ((I/12)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBgamma[Global`mu$23469, Global`d1, Global`d2]*
   TBvecs[Global`p1, Global`mu$23469])/TBsps[Global`p1, Global`p1], 
 (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaFund[Global`color, Global`A1, 
    Global`A2])/12}
