(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho$2603, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2603], 
 TBdeltaDirac[Global`d2, Global`d3]*TBdeltaFund[Global`flavor, Global`F2, 
   Global`F3]*TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`rho$2689] - TBvec[Global`p3, Global`rho$2689])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2689], 
 TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$2778, Global`d2, Global`md$2784]*
  TBgamma[Global`rho$2781, Global`md$2784, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$2778] - TBvec[Global`p3, Global`mu$2778])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2781], 
 TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$2431, Global`d2, Global`md$2437]*
  TBgamma[Global`rho$2434, Global`md$2437, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$2431] + TBvec[Global`p3, Global`mu$2431])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2434], 
 I*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$2437, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$2437] + TBvec[Global`p3, Global`mu$2437])*
  (TBvec[Global`p2, Global`rho$2440] - TBvec[Global`p3, Global`rho$2440])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2440], 
 I*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$2431, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$2431] - TBvec[Global`p3, Global`mu$2431])*
  (TBvec[Global`p2, Global`rho$2434] - TBvec[Global`p3, Global`rho$2434])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2434], 
 (I/2)*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho$2443, Global`dint2$2449, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (-(TBgamma[Global`mu$2431, Global`dint1$2446, Global`dint2$2449]*
     TBgamma[Global`mu$2434, Global`d2, Global`dint1$2446]*
     TBvec[Global`p2, Global`mu$2431]*TBvec[Global`p3, Global`mu$2434]) + 
   TBgamma[Global`mu$2437, Global`d2, Global`dint1$2446]*
    TBgamma[Global`mu$2440, Global`dint1$2446, Global`dint2$2449]*
    TBvec[Global`p2, Global`mu$2437]*TBvec[Global`p3, Global`mu$2440])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2443], 
 (TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$2431, Global`md1$2446, Global`d3]*
      TBgamma[Global`mu$2434, Global`d2, Global`md1$2446]*
      TBvec[Global`p2, Global`mu$2431]*TBvec[Global`p3, Global`mu$2434]) + 
    TBgamma[Global`mu$2437, Global`d2, Global`md1$2446]*
     TBgamma[Global`mu$2440, Global`md1$2446, Global`d3]*
     TBvec[Global`p2, Global`mu$2437]*TBvec[Global`p3, Global`mu$2440])*
   (TBvec[Global`p2, Global`rho$2443] - TBvec[Global`p3, Global`rho$2443])*
   Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2443])/2, 
 I*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2437]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho$2437, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3], 
 Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2431]*
  TBdeltaDirac[Global`d2, Global`d3]*TBdeltaFund[Global`flavor, Global`F2, 
   Global`F3]*TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`rho$2431] - TBvec[Global`p3, Global`rho$2431]), 
 (-I)*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2434]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$2431, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$2431] - TBvec[Global`p3, Global`mu$2431])*
  (TBvec[Global`p2, Global`rho$2434] - TBvec[Global`p3, Global`rho$2434]), 
 (Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho$2449]*
   TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$2437, Global`md1$2452, Global`d3]*
      TBgamma[Global`mu$2440, Global`d2, Global`md1$2452]*
      TBvec[Global`p2, Global`mu$2437]*TBvec[Global`p3, Global`mu$2440]) + 
    TBgamma[Global`mu$2443, Global`d2, Global`md1$2452]*
     TBgamma[Global`mu$2446, Global`md1$2452, Global`d3]*
     TBvec[Global`p2, Global`mu$2443]*TBvec[Global`p3, Global`mu$2446])*
   (TBvec[Global`p2, Global`rho$2449] - TBvec[Global`p3, Global`rho$2449]))/2}
