(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho, Global`d2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3]*Global`transProj[-Global`p2 - Global`p3, Global`mu, 
   Global`rho], TBdeltaDirac[Global`d2, Global`d3]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$69427, Global`d2, Global`md]*
  TBgamma[Global`rho, Global`md, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3]*(TBvec[Global`p2, Global`mu$69427] - 
   TBvec[Global`p3, Global`mu$69427])*Global`transProj[
   -Global`p2 - Global`p3, Global`mu, Global`rho], 
 TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$69429, Global`d2, Global`md]*
  TBgamma[Global`rho, Global`md, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3]*(TBvec[Global`p2, Global`mu$69429] + 
   TBvec[Global`p3, Global`mu$69429])*Global`transProj[
   -Global`p2 - Global`p3, Global`mu, Global`rho], 
 I*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$69431, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$69431] + TBvec[Global`p3, Global`mu$69431])*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 I*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$69433, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$69433] - TBvec[Global`p3, Global`mu$69433])*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 (I/2)*TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho, Global`dint2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3]*
  (-(TBgamma[Global`mu$69435, Global`dint1, Global`dint2]*
     TBgamma[Global`mu$69437, Global`d2, Global`dint1]*
     TBvec[Global`p2, Global`mu$69435]*TBvec[Global`p3, Global`mu$69437]) + 
   TBgamma[Global`mu$69439, Global`d2, Global`dint1]*
    TBgamma[Global`mu$69441, Global`dint1, Global`dint2]*
    TBvec[Global`p2, Global`mu$69439]*TBvec[Global`p3, Global`mu$69441])*
  Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho], 
 (TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$69443, Global`md1, Global`d3]*
      TBgamma[Global`mu$69445, Global`d2, Global`md1]*
      TBvec[Global`p2, Global`mu$69443]*TBvec[Global`p3, Global`mu$69445]) + 
    TBgamma[Global`mu$69447, Global`d2, Global`md1]*
     TBgamma[Global`mu$69449, Global`md1, Global`d3]*
     TBvec[Global`p2, Global`mu$69447]*TBvec[Global`p3, Global`mu$69449])*
   (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho])*
   Global`transProj[-Global`p2 - Global`p3, Global`mu, Global`rho])/2, 
 I*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`rho, Global`d2, Global`d3]*TBT[Global`color, Global`a1, 
   Global`A2, Global`A3], Global`longProj[-Global`p2 - Global`p3, Global`mu, 
   Global`rho]*TBdeltaDirac[Global`d2, Global`d3]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]), 
 (-I)*Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
  TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
  TBgamma[Global`mu$69451, Global`d2, Global`d3]*
  TBT[Global`color, Global`a1, Global`A2, Global`A3]*
  (TBvec[Global`p2, Global`mu$69451] - TBvec[Global`p3, Global`mu$69451])*
  (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]), 
 (Global`longProj[-Global`p2 - Global`p3, Global`mu, Global`rho]*
   TBdeltaFund[Global`flavor, Global`F2, Global`F3]*
   TBT[Global`color, Global`a1, Global`A2, Global`A3]*
   (-(TBgamma[Global`mu$69453, Global`md1, Global`d3]*
      TBgamma[Global`mu$69455, Global`d2, Global`md1]*
      TBvec[Global`p2, Global`mu$69453]*TBvec[Global`p3, Global`mu$69455]) + 
    TBgamma[Global`mu$69457, Global`d2, Global`md1]*
     TBgamma[Global`mu$69459, Global`md1, Global`d3]*
     TBvec[Global`p2, Global`mu$69457]*TBvec[Global`p3, Global`mu$69459])*
   (TBvec[Global`p2, Global`rho] - TBvec[Global`p3, Global`rho]))/2}
