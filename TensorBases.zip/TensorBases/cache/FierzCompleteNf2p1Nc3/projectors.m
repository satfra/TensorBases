(* Created with the Wolfram Language : www.wolfram.com *)
{(3*(4*Global`Nc*(9 - 8*Global`Nf)*Global`Nf*(2 + Global`Nf)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2321]*TBgamma[0, Global`d3, 
        Global`dc$2324]*TBgamma5[Global`dc$2321, Global`d2]*
       TBgamma5[Global`dc$2324, Global`d4]) + 4*Global`Nc*(9 - 8*Global`Nf)*
     Global`Nf^2*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2497]*TBgamma[0, Global`d3, 
        Global`dc$2500]*TBgamma5[Global`dc$2497, Global`d2]*
       TBgamma5[Global`dc$2500, Global`d4]) + 
    4*Global`Nc*(18 - 34*Global`Nf - 9*Global`Nf^2 + 8*Global`Nf^3)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2614]*TBgamma[0, Global`d3, 
        Global`dc$2617]*TBgamma5[Global`dc$2614, Global`d2]*
       TBgamma5[Global`dc$2617, Global`d4]) - 
    Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$2826]*TBgamma[1, Global`a$2826, 
            Global`d2] - TBgamma[0, Global`a$2829, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2829])*
         (TBgamma[0, Global`d3, Global`a$2832]*TBgamma[1, Global`a$2832, 
            Global`d4] - TBgamma[0, Global`a$2835, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2835]) - 
        (TBgamma[1, Global`a$2862, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2862] - TBgamma[1, Global`a$2865, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2865])*
         (TBgamma[1, Global`a$2868, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2868] - TBgamma[1, Global`a$2871, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2871]) + 
        2*(TBgamma[0, Global`d1, Global`a$2838]*TBgamma[2, Global`a$2838, 
            Global`d2] - TBgamma[0, Global`a$2841, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2841])*
         (TBgamma[0, Global`d3, Global`a$2844]*TBgamma[2, Global`a$2844, 
            Global`d4] - TBgamma[0, Global`a$2847, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2847]) - 
        (TBgamma[1, Global`d1, Global`a$2874]*TBgamma[2, Global`a$2874, 
            Global`d2] - TBgamma[1, Global`a$2877, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2877])*
         (TBgamma[1, Global`d3, Global`a$2880]*TBgamma[2, Global`a$2880, 
            Global`d4] - TBgamma[1, Global`a$2883, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2883]) - 
        (TBgamma[1, Global`d1, Global`a$2901]*TBgamma[2, Global`a$2901, 
            Global`d2] - TBgamma[1, Global`a$2898, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2898])*
         (TBgamma[1, Global`d3, Global`a$2907]*TBgamma[2, Global`a$2907, 
            Global`d4] - TBgamma[1, Global`a$2904, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2904]) - 
        (TBgamma[2, Global`a$2910, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2910] - TBgamma[2, Global`a$2913, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2913])*
         (TBgamma[2, Global`a$2916, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2916] - TBgamma[2, Global`a$2919, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2919]) + 
        2*(TBgamma[0, Global`d1, Global`a$2850]*TBgamma[3, Global`a$2850, 
            Global`d2] - TBgamma[0, Global`a$2853, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2853])*
         (TBgamma[0, Global`d3, Global`a$2856]*TBgamma[3, Global`a$2856, 
            Global`d4] - TBgamma[0, Global`a$2859, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2859]) - 
        (TBgamma[1, Global`d1, Global`a$2886]*TBgamma[3, Global`a$2886, 
            Global`d2] - TBgamma[1, Global`a$2889, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2889])*
         (TBgamma[1, Global`d3, Global`a$2892]*TBgamma[3, Global`a$2892, 
            Global`d4] - TBgamma[1, Global`a$2895, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2895]) - 
        (TBgamma[2, Global`d1, Global`a$2922]*TBgamma[3, Global`a$2922, 
            Global`d2] - TBgamma[2, Global`a$2925, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2925])*
         (TBgamma[2, Global`d3, Global`a$2928]*TBgamma[3, Global`a$2928, 
            Global`d4] - TBgamma[2, Global`a$2931, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2931]) - 
        (TBgamma[1, Global`d1, Global`a$2937]*TBgamma[3, Global`a$2937, 
            Global`d2] - TBgamma[1, Global`a$2934, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2934])*
         (TBgamma[1, Global`d3, Global`a$2943]*TBgamma[3, Global`a$2943, 
            Global`d4] - TBgamma[1, Global`a$2940, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2940]) - 
        (TBgamma[2, Global`d1, Global`a$2949]*TBgamma[3, Global`a$2949, 
            Global`d2] - TBgamma[2, Global`a$2946, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2946])*
         (TBgamma[2, Global`d3, Global`a$2955]*TBgamma[3, Global`a$2955, 
            Global`d4] - TBgamma[2, Global`a$2952, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2952]) - 
        (TBgamma[3, Global`a$2958, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2958] - TBgamma[3, Global`a$2961, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2961])*
         (TBgamma[3, Global`a$2964, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2964] - TBgamma[3, Global`a$2967, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2967])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$2970]*TBgamma[1, Global`a$2970, 
            Global`d2] - TBgamma[0, Global`a$2973, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2973])*
         (TBgamma[0, Global`d3, Global`a$2976]*TBgamma[1, Global`a$2976, 
            Global`d4] - TBgamma[0, Global`a$2979, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2979]) - 
        (TBgamma[1, Global`a$3006, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$3006] - TBgamma[1, Global`a$3009, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3009])*
         (TBgamma[1, Global`a$3012, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$3012] - TBgamma[1, Global`a$3015, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3015]) + 
        2*(TBgamma[0, Global`d1, Global`a$2982]*TBgamma[2, Global`a$2982, 
            Global`d2] - TBgamma[0, Global`a$2985, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2985])*
         (TBgamma[0, Global`d3, Global`a$2988]*TBgamma[2, Global`a$2988, 
            Global`d4] - TBgamma[0, Global`a$2991, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2991]) - 
        (TBgamma[1, Global`d1, Global`a$3018]*TBgamma[2, Global`a$3018, 
            Global`d2] - TBgamma[1, Global`a$3021, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3021])*
         (TBgamma[1, Global`d3, Global`a$3024]*TBgamma[2, Global`a$3024, 
            Global`d4] - TBgamma[1, Global`a$3027, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3027]) - 
        (TBgamma[1, Global`d1, Global`a$3045]*TBgamma[2, Global`a$3045, 
            Global`d2] - TBgamma[1, Global`a$3042, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3042])*
         (TBgamma[1, Global`d3, Global`a$3051]*TBgamma[2, Global`a$3051, 
            Global`d4] - TBgamma[1, Global`a$3048, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3048]) - 
        (TBgamma[2, Global`a$3054, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$3054] - TBgamma[2, Global`a$3057, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3057])*
         (TBgamma[2, Global`a$3060, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$3060] - TBgamma[2, Global`a$3063, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3063]) + 
        2*(TBgamma[0, Global`d1, Global`a$2994]*TBgamma[3, Global`a$2994, 
            Global`d2] - TBgamma[0, Global`a$2997, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2997])*
         (TBgamma[0, Global`d3, Global`a$3000]*TBgamma[3, Global`a$3000, 
            Global`d4] - TBgamma[0, Global`a$3003, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3003]) - 
        (TBgamma[1, Global`d1, Global`a$3030]*TBgamma[3, Global`a$3030, 
            Global`d2] - TBgamma[1, Global`a$3033, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3033])*
         (TBgamma[1, Global`d3, Global`a$3036]*TBgamma[3, Global`a$3036, 
            Global`d4] - TBgamma[1, Global`a$3039, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3039]) - 
        (TBgamma[2, Global`d1, Global`a$3066]*TBgamma[3, Global`a$3066, 
            Global`d2] - TBgamma[2, Global`a$3069, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3069])*
         (TBgamma[2, Global`d3, Global`a$3073]*TBgamma[3, Global`a$3073, 
            Global`d4] - TBgamma[2, Global`a$3076, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3076]) - 
        (TBgamma[1, Global`d1, Global`a$3082]*TBgamma[3, Global`a$3082, 
            Global`d2] - TBgamma[1, Global`a$3079, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3079])*
         (TBgamma[1, Global`d3, Global`a$3088]*TBgamma[3, Global`a$3088, 
            Global`d4] - TBgamma[1, Global`a$3085, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3085]) - 
        (TBgamma[2, Global`d1, Global`a$3094]*TBgamma[3, Global`a$3094, 
            Global`d2] - TBgamma[2, Global`a$3091, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3091])*
         (TBgamma[2, Global`d3, Global`a$3100]*TBgamma[3, Global`a$3100, 
            Global`d4] - TBgamma[2, Global`a$3097, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3097]) - 
        (TBgamma[3, Global`a$3103, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$3103] - TBgamma[3, Global`a$3106, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3106])*
         (TBgamma[3, Global`a$3109, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$3109] - TBgamma[3, Global`a$3112, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3112]))*TBT[Global`flavor, 
        Global`af$3115, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$3115, Global`F3, Global`F4]) - 2*Global`Nc*Global`Nf*
     TBT[Global`color, Global`ac$3421, Global`A1, Global`A2]*
     TBT[Global`color, Global`ac$3421, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$3131]*TBgamma[1, Global`a$3131, 
            Global`d2] - TBgamma[0, Global`a$3134, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3134])*
         (TBgamma[0, Global`d3, Global`a$3137]*TBgamma[1, Global`a$3137, 
            Global`d4] - TBgamma[0, Global`a$3140, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3140]) - 
        (TBgamma[1, Global`a$3167, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$3167] - TBgamma[1, Global`a$3170, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3170])*
         (TBgamma[1, Global`a$3173, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$3173] - TBgamma[1, Global`a$3176, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3176]) + 
        2*(TBgamma[0, Global`d1, Global`a$3143]*TBgamma[2, Global`a$3143, 
            Global`d2] - TBgamma[0, Global`a$3146, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3146])*
         (TBgamma[0, Global`d3, Global`a$3149]*TBgamma[2, Global`a$3149, 
            Global`d4] - TBgamma[0, Global`a$3152, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3152]) - 
        (TBgamma[1, Global`d1, Global`a$3179]*TBgamma[2, Global`a$3179, 
            Global`d2] - TBgamma[1, Global`a$3182, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3182])*
         (TBgamma[1, Global`d3, Global`a$3185]*TBgamma[2, Global`a$3185, 
            Global`d4] - TBgamma[1, Global`a$3188, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3188]) - 
        (TBgamma[1, Global`d1, Global`a$3206]*TBgamma[2, Global`a$3206, 
            Global`d2] - TBgamma[1, Global`a$3203, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3203])*
         (TBgamma[1, Global`d3, Global`a$3212]*TBgamma[2, Global`a$3212, 
            Global`d4] - TBgamma[1, Global`a$3209, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3209]) - 
        (TBgamma[2, Global`a$3215, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$3215] - TBgamma[2, Global`a$3218, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3218])*
         (TBgamma[2, Global`a$3221, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$3221] - TBgamma[2, Global`a$3224, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3224]) + 
        2*(TBgamma[0, Global`d1, Global`a$3155]*TBgamma[3, Global`a$3155, 
            Global`d2] - TBgamma[0, Global`a$3158, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3158])*
         (TBgamma[0, Global`d3, Global`a$3161]*TBgamma[3, Global`a$3161, 
            Global`d4] - TBgamma[0, Global`a$3164, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3164]) - 
        (TBgamma[1, Global`d1, Global`a$3191]*TBgamma[3, Global`a$3191, 
            Global`d2] - TBgamma[1, Global`a$3194, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3194])*
         (TBgamma[1, Global`d3, Global`a$3197]*TBgamma[3, Global`a$3197, 
            Global`d4] - TBgamma[1, Global`a$3200, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3200]) - 
        (TBgamma[2, Global`d1, Global`a$3227]*TBgamma[3, Global`a$3227, 
            Global`d2] - TBgamma[2, Global`a$3230, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3230])*
         (TBgamma[2, Global`d3, Global`a$3233]*TBgamma[3, Global`a$3233, 
            Global`d4] - TBgamma[2, Global`a$3236, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3236]) - 
        (TBgamma[1, Global`d1, Global`a$3242]*TBgamma[3, Global`a$3242, 
            Global`d2] - TBgamma[1, Global`a$3239, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3239])*
         (TBgamma[1, Global`d3, Global`a$3248]*TBgamma[3, Global`a$3248, 
            Global`d4] - TBgamma[1, Global`a$3245, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3245]) - 
        (TBgamma[2, Global`d1, Global`a$3254]*TBgamma[3, Global`a$3254, 
            Global`d2] - TBgamma[2, Global`a$3251, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3251])*
         (TBgamma[2, Global`d3, Global`a$3260]*TBgamma[3, Global`a$3260, 
            Global`d4] - TBgamma[2, Global`a$3257, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3257]) - 
        (TBgamma[3, Global`a$3263, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$3263] - TBgamma[3, Global`a$3266, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3266])*
         (TBgamma[3, Global`a$3269, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$3269] - TBgamma[3, Global`a$3272, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3272])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$3275]*TBgamma[1, Global`a$3275, 
            Global`d2] - TBgamma[0, Global`a$3278, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3278])*
         (TBgamma[0, Global`d3, Global`a$3281]*TBgamma[1, Global`a$3281, 
            Global`d4] - TBgamma[0, Global`a$3284, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3284]) - 
        (TBgamma[1, Global`a$3311, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$3311] - TBgamma[1, Global`a$3314, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3314])*
         (TBgamma[1, Global`a$3317, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$3317] - TBgamma[1, Global`a$3320, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3320]) + 
        2*(TBgamma[0, Global`d1, Global`a$3287]*TBgamma[2, Global`a$3287, 
            Global`d2] - TBgamma[0, Global`a$3290, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3290])*
         (TBgamma[0, Global`d3, Global`a$3293]*TBgamma[2, Global`a$3293, 
            Global`d4] - TBgamma[0, Global`a$3296, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3296]) - 
        (TBgamma[1, Global`d1, Global`a$3323]*TBgamma[2, Global`a$3323, 
            Global`d2] - TBgamma[1, Global`a$3326, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3326])*
         (TBgamma[1, Global`d3, Global`a$3329]*TBgamma[2, Global`a$3329, 
            Global`d4] - TBgamma[1, Global`a$3332, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3332]) - 
        (TBgamma[1, Global`d1, Global`a$3350]*TBgamma[2, Global`a$3350, 
            Global`d2] - TBgamma[1, Global`a$3347, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3347])*
         (TBgamma[1, Global`d3, Global`a$3356]*TBgamma[2, Global`a$3356, 
            Global`d4] - TBgamma[1, Global`a$3353, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3353]) - 
        (TBgamma[2, Global`a$3359, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$3359] - TBgamma[2, Global`a$3362, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3362])*
         (TBgamma[2, Global`a$3365, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$3365] - TBgamma[2, Global`a$3368, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3368]) + 
        2*(TBgamma[0, Global`d1, Global`a$3299]*TBgamma[3, Global`a$3299, 
            Global`d2] - TBgamma[0, Global`a$3302, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3302])*
         (TBgamma[0, Global`d3, Global`a$3305]*TBgamma[3, Global`a$3305, 
            Global`d4] - TBgamma[0, Global`a$3308, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3308]) - 
        (TBgamma[1, Global`d1, Global`a$3335]*TBgamma[3, Global`a$3335, 
            Global`d2] - TBgamma[1, Global`a$3338, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3338])*
         (TBgamma[1, Global`d3, Global`a$3341]*TBgamma[3, Global`a$3341, 
            Global`d4] - TBgamma[1, Global`a$3344, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3344]) - 
        (TBgamma[2, Global`d1, Global`a$3371]*TBgamma[3, Global`a$3371, 
            Global`d2] - TBgamma[2, Global`a$3374, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3374])*
         (TBgamma[2, Global`d3, Global`a$3377]*TBgamma[3, Global`a$3377, 
            Global`d4] - TBgamma[2, Global`a$3381, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3381]) - 
        (TBgamma[1, Global`d1, Global`a$3387]*TBgamma[3, Global`a$3387, 
            Global`d2] - TBgamma[1, Global`a$3384, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3384])*
         (TBgamma[1, Global`d3, Global`a$3393]*TBgamma[3, Global`a$3393, 
            Global`d4] - TBgamma[1, Global`a$3390, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3390]) - 
        (TBgamma[2, Global`d1, Global`a$3400]*TBgamma[3, Global`a$3400, 
            Global`d2] - TBgamma[2, Global`a$3396, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3396])*
         (TBgamma[2, Global`d3, Global`a$3406]*TBgamma[3, Global`a$3406, 
            Global`d4] - TBgamma[2, Global`a$3403, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3403]) - 
        (TBgamma[3, Global`a$3409, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$3409] - TBgamma[3, Global`a$3412, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3412])*
         (TBgamma[3, Global`a$3415, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$3415] - TBgamma[3, Global`a$3418, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3418]))*TBT[Global`flavor, 
        Global`af$3424, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$3424, Global`F3, Global`F4]) - 
    8*Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$2791, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$2791, Global`F3, Global`F4]) - 
    16*Global`Nc*Global`Nf*(TBdeltaDirac[Global`d1, Global`d2]*
       TBdeltaDirac[Global`d3, Global`d4] - TBgamma5[Global`d1, Global`d2]*
       TBgamma5[Global`d3, Global`d4])*TBT[Global`color, Global`a$2807, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2807, Global`A3, 
      Global`A4]*(4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$2810, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$2810, Global`F3, Global`F4])))/
  (256*Global`Nc^3*(9 - 8*Global`Nf)*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
 (8*Global`Nf^2*(-9 + 8*Global`Nf)*TBdeltaFund[Global`color, Global`A1, 
     Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
     Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
    TBdeltaFund[Global`flavor, Global`F4, 3]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
   4*Global`Nc*(9 - 8*Global`Nf)*Global`Nf*(2 + Global`Nf)*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$3459, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$3459, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$3459, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$3459, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$3459, 0]*TBgamma[0, Global`d1, 
          Global`dc$3462]) + TBgamma[Global`i$3459, Global`d1, 
        Global`dc$3462])*(-(TBdeltaLorentz[Global`i$3459, 0]*
         TBgamma[0, Global`d3, Global`dc$3465]) + TBgamma[Global`i$3459, 
        Global`d3, Global`dc$3465])*TBgamma5[Global`dc$3462, Global`d2]*
      TBgamma5[Global`dc$3465, Global`d4]) + 4*Global`Nc*Global`Nf^2*
    (-9 + 8*Global`Nf)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
     Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
    TBdeltaFund[Global`flavor, Global`F4, 3]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$3616]*TBgamma[0, Global`d3, 
       Global`dc$3619]*TBgamma5[Global`dc$3616, Global`d2]*
      TBgamma5[Global`dc$3619, Global`d4]) + 
   4*Global`Nc*(18 - 34*Global`Nf - 9*Global`Nf^2 + 8*Global`Nf^3)*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$3752, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$3752, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$3752, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$3752, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$3752, 0]*TBgamma[0, Global`d1, 
          Global`dc$3755]) + TBgamma[Global`i$3752, Global`d1, 
        Global`dc$3755])*(-(TBdeltaLorentz[Global`i$3752, 0]*
         TBgamma[0, Global`d3, Global`dc$3758]) + TBgamma[Global`i$3752, 
        Global`d3, Global`dc$3758])*TBgamma5[Global`dc$3755, Global`d2]*
      TBgamma5[Global`dc$3758, Global`d4]) + 16*Global`Nc*Global`Nf^2*
    (-9 + 8*Global`Nf)*TBdeltaFund[Global`flavor, Global`F1, 3]*
    TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
     Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    TBT[Global`color, Global`a$3717, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$3717, Global`A3, Global`A4] + 
   Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (2*(TBgamma[0, Global`d1, Global`a$3946]*TBgamma[1, Global`a$3946, 
           Global`d2] - TBgamma[0, Global`a$3949, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3949])*
        (TBgamma[0, Global`d3, Global`a$3952]*TBgamma[1, Global`a$3952, 
           Global`d4] - TBgamma[0, Global`a$3955, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3955]) - 
       (TBgamma[1, Global`a$3982, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$3982] - TBgamma[1, Global`a$3985, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3985])*
        (TBgamma[1, Global`a$3988, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$3988] - TBgamma[1, Global`a$3991, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3991]) + 
       2*(TBgamma[0, Global`d1, Global`a$3958]*TBgamma[2, Global`a$3958, 
           Global`d2] - TBgamma[0, Global`a$3961, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3961])*
        (TBgamma[0, Global`d3, Global`a$3964]*TBgamma[2, Global`a$3964, 
           Global`d4] - TBgamma[0, Global`a$3967, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3967]) - 
       (TBgamma[1, Global`d1, Global`a$3994]*TBgamma[2, Global`a$3994, 
           Global`d2] - TBgamma[1, Global`a$3997, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3997])*
        (TBgamma[1, Global`d3, Global`a$4000]*TBgamma[2, Global`a$4000, 
           Global`d4] - TBgamma[1, Global`a$4003, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4003]) - 
       (TBgamma[1, Global`d1, Global`a$4021]*TBgamma[2, Global`a$4021, 
           Global`d2] - TBgamma[1, Global`a$4018, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4018])*
        (TBgamma[1, Global`d3, Global`a$4027]*TBgamma[2, Global`a$4027, 
           Global`d4] - TBgamma[1, Global`a$4024, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4024]) - 
       (TBgamma[2, Global`a$4030, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$4030] - TBgamma[2, Global`a$4033, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4033])*
        (TBgamma[2, Global`a$4036, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$4036] - TBgamma[2, Global`a$4039, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4039]) + 
       2*(TBgamma[0, Global`d1, Global`a$3970]*TBgamma[3, Global`a$3970, 
           Global`d2] - TBgamma[0, Global`a$3973, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3973])*
        (TBgamma[0, Global`d3, Global`a$3976]*TBgamma[3, Global`a$3976, 
           Global`d4] - TBgamma[0, Global`a$3979, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3979]) - 
       (TBgamma[1, Global`d1, Global`a$4006]*TBgamma[3, Global`a$4006, 
           Global`d2] - TBgamma[1, Global`a$4009, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4009])*
        (TBgamma[1, Global`d3, Global`a$4012]*TBgamma[3, Global`a$4012, 
           Global`d4] - TBgamma[1, Global`a$4015, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4015]) - 
       (TBgamma[2, Global`d1, Global`a$4042]*TBgamma[3, Global`a$4042, 
           Global`d2] - TBgamma[2, Global`a$4045, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4045])*
        (TBgamma[2, Global`d3, Global`a$4048]*TBgamma[3, Global`a$4048, 
           Global`d4] - TBgamma[2, Global`a$4051, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4051]) - 
       (TBgamma[1, Global`d1, Global`a$4057]*TBgamma[3, Global`a$4057, 
           Global`d2] - TBgamma[1, Global`a$4054, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4054])*
        (TBgamma[1, Global`d3, Global`a$4063]*TBgamma[3, Global`a$4063, 
           Global`d4] - TBgamma[1, Global`a$4060, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4060]) - 
       (TBgamma[2, Global`d1, Global`a$4069]*TBgamma[3, Global`a$4069, 
           Global`d2] - TBgamma[2, Global`a$4066, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4066])*
        (TBgamma[2, Global`d3, Global`a$4075]*TBgamma[3, Global`a$4075, 
           Global`d4] - TBgamma[2, Global`a$4072, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4072]) - 
       (TBgamma[3, Global`a$4078, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$4078] - TBgamma[3, Global`a$4081, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4081])*
        (TBgamma[3, Global`a$4084, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$4084] - TBgamma[3, Global`a$4087, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4087])) + 
     9*(2*(TBgamma[0, Global`d1, Global`a$4090]*TBgamma[1, Global`a$4090, 
           Global`d2] - TBgamma[0, Global`a$4093, Global`d2]*
          TBgamma[1, Global`d1, Global`a$4093])*
        (TBgamma[0, Global`d3, Global`a$4096]*TBgamma[1, Global`a$4096, 
           Global`d4] - TBgamma[0, Global`a$4099, Global`d4]*
          TBgamma[1, Global`d3, Global`a$4099]) - 
       (TBgamma[1, Global`a$4126, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$4126] - TBgamma[1, Global`a$4129, Global`d2]*
          TBgamma[1, Global`d1, Global`a$4129])*
        (TBgamma[1, Global`a$4132, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$4132] - TBgamma[1, Global`a$4135, Global`d4]*
          TBgamma[1, Global`d3, Global`a$4135]) + 
       2*(TBgamma[0, Global`d1, Global`a$4102]*TBgamma[2, Global`a$4102, 
           Global`d2] - TBgamma[0, Global`a$4105, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4105])*
        (TBgamma[0, Global`d3, Global`a$4108]*TBgamma[2, Global`a$4108, 
           Global`d4] - TBgamma[0, Global`a$4111, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4111]) - 
       (TBgamma[1, Global`d1, Global`a$4138]*TBgamma[2, Global`a$4138, 
           Global`d2] - TBgamma[1, Global`a$4141, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4141])*
        (TBgamma[1, Global`d3, Global`a$4144]*TBgamma[2, Global`a$4144, 
           Global`d4] - TBgamma[1, Global`a$4147, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4147]) - 
       (TBgamma[1, Global`d1, Global`a$4166]*TBgamma[2, Global`a$4166, 
           Global`d2] - TBgamma[1, Global`a$4163, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4163])*
        (TBgamma[1, Global`d3, Global`a$4174]*TBgamma[2, Global`a$4174, 
           Global`d4] - TBgamma[1, Global`a$4171, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4171]) - 
       (TBgamma[2, Global`a$4177, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$4177] - TBgamma[2, Global`a$4180, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4180])*
        (TBgamma[2, Global`a$4183, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$4183] - TBgamma[2, Global`a$4186, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4186]) + 
       2*(TBgamma[0, Global`d1, Global`a$4114]*TBgamma[3, Global`a$4114, 
           Global`d2] - TBgamma[0, Global`a$4117, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4117])*
        (TBgamma[0, Global`d3, Global`a$4120]*TBgamma[3, Global`a$4120, 
           Global`d4] - TBgamma[0, Global`a$4123, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4123]) - 
       (TBgamma[1, Global`d1, Global`a$4151]*TBgamma[3, Global`a$4151, 
           Global`d2] - TBgamma[1, Global`a$4154, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4154])*
        (TBgamma[1, Global`d3, Global`a$4157]*TBgamma[3, Global`a$4157, 
           Global`d4] - TBgamma[1, Global`a$4160, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4160]) - 
       (TBgamma[2, Global`d1, Global`a$4189]*TBgamma[3, Global`a$4189, 
           Global`d2] - TBgamma[2, Global`a$4192, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4192])*
        (TBgamma[2, Global`d3, Global`a$4196]*TBgamma[3, Global`a$4196, 
           Global`d4] - TBgamma[2, Global`a$4199, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4199]) - 
       (TBgamma[1, Global`d1, Global`a$4205]*TBgamma[3, Global`a$4205, 
           Global`d2] - TBgamma[1, Global`a$4202, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4202])*
        (TBgamma[1, Global`d3, Global`a$4212]*TBgamma[3, Global`a$4212, 
           Global`d4] - TBgamma[1, Global`a$4209, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4209]) - 
       (TBgamma[2, Global`d1, Global`a$4218]*TBgamma[3, Global`a$4218, 
           Global`d2] - TBgamma[2, Global`a$4215, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4215])*
        (TBgamma[2, Global`d3, Global`a$4224]*TBgamma[3, Global`a$4224, 
           Global`d4] - TBgamma[2, Global`a$4221, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4221]) - 
       (TBgamma[3, Global`a$4227, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$4227] - TBgamma[3, Global`a$4230, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4230])*
        (TBgamma[3, Global`a$4233, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$4233] - TBgamma[3, Global`a$4236, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4236]))*TBT[Global`flavor, 
       Global`af$4239, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$4239, Global`F3, Global`F4]) + 2*Global`Nc*Global`Nf*
    TBT[Global`color, Global`ac$4549, Global`A1, Global`A2]*
    TBT[Global`color, Global`ac$4549, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (2*(TBgamma[0, Global`d1, Global`a$4255]*TBgamma[1, Global`a$4255, 
           Global`d2] - TBgamma[0, Global`a$4258, Global`d2]*
          TBgamma[1, Global`d1, Global`a$4258])*
        (TBgamma[0, Global`d3, Global`a$4261]*TBgamma[1, Global`a$4261, 
           Global`d4] - TBgamma[0, Global`a$4264, Global`d4]*
          TBgamma[1, Global`d3, Global`a$4264]) - 
       (TBgamma[1, Global`a$4292, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$4292] - TBgamma[1, Global`a$4295, Global`d2]*
          TBgamma[1, Global`d1, Global`a$4295])*
        (TBgamma[1, Global`a$4300, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$4300] - TBgamma[1, Global`a$4303, Global`d4]*
          TBgamma[1, Global`d3, Global`a$4303]) + 
       2*(TBgamma[0, Global`d1, Global`a$4267]*TBgamma[2, Global`a$4267, 
           Global`d2] - TBgamma[0, Global`a$4270, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4270])*
        (TBgamma[0, Global`d3, Global`a$4274]*TBgamma[2, Global`a$4274, 
           Global`d4] - TBgamma[0, Global`a$4277, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4277]) - 
       (TBgamma[1, Global`d1, Global`a$4306]*TBgamma[2, Global`a$4306, 
           Global`d2] - TBgamma[1, Global`a$4309, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4309])*
        (TBgamma[1, Global`d3, Global`a$4313]*TBgamma[2, Global`a$4313, 
           Global`d4] - TBgamma[1, Global`a$4316, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4316]) - 
       (TBgamma[1, Global`d1, Global`a$4334]*TBgamma[2, Global`a$4334, 
           Global`d2] - TBgamma[1, Global`a$4331, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4331])*
        (TBgamma[1, Global`d3, Global`a$4340]*TBgamma[2, Global`a$4340, 
           Global`d4] - TBgamma[1, Global`a$4337, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4337]) - 
       (TBgamma[2, Global`a$4343, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$4343] - TBgamma[2, Global`a$4347, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4347])*
        (TBgamma[2, Global`a$4350, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$4350] - TBgamma[2, Global`a$4353, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4353]) + 
       2*(TBgamma[0, Global`d1, Global`a$4280]*TBgamma[3, Global`a$4280, 
           Global`d2] - TBgamma[0, Global`a$4283, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4283])*
        (TBgamma[0, Global`d3, Global`a$4286]*TBgamma[3, Global`a$4286, 
           Global`d4] - TBgamma[0, Global`a$4289, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4289]) - 
       (TBgamma[1, Global`d1, Global`a$4319]*TBgamma[3, Global`a$4319, 
           Global`d2] - TBgamma[1, Global`a$4322, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4322])*
        (TBgamma[1, Global`d3, Global`a$4325]*TBgamma[3, Global`a$4325, 
           Global`d4] - TBgamma[1, Global`a$4328, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4328]) - 
       (TBgamma[2, Global`d1, Global`a$4356]*TBgamma[3, Global`a$4356, 
           Global`d2] - TBgamma[2, Global`a$4359, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4359])*
        (TBgamma[2, Global`d3, Global`a$4362]*TBgamma[3, Global`a$4362, 
           Global`d4] - TBgamma[2, Global`a$4365, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4365]) - 
       (TBgamma[1, Global`d1, Global`a$4371]*TBgamma[3, Global`a$4371, 
           Global`d2] - TBgamma[1, Global`a$4368, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4368])*
        (TBgamma[1, Global`d3, Global`a$4377]*TBgamma[3, Global`a$4377, 
           Global`d4] - TBgamma[1, Global`a$4374, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4374]) - 
       (TBgamma[2, Global`d1, Global`a$4383]*TBgamma[3, Global`a$4383, 
           Global`d2] - TBgamma[2, Global`a$4380, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4380])*
        (TBgamma[2, Global`d3, Global`a$4389]*TBgamma[3, Global`a$4389, 
           Global`d4] - TBgamma[2, Global`a$4386, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4386]) - 
       (TBgamma[3, Global`a$4392, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$4392] - TBgamma[3, Global`a$4395, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4395])*
        (TBgamma[3, Global`a$4398, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$4398] - TBgamma[3, Global`a$4401, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4401])) + 
     9*(2*(TBgamma[0, Global`d1, Global`a$4404]*TBgamma[1, Global`a$4404, 
           Global`d2] - TBgamma[0, Global`a$4407, Global`d2]*
          TBgamma[1, Global`d1, Global`a$4407])*
        (TBgamma[0, Global`d3, Global`a$4410]*TBgamma[1, Global`a$4410, 
           Global`d4] - TBgamma[0, Global`a$4413, Global`d4]*
          TBgamma[1, Global`d3, Global`a$4413]) - 
       (TBgamma[1, Global`a$4440, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$4440] - TBgamma[1, Global`a$4443, Global`d2]*
          TBgamma[1, Global`d1, Global`a$4443])*
        (TBgamma[1, Global`a$4446, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$4446] - TBgamma[1, Global`a$4449, Global`d4]*
          TBgamma[1, Global`d3, Global`a$4449]) + 
       2*(TBgamma[0, Global`d1, Global`a$4416]*TBgamma[2, Global`a$4416, 
           Global`d2] - TBgamma[0, Global`a$4419, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4419])*
        (TBgamma[0, Global`d3, Global`a$4422]*TBgamma[2, Global`a$4422, 
           Global`d4] - TBgamma[0, Global`a$4425, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4425]) - 
       (TBgamma[1, Global`d1, Global`a$4452]*TBgamma[2, Global`a$4452, 
           Global`d2] - TBgamma[1, Global`a$4455, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4455])*
        (TBgamma[1, Global`d3, Global`a$4458]*TBgamma[2, Global`a$4458, 
           Global`d4] - TBgamma[1, Global`a$4461, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4461]) - 
       (TBgamma[1, Global`d1, Global`a$4479]*TBgamma[2, Global`a$4479, 
           Global`d2] - TBgamma[1, Global`a$4476, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4476])*
        (TBgamma[1, Global`d3, Global`a$4485]*TBgamma[2, Global`a$4485, 
           Global`d4] - TBgamma[1, Global`a$4482, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4482]) - 
       (TBgamma[2, Global`a$4488, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$4488] - TBgamma[2, Global`a$4492, Global`d2]*
          TBgamma[2, Global`d1, Global`a$4492])*
        (TBgamma[2, Global`a$4495, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$4495] - TBgamma[2, Global`a$4498, Global`d4]*
          TBgamma[2, Global`d3, Global`a$4498]) + 
       2*(TBgamma[0, Global`d1, Global`a$4428]*TBgamma[3, Global`a$4428, 
           Global`d2] - TBgamma[0, Global`a$4431, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4431])*
        (TBgamma[0, Global`d3, Global`a$4434]*TBgamma[3, Global`a$4434, 
           Global`d4] - TBgamma[0, Global`a$4437, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4437]) - 
       (TBgamma[1, Global`d1, Global`a$4464]*TBgamma[3, Global`a$4464, 
           Global`d2] - TBgamma[1, Global`a$4467, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4467])*
        (TBgamma[1, Global`d3, Global`a$4470]*TBgamma[3, Global`a$4470, 
           Global`d4] - TBgamma[1, Global`a$4473, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4473]) - 
       (TBgamma[2, Global`d1, Global`a$4501]*TBgamma[3, Global`a$4501, 
           Global`d2] - TBgamma[2, Global`a$4504, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4504])*
        (TBgamma[2, Global`d3, Global`a$4507]*TBgamma[3, Global`a$4507, 
           Global`d4] - TBgamma[2, Global`a$4510, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4510]) - 
       (TBgamma[1, Global`d1, Global`a$4516]*TBgamma[3, Global`a$4516, 
           Global`d2] - TBgamma[1, Global`a$4513, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4513])*
        (TBgamma[1, Global`d3, Global`a$4522]*TBgamma[3, Global`a$4522, 
           Global`d4] - TBgamma[1, Global`a$4519, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4519]) - 
       (TBgamma[2, Global`d1, Global`a$4528]*TBgamma[3, Global`a$4528, 
           Global`d2] - TBgamma[2, Global`a$4525, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4525])*
        (TBgamma[2, Global`d3, Global`a$4534]*TBgamma[3, Global`a$4534, 
           Global`d4] - TBgamma[2, Global`a$4531, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4531]) - 
       (TBgamma[3, Global`a$4537, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$4537] - TBgamma[3, Global`a$4540, Global`d2]*
          TBgamma[3, Global`d1, Global`a$4540])*
        (TBgamma[3, Global`a$4543, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$4543] - TBgamma[3, Global`a$4546, Global`d4]*
          TBgamma[3, Global`d3, Global`a$4546]))*TBT[Global`flavor, 
       Global`af$4552, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$4552, Global`F3, Global`F4]) - 
   24*Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     9*TBT[Global`flavor, Global`f$3911, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3911, Global`F3, Global`F4]) - 
   48*Global`Nc*Global`Nf*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4] - TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4])*TBT[Global`color, Global`a$3927, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$3927, Global`A3, 
     Global`A4]*(4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     9*TBT[Global`flavor, Global`f$3930, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3930, Global`F3, Global`F4]))/
  (256*Global`Nc^3*(9 - 8*Global`Nf)*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
 (-3*(-((1 + Global`Nc*(-2 + Global`Nf^2))*TBdeltaFund[Global`color, 
       Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
      (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
        TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$2363]*TBgamma[0, Global`d3, 
         Global`dc$2366]*TBgamma5[Global`dc$2363, Global`d2]*
        TBgamma5[Global`dc$2366, Global`d4])) + 
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$2382, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2382, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2382, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2382, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$2382, 0]*TBgamma[0, Global`d1, 
           Global`dc$2385]) + TBgamma[Global`i$2382, Global`d1, 
         Global`dc$2385])*(-(TBdeltaLorentz[Global`i$2382, 0]*
          TBgamma[0, Global`d3, Global`dc$2388]) + TBgamma[Global`i$2382, 
         Global`d3, Global`dc$2388])*TBgamma5[Global`dc$2385, Global`d2]*
       TBgamma5[Global`dc$2388, Global`d4]) - Global`Nc*(-2 + Global`Nf)*
     Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$2517]*TBgamma[0, Global`d3, 
        Global`dc$2520]*TBgamma5[Global`dc$2517, Global`d2]*
       TBgamma5[Global`dc$2520, Global`d4]) + Global`Nc*(-2 + Global`Nf)*
     Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$2657]*TBgamma[0, Global`d3, 
        Global`dc$2660]*TBgamma5[Global`dc$2657, Global`d2]*
       TBgamma5[Global`dc$2660, Global`d4]) - 
    2*Global`Nc*(TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$2451]*TBgamma[0, Global`d3, 
        Global`dc$2454]*TBgamma5[Global`dc$2451, Global`d2]*
       TBgamma5[Global`dc$2454, Global`d4])*TBT[Global`color, Global`a$2457, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2457, Global`A3, 
      Global`A4] + 2*Global`Nc*(TBdeltaFund[Global`flavor, Global`F1, 
       Global`F2] - TBdeltaFund[Global`flavor, Global`F1, 3]*
       TBdeltaFund[Global`flavor, Global`F2, 3])*
     (TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$2473, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2473, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2473, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2473, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$2473, 0]*TBgamma[0, Global`d1, 
           Global`dc$2476]) + TBgamma[Global`i$2473, Global`d1, 
         Global`dc$2476])*(-(TBdeltaLorentz[Global`i$2473, 0]*
          TBgamma[0, Global`d3, Global`dc$2479]) + TBgamma[Global`i$2473, 
         Global`d3, Global`dc$2479])*TBgamma5[Global`dc$2476, Global`d2]*
       TBgamma5[Global`dc$2479, Global`d4])*TBT[Global`color, Global`a$2482, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2482, Global`A3, 
      Global`A4]))/(64*Global`Nc^3*(-2 + Global`Nf)*(-1 + Global`Nf)*
   Global`Nf), 
 -1/64*((3*TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
        TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$3481]*TBgamma[0, Global`d3, 
         Global`dc$3484]*TBgamma5[Global`dc$3481, Global`d2]*
        TBgamma5[Global`dc$3484, Global`d4]))/((-2 + Global`Nf)*Global`Nf) - 
    ((-1 + Global`Nc*(-2 + Global`Nf^2))*TBdeltaFund[Global`color, Global`A1, 
       Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
      (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*((-(TBdeltaLorentz[Global`i$3500, 0]*
           TBgamma[0, Global`d1, Global`d2]) + TBgamma[Global`i$3500, 
          Global`d1, Global`d2])*(-(TBdeltaLorentz[Global`i$3500, 0]*
           TBgamma[0, Global`d3, Global`d4]) + TBgamma[Global`i$3500, 
          Global`d3, Global`d4]) + 
       (-(TBdeltaLorentz[Global`i$3500, 0]*TBgamma[0, Global`d1, 
            Global`dc$3503]) + TBgamma[Global`i$3500, Global`d1, 
          Global`dc$3503])*(-(TBdeltaLorentz[Global`i$3500, 0]*
           TBgamma[0, Global`d3, Global`dc$3506]) + TBgamma[Global`i$3500, 
          Global`d3, Global`dc$3506])*TBgamma5[Global`dc$3503, Global`d2]*
        TBgamma5[Global`dc$3506, Global`d4]))/((-2 + Global`Nf)*Global`Nf) + 
    (3*Global`Nc^2*TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
      TBdeltaFund[Global`flavor, Global`F4, 3]*
      (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$3635]*TBgamma[0, Global`d3, 
         Global`dc$3638]*TBgamma5[Global`dc$3635, Global`d2]*
        TBgamma5[Global`dc$3638, Global`d4]))/(-2 + Global`Nc) + 
    Global`Nc*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$3793, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$3793, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$3793, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$3793, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$3793, 0]*TBgamma[0, Global`d1, 
           Global`dc$3796]) + TBgamma[Global`i$3793, Global`d1, 
         Global`dc$3796])*(-(TBdeltaLorentz[Global`i$3793, 0]*
          TBgamma[0, Global`d3, Global`dc$3799]) + TBgamma[Global`i$3793, 
         Global`d3, Global`dc$3799])*TBgamma5[Global`dc$3796, Global`d2]*
       TBgamma5[Global`dc$3799, Global`d4]) + 
    (6*Global`Nc*(TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
        TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$3569]*TBgamma[0, Global`d3, 
         Global`dc$3572]*TBgamma5[Global`dc$3569, Global`d2]*
        TBgamma5[Global`dc$3572, Global`d4])*TBT[Global`color, Global`a$3575, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$3575, Global`A3, 
       Global`A4])/((-2 + Global`Nf)*Global`Nf) + 
    (2*Global`Nc*(TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*((-(TBdeltaLorentz[Global`i$3591, 0]*
           TBgamma[0, Global`d1, Global`d2]) + TBgamma[Global`i$3591, 
          Global`d1, Global`d2])*(-(TBdeltaLorentz[Global`i$3591, 0]*
           TBgamma[0, Global`d3, Global`d4]) + TBgamma[Global`i$3591, 
          Global`d3, Global`d4]) + 
       (-(TBdeltaLorentz[Global`i$3591, 0]*TBgamma[0, Global`d1, 
            Global`dc$3594]) + TBgamma[Global`i$3591, Global`d1, 
          Global`dc$3594])*(-(TBdeltaLorentz[Global`i$3591, 0]*
           TBgamma[0, Global`d3, Global`dc$3597]) + TBgamma[Global`i$3591, 
          Global`d3, Global`dc$3597])*TBgamma5[Global`dc$3594, Global`d2]*
        TBgamma5[Global`dc$3597, Global`d4])*TBT[Global`color, Global`a$3600, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$3600, Global`A3, 
       Global`A4])/((-2 + Global`Nf)*Global`Nf) - 
    (4*Global`Nc^2*TBdeltaFund[Global`flavor, Global`F1, 3]*
      TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
       Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
      ((-(TBdeltaLorentz[Global`i$3679, 0]*TBgamma[0, Global`d1, 
            Global`d2]) + TBgamma[Global`i$3679, Global`d1, Global`d2])*
        (-(TBdeltaLorentz[Global`i$3679, 0]*TBgamma[0, Global`d3, 
            Global`d4]) + TBgamma[Global`i$3679, Global`d3, Global`d4]) + 
       (-(TBdeltaLorentz[Global`i$3679, 0]*TBgamma[0, Global`d1, 
            Global`dc$3682]) + TBgamma[Global`i$3679, Global`d1, 
          Global`dc$3682])*(-(TBdeltaLorentz[Global`i$3679, 0]*
           TBgamma[0, Global`d3, Global`dc$3685]) + TBgamma[Global`i$3679, 
          Global`d3, Global`dc$3685])*TBgamma5[Global`dc$3682, Global`d2]*
        TBgamma5[Global`dc$3685, Global`d4])*TBT[Global`color, Global`a$3688, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$3688, Global`A3, 
       Global`A4])/(-2 + Global`Nc))/(Global`Nc^3*(-1 + Global`Nf)), 
 (3*(-8*(-1 + Global`Nc^2)*Global`Nf^2*(-9 + 8*Global`Nf)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
    8*Global`Nc^2*Global`Nf*(2 + Global`Nf)*(-9 + 8*Global`Nf)*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1799]*TBgamma[0, Global`d3, 
        Global`dc$1802]*TBgamma5[Global`dc$1799, Global`d2]*
       TBgamma5[Global`dc$1802, Global`d4])*TBT[Global`color, Global`a$1805, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1805, Global`A3, 
      Global`A4] + 8*Global`Nc^2*(9 - 8*Global`Nf)*Global`Nf^2*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     ((-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1931, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1931, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d1, 
           Global`dc$1934]) + TBgamma[Global`i$1931, Global`d1, 
         Global`dc$1934])*(-(TBdeltaLorentz[Global`i$1931, 0]*
          TBgamma[0, Global`d3, Global`dc$1937]) + TBgamma[Global`i$1931, 
         Global`d3, Global`dc$1937])*TBgamma5[Global`dc$1934, Global`d2]*
       TBgamma5[Global`dc$1937, Global`d4])*TBT[Global`color, Global`a$1940, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1940, Global`A3, 
      Global`A4] + 16*Global`Nc*Global`Nf^2*(-9 + 8*Global`Nf)*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$1994, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$1994, Global`A3, Global`A4] - 
    8*Global`Nc^2*(18 - 34*Global`Nf - 9*Global`Nf^2 + 8*Global`Nf^3)*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2092]*TBgamma[0, Global`d3, 
        Global`dc$2095]*TBgamma5[Global`dc$2092, Global`d2]*
       TBgamma5[Global`dc$2095, Global`d4])*TBT[Global`color, Global`a$2098, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2098, Global`A3, 
      Global`A4] - (1 - Global`Nc^2)*Global`Nf*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$2221]*TBgamma[1, Global`a$2221, 
            Global`d2] - TBgamma[0, Global`a$2224, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2224])*
         (TBgamma[0, Global`d3, Global`a$2227]*TBgamma[1, Global`a$2227, 
            Global`d4] - TBgamma[0, Global`a$2230, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2230]) - 
        (TBgamma[1, Global`a$2258, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2258] - TBgamma[1, Global`a$2261, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2261])*
         (TBgamma[1, Global`a$2264, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2264] - TBgamma[1, Global`a$2267, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2267]) + 
        2*(TBgamma[0, Global`d1, Global`a$2233]*TBgamma[2, Global`a$2233, 
            Global`d2] - TBgamma[0, Global`a$2236, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2236])*
         (TBgamma[0, Global`d3, Global`a$2239]*TBgamma[2, Global`a$2239, 
            Global`d4] - TBgamma[0, Global`a$2242, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2242]) - 
        (TBgamma[1, Global`d1, Global`a$2270]*TBgamma[2, Global`a$2270, 
            Global`d2] - TBgamma[1, Global`a$2273, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2273])*
         (TBgamma[1, Global`d3, Global`a$2276]*TBgamma[2, Global`a$2276, 
            Global`d4] - TBgamma[1, Global`a$2279, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2279]) - 
        (TBgamma[1, Global`d1, Global`a$2297]*TBgamma[2, Global`a$2297, 
            Global`d2] - TBgamma[1, Global`a$2294, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2294])*
         (TBgamma[1, Global`d3, Global`a$2303]*TBgamma[2, Global`a$2303, 
            Global`d4] - TBgamma[1, Global`a$2300, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2300]) - 
        (TBgamma[2, Global`a$2306, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2306] - TBgamma[2, Global`a$2309, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2309])*
         (TBgamma[2, Global`a$2312, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2312] - TBgamma[2, Global`a$2315, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2315]) + 
        2*(TBgamma[0, Global`d1, Global`a$2246]*TBgamma[3, Global`a$2246, 
            Global`d2] - TBgamma[0, Global`a$2249, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2249])*
         (TBgamma[0, Global`d3, Global`a$2252]*TBgamma[3, Global`a$2252, 
            Global`d4] - TBgamma[0, Global`a$2255, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2255]) - 
        (TBgamma[1, Global`d1, Global`a$2282]*TBgamma[3, Global`a$2282, 
            Global`d2] - TBgamma[1, Global`a$2285, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2285])*
         (TBgamma[1, Global`d3, Global`a$2288]*TBgamma[3, Global`a$2288, 
            Global`d4] - TBgamma[1, Global`a$2291, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2291]) - 
        (TBgamma[2, Global`d1, Global`a$2318]*TBgamma[3, Global`a$2318, 
            Global`d2] - TBgamma[2, Global`a$2321, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2321])*
         (TBgamma[2, Global`d3, Global`a$2324]*TBgamma[3, Global`a$2324, 
            Global`d4] - TBgamma[2, Global`a$2327, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2327]) - 
        (TBgamma[1, Global`d1, Global`a$2333]*TBgamma[3, Global`a$2333, 
            Global`d2] - TBgamma[1, Global`a$2330, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2330])*
         (TBgamma[1, Global`d3, Global`a$2339]*TBgamma[3, Global`a$2339, 
            Global`d4] - TBgamma[1, Global`a$2336, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2336]) - 
        (TBgamma[2, Global`d1, Global`a$2345]*TBgamma[3, Global`a$2345, 
            Global`d2] - TBgamma[2, Global`a$2342, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2342])*
         (TBgamma[2, Global`d3, Global`a$2351]*TBgamma[3, Global`a$2351, 
            Global`d4] - TBgamma[2, Global`a$2348, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2348]) - 
        (TBgamma[3, Global`a$2354, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2354] - TBgamma[3, Global`a$2357, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2357])*
         (TBgamma[3, Global`a$2360, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2360] - TBgamma[3, Global`a$2363, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2363])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$2366]*TBgamma[1, Global`a$2366, 
            Global`d2] - TBgamma[0, Global`a$2369, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2369])*
         (TBgamma[0, Global`d3, Global`a$2372]*TBgamma[1, Global`a$2372, 
            Global`d4] - TBgamma[0, Global`a$2375, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2375]) - 
        (TBgamma[1, Global`a$2402, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2402] - TBgamma[1, Global`a$2405, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2405])*
         (TBgamma[1, Global`a$2408, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2408] - TBgamma[1, Global`a$2411, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2411]) + 
        2*(TBgamma[0, Global`d1, Global`a$2378]*TBgamma[2, Global`a$2378, 
            Global`d2] - TBgamma[0, Global`a$2381, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2381])*
         (TBgamma[0, Global`d3, Global`a$2384]*TBgamma[2, Global`a$2384, 
            Global`d4] - TBgamma[0, Global`a$2387, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2387]) - 
        (TBgamma[1, Global`d1, Global`a$2414]*TBgamma[2, Global`a$2414, 
            Global`d2] - TBgamma[1, Global`a$2417, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2417])*
         (TBgamma[1, Global`d3, Global`a$2420]*TBgamma[2, Global`a$2420, 
            Global`d4] - TBgamma[1, Global`a$2423, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2423]) - 
        (TBgamma[1, Global`d1, Global`a$2441]*TBgamma[2, Global`a$2441, 
            Global`d2] - TBgamma[1, Global`a$2438, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2438])*
         (TBgamma[1, Global`d3, Global`a$2447]*TBgamma[2, Global`a$2447, 
            Global`d4] - TBgamma[1, Global`a$2444, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2444]) - 
        (TBgamma[2, Global`a$2450, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2450] - TBgamma[2, Global`a$2453, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2453])*
         (TBgamma[2, Global`a$2456, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2456] - TBgamma[2, Global`a$2459, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2459]) + 
        2*(TBgamma[0, Global`d1, Global`a$2390]*TBgamma[3, Global`a$2390, 
            Global`d2] - TBgamma[0, Global`a$2393, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2393])*
         (TBgamma[0, Global`d3, Global`a$2396]*TBgamma[3, Global`a$2396, 
            Global`d4] - TBgamma[0, Global`a$2399, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2399]) - 
        (TBgamma[1, Global`d1, Global`a$2426]*TBgamma[3, Global`a$2426, 
            Global`d2] - TBgamma[1, Global`a$2429, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2429])*
         (TBgamma[1, Global`d3, Global`a$2432]*TBgamma[3, Global`a$2432, 
            Global`d4] - TBgamma[1, Global`a$2435, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2435]) - 
        (TBgamma[2, Global`d1, Global`a$2462]*TBgamma[3, Global`a$2462, 
            Global`d2] - TBgamma[2, Global`a$2465, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2465])*
         (TBgamma[2, Global`d3, Global`a$2468]*TBgamma[3, Global`a$2468, 
            Global`d4] - TBgamma[2, Global`a$2471, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2471]) - 
        (TBgamma[1, Global`d1, Global`a$2477]*TBgamma[3, Global`a$2477, 
            Global`d2] - TBgamma[1, Global`a$2474, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2474])*
         (TBgamma[1, Global`d3, Global`a$2483]*TBgamma[3, Global`a$2483, 
            Global`d4] - TBgamma[1, Global`a$2480, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2480]) - 
        (TBgamma[2, Global`d1, Global`a$2489]*TBgamma[3, Global`a$2489, 
            Global`d2] - TBgamma[2, Global`a$2486, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2486])*
         (TBgamma[2, Global`d3, Global`a$2495]*TBgamma[3, Global`a$2495, 
            Global`d4] - TBgamma[2, Global`a$2492, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2492]) - 
        (TBgamma[3, Global`a$2498, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2498] - TBgamma[3, Global`a$2501, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2501])*
         (TBgamma[3, Global`a$2504, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2504] - TBgamma[3, Global`a$2507, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2507]))*TBT[Global`flavor, 
        Global`af$2510, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$2510, Global`F3, Global`F4]) - 2*Global`Nc*Global`Nf*
     TBT[Global`color, Global`ac$2816, Global`A1, Global`A2]*
     TBT[Global`color, Global`ac$2816, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$2526]*TBgamma[1, Global`a$2526, 
            Global`d2] - TBgamma[0, Global`a$2529, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2529])*
         (TBgamma[0, Global`d3, Global`a$2532]*TBgamma[1, Global`a$2532, 
            Global`d4] - TBgamma[0, Global`a$2535, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2535]) - 
        (TBgamma[1, Global`a$2562, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2562] - TBgamma[1, Global`a$2565, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2565])*
         (TBgamma[1, Global`a$2568, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2568] - TBgamma[1, Global`a$2571, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2571]) + 
        2*(TBgamma[0, Global`d1, Global`a$2538]*TBgamma[2, Global`a$2538, 
            Global`d2] - TBgamma[0, Global`a$2541, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2541])*
         (TBgamma[0, Global`d3, Global`a$2544]*TBgamma[2, Global`a$2544, 
            Global`d4] - TBgamma[0, Global`a$2547, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2547]) - 
        (TBgamma[1, Global`d1, Global`a$2574]*TBgamma[2, Global`a$2574, 
            Global`d2] - TBgamma[1, Global`a$2577, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2577])*
         (TBgamma[1, Global`d3, Global`a$2580]*TBgamma[2, Global`a$2580, 
            Global`d4] - TBgamma[1, Global`a$2583, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2583]) - 
        (TBgamma[1, Global`d1, Global`a$2601]*TBgamma[2, Global`a$2601, 
            Global`d2] - TBgamma[1, Global`a$2598, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2598])*
         (TBgamma[1, Global`d3, Global`a$2607]*TBgamma[2, Global`a$2607, 
            Global`d4] - TBgamma[1, Global`a$2604, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2604]) - 
        (TBgamma[2, Global`a$2610, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2610] - TBgamma[2, Global`a$2613, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2613])*
         (TBgamma[2, Global`a$2616, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2616] - TBgamma[2, Global`a$2619, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2619]) + 
        2*(TBgamma[0, Global`d1, Global`a$2550]*TBgamma[3, Global`a$2550, 
            Global`d2] - TBgamma[0, Global`a$2553, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2553])*
         (TBgamma[0, Global`d3, Global`a$2556]*TBgamma[3, Global`a$2556, 
            Global`d4] - TBgamma[0, Global`a$2559, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2559]) - 
        (TBgamma[1, Global`d1, Global`a$2586]*TBgamma[3, Global`a$2586, 
            Global`d2] - TBgamma[1, Global`a$2589, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2589])*
         (TBgamma[1, Global`d3, Global`a$2592]*TBgamma[3, Global`a$2592, 
            Global`d4] - TBgamma[1, Global`a$2595, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2595]) - 
        (TBgamma[2, Global`d1, Global`a$2622]*TBgamma[3, Global`a$2622, 
            Global`d2] - TBgamma[2, Global`a$2625, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2625])*
         (TBgamma[2, Global`d3, Global`a$2628]*TBgamma[3, Global`a$2628, 
            Global`d4] - TBgamma[2, Global`a$2631, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2631]) - 
        (TBgamma[1, Global`d1, Global`a$2637]*TBgamma[3, Global`a$2637, 
            Global`d2] - TBgamma[1, Global`a$2634, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2634])*
         (TBgamma[1, Global`d3, Global`a$2644]*TBgamma[3, Global`a$2644, 
            Global`d4] - TBgamma[1, Global`a$2640, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2640]) - 
        (TBgamma[2, Global`d1, Global`a$2650]*TBgamma[3, Global`a$2650, 
            Global`d2] - TBgamma[2, Global`a$2647, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2647])*
         (TBgamma[2, Global`d3, Global`a$2656]*TBgamma[3, Global`a$2656, 
            Global`d4] - TBgamma[2, Global`a$2653, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2653]) - 
        (TBgamma[3, Global`a$2659, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2659] - TBgamma[3, Global`a$2662, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2662])*
         (TBgamma[3, Global`a$2665, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2665] - TBgamma[3, Global`a$2668, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2668])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$2671]*TBgamma[1, Global`a$2671, 
            Global`d2] - TBgamma[0, Global`a$2674, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2674])*
         (TBgamma[0, Global`d3, Global`a$2677]*TBgamma[1, Global`a$2677, 
            Global`d4] - TBgamma[0, Global`a$2680, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2680]) - 
        (TBgamma[1, Global`a$2707, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2707] - TBgamma[1, Global`a$2710, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2710])*
         (TBgamma[1, Global`a$2713, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2713] - TBgamma[1, Global`a$2716, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2716]) + 
        2*(TBgamma[0, Global`d1, Global`a$2683]*TBgamma[2, Global`a$2683, 
            Global`d2] - TBgamma[0, Global`a$2686, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2686])*
         (TBgamma[0, Global`d3, Global`a$2689]*TBgamma[2, Global`a$2689, 
            Global`d4] - TBgamma[0, Global`a$2692, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2692]) - 
        (TBgamma[1, Global`d1, Global`a$2719]*TBgamma[2, Global`a$2719, 
            Global`d2] - TBgamma[1, Global`a$2722, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2722])*
         (TBgamma[1, Global`d3, Global`a$2725]*TBgamma[2, Global`a$2725, 
            Global`d4] - TBgamma[1, Global`a$2728, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2728]) - 
        (TBgamma[1, Global`d1, Global`a$2746]*TBgamma[2, Global`a$2746, 
            Global`d2] - TBgamma[1, Global`a$2743, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2743])*
         (TBgamma[1, Global`d3, Global`a$2752]*TBgamma[2, Global`a$2752, 
            Global`d4] - TBgamma[1, Global`a$2749, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2749]) - 
        (TBgamma[2, Global`a$2755, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2755] - TBgamma[2, Global`a$2758, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2758])*
         (TBgamma[2, Global`a$2761, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2761] - TBgamma[2, Global`a$2764, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2764]) + 
        2*(TBgamma[0, Global`d1, Global`a$2695]*TBgamma[3, Global`a$2695, 
            Global`d2] - TBgamma[0, Global`a$2698, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2698])*
         (TBgamma[0, Global`d3, Global`a$2701]*TBgamma[3, Global`a$2701, 
            Global`d4] - TBgamma[0, Global`a$2704, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2704]) - 
        (TBgamma[1, Global`d1, Global`a$2731]*TBgamma[3, Global`a$2731, 
            Global`d2] - TBgamma[1, Global`a$2734, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2734])*
         (TBgamma[1, Global`d3, Global`a$2737]*TBgamma[3, Global`a$2737, 
            Global`d4] - TBgamma[1, Global`a$2740, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2740]) - 
        (TBgamma[2, Global`d1, Global`a$2767]*TBgamma[3, Global`a$2767, 
            Global`d2] - TBgamma[2, Global`a$2770, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2770])*
         (TBgamma[2, Global`d3, Global`a$2773]*TBgamma[3, Global`a$2773, 
            Global`d4] - TBgamma[2, Global`a$2776, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2776]) - 
        (TBgamma[1, Global`d1, Global`a$2782]*TBgamma[3, Global`a$2782, 
            Global`d2] - TBgamma[1, Global`a$2779, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2779])*
         (TBgamma[1, Global`d3, Global`a$2788]*TBgamma[3, Global`a$2788, 
            Global`d4] - TBgamma[1, Global`a$2785, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2785]) - 
        (TBgamma[2, Global`d1, Global`a$2794]*TBgamma[3, Global`a$2794, 
            Global`d2] - TBgamma[2, Global`a$2791, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2791])*
         (TBgamma[2, Global`d3, Global`a$2800]*TBgamma[3, Global`a$2800, 
            Global`d4] - TBgamma[2, Global`a$2797, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2797]) - 
        (TBgamma[3, Global`a$2803, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2803] - TBgamma[3, Global`a$2806, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2806])*
         (TBgamma[3, Global`a$2809, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2809] - TBgamma[3, Global`a$2813, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2813]))*TBT[Global`flavor, 
        Global`af$2819, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$2819, Global`F3, Global`F4]) + 8*(-1 + Global`Nc^2)*
     Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$2186, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$2186, Global`F3, Global`F4]) - 
    16*Global`Nc*Global`Nf*(TBdeltaDirac[Global`d1, Global`d2]*
       TBdeltaDirac[Global`d3, Global`d4] - TBgamma5[Global`d1, Global`d2]*
       TBgamma5[Global`d3, Global`d4])*TBT[Global`color, Global`a$2202, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2202, Global`A3, 
      Global`A4]*(4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$2205, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$2205, Global`F3, Global`F4])))/
  (128*Global`Nc^2*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
   (-2 + Global`Nf^2)), (-8*Global`Nc^2*(9 - 8*Global`Nf)*Global`Nf*
    (2 + Global`Nf)*(TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$2944, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$2944, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$2944, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$2944, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$2944, 0]*TBgamma[0, Global`d1, 
          Global`dc$2947]) + TBgamma[Global`i$2944, Global`d1, 
        Global`dc$2947])*(-(TBdeltaLorentz[Global`i$2944, 0]*
         TBgamma[0, Global`d3, Global`dc$2950]) + TBgamma[Global`i$2944, 
        Global`d3, Global`dc$2950])*TBgamma5[Global`dc$2947, Global`d2]*
      TBgamma5[Global`dc$2950, Global`d4])*TBT[Global`color, Global`a$2953, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$2953, Global`A3, 
     Global`A4] - 8*Global`Nc^2*(9 - 8*Global`Nf)*Global`Nf^2*
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
     Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
    TBdeltaFund[Global`flavor, Global`F4, 3]*
    ((-(TBdeltaLorentz[Global`i$3054, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$3054, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$3054, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$3054, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$3054, 0]*TBgamma[0, Global`d1, 
          Global`dc$3057]) + TBgamma[Global`i$3054, Global`d1, 
        Global`dc$3057])*(-(TBdeltaLorentz[Global`i$3054, 0]*
         TBgamma[0, Global`d3, Global`dc$3060]) + TBgamma[Global`i$3054, 
        Global`d3, Global`dc$3060])*TBgamma5[Global`dc$3057, Global`d2]*
      TBgamma5[Global`dc$3060, Global`d4])*TBT[Global`color, Global`a$3063, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$3063, Global`A3, 
     Global`A4] - 8*Global`Nc^2*(18 - 34*Global`Nf - 9*Global`Nf^2 + 
     8*Global`Nf^3)*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$3237, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$3237, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$3237, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$3237, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$3237, 0]*TBgamma[0, Global`d1, 
          Global`dc$3240]) + TBgamma[Global`i$3237, Global`d1, 
        Global`dc$3240])*(-(TBdeltaLorentz[Global`i$3237, 0]*
         TBgamma[0, Global`d3, Global`dc$3243]) + TBgamma[Global`i$3237, 
        Global`d3, Global`dc$3243])*TBgamma5[Global`dc$3240, Global`d2]*
      TBgamma5[Global`dc$3243, Global`d4])*TBT[Global`color, Global`a$3246, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$3246, Global`A3, 
     Global`A4] + (1 - Global`Nc^2)*Global`Nf*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (2*(TBgamma[0, Global`d1, Global`a$3344]*TBgamma[1, Global`a$3344, 
           Global`d2] - TBgamma[0, Global`a$3347, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3347])*
        (TBgamma[0, Global`d3, Global`a$3350]*TBgamma[1, Global`a$3350, 
           Global`d4] - TBgamma[0, Global`a$3353, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3353]) - 
       (TBgamma[1, Global`a$3381, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$3381] - TBgamma[1, Global`a$3384, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3384])*
        (TBgamma[1, Global`a$3387, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$3387] - TBgamma[1, Global`a$3390, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3390]) + 
       2*(TBgamma[0, Global`d1, Global`a$3356]*TBgamma[2, Global`a$3356, 
           Global`d2] - TBgamma[0, Global`a$3359, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3359])*
        (TBgamma[0, Global`d3, Global`a$3362]*TBgamma[2, Global`a$3362, 
           Global`d4] - TBgamma[0, Global`a$3365, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3365]) - 
       (TBgamma[1, Global`d1, Global`a$3393]*TBgamma[2, Global`a$3393, 
           Global`d2] - TBgamma[1, Global`a$3396, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3396])*
        (TBgamma[1, Global`d3, Global`a$3400]*TBgamma[2, Global`a$3400, 
           Global`d4] - TBgamma[1, Global`a$3403, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3403]) - 
       (TBgamma[1, Global`d1, Global`a$3421]*TBgamma[2, Global`a$3421, 
           Global`d2] - TBgamma[1, Global`a$3418, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3418])*
        (TBgamma[1, Global`d3, Global`a$3427]*TBgamma[2, Global`a$3427, 
           Global`d4] - TBgamma[1, Global`a$3424, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3424]) - 
       (TBgamma[2, Global`a$3430, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$3430] - TBgamma[2, Global`a$3433, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3433])*
        (TBgamma[2, Global`a$3436, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$3436] - TBgamma[2, Global`a$3439, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3439]) + 
       2*(TBgamma[0, Global`d1, Global`a$3368]*TBgamma[3, Global`a$3368, 
           Global`d2] - TBgamma[0, Global`a$3371, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3371])*
        (TBgamma[0, Global`d3, Global`a$3374]*TBgamma[3, Global`a$3374, 
           Global`d4] - TBgamma[0, Global`a$3377, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3377]) - 
       (TBgamma[1, Global`d1, Global`a$3406]*TBgamma[3, Global`a$3406, 
           Global`d2] - TBgamma[1, Global`a$3409, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3409])*
        (TBgamma[1, Global`d3, Global`a$3412]*TBgamma[3, Global`a$3412, 
           Global`d4] - TBgamma[1, Global`a$3415, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3415]) - 
       (TBgamma[2, Global`d1, Global`a$3442]*TBgamma[3, Global`a$3442, 
           Global`d2] - TBgamma[2, Global`a$3445, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3445])*
        (TBgamma[2, Global`d3, Global`a$3448]*TBgamma[3, Global`a$3448, 
           Global`d4] - TBgamma[2, Global`a$3451, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3451]) - 
       (TBgamma[1, Global`d1, Global`a$3457]*TBgamma[3, Global`a$3457, 
           Global`d2] - TBgamma[1, Global`a$3454, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3454])*
        (TBgamma[1, Global`d3, Global`a$3463]*TBgamma[3, Global`a$3463, 
           Global`d4] - TBgamma[1, Global`a$3460, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3460]) - 
       (TBgamma[2, Global`d1, Global`a$3469]*TBgamma[3, Global`a$3469, 
           Global`d2] - TBgamma[2, Global`a$3466, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3466])*
        (TBgamma[2, Global`d3, Global`a$3475]*TBgamma[3, Global`a$3475, 
           Global`d4] - TBgamma[2, Global`a$3472, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3472]) - 
       (TBgamma[3, Global`a$3478, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$3478] - TBgamma[3, Global`a$3481, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3481])*
        (TBgamma[3, Global`a$3484, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$3484] - TBgamma[3, Global`a$3487, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3487])) + 
     9*(2*(TBgamma[0, Global`d1, Global`a$3490]*TBgamma[1, Global`a$3490, 
           Global`d2] - TBgamma[0, Global`a$3493, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3493])*
        (TBgamma[0, Global`d3, Global`a$3496]*TBgamma[1, Global`a$3496, 
           Global`d4] - TBgamma[0, Global`a$3499, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3499]) - 
       (TBgamma[1, Global`a$3526, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$3526] - TBgamma[1, Global`a$3529, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3529])*
        (TBgamma[1, Global`a$3532, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$3532] - TBgamma[1, Global`a$3535, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3535]) + 
       2*(TBgamma[0, Global`d1, Global`a$3502]*TBgamma[2, Global`a$3502, 
           Global`d2] - TBgamma[0, Global`a$3505, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3505])*
        (TBgamma[0, Global`d3, Global`a$3508]*TBgamma[2, Global`a$3508, 
           Global`d4] - TBgamma[0, Global`a$3511, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3511]) - 
       (TBgamma[1, Global`d1, Global`a$3538]*TBgamma[2, Global`a$3538, 
           Global`d2] - TBgamma[1, Global`a$3541, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3541])*
        (TBgamma[1, Global`d3, Global`a$3544]*TBgamma[2, Global`a$3544, 
           Global`d4] - TBgamma[1, Global`a$3547, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3547]) - 
       (TBgamma[1, Global`d1, Global`a$3565]*TBgamma[2, Global`a$3565, 
           Global`d2] - TBgamma[1, Global`a$3562, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3562])*
        (TBgamma[1, Global`d3, Global`a$3571]*TBgamma[2, Global`a$3571, 
           Global`d4] - TBgamma[1, Global`a$3568, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3568]) - 
       (TBgamma[2, Global`a$3574, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$3574] - TBgamma[2, Global`a$3577, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3577])*
        (TBgamma[2, Global`a$3580, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$3580] - TBgamma[2, Global`a$3583, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3583]) + 
       2*(TBgamma[0, Global`d1, Global`a$3514]*TBgamma[3, Global`a$3514, 
           Global`d2] - TBgamma[0, Global`a$3517, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3517])*
        (TBgamma[0, Global`d3, Global`a$3520]*TBgamma[3, Global`a$3520, 
           Global`d4] - TBgamma[0, Global`a$3523, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3523]) - 
       (TBgamma[1, Global`d1, Global`a$3550]*TBgamma[3, Global`a$3550, 
           Global`d2] - TBgamma[1, Global`a$3553, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3553])*
        (TBgamma[1, Global`d3, Global`a$3556]*TBgamma[3, Global`a$3556, 
           Global`d4] - TBgamma[1, Global`a$3559, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3559]) - 
       (TBgamma[2, Global`d1, Global`a$3586]*TBgamma[3, Global`a$3586, 
           Global`d2] - TBgamma[2, Global`a$3589, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3589])*
        (TBgamma[2, Global`d3, Global`a$3592]*TBgamma[3, Global`a$3592, 
           Global`d4] - TBgamma[2, Global`a$3595, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3595]) - 
       (TBgamma[1, Global`d1, Global`a$3601]*TBgamma[3, Global`a$3601, 
           Global`d2] - TBgamma[1, Global`a$3598, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3598])*
        (TBgamma[1, Global`d3, Global`a$3607]*TBgamma[3, Global`a$3607, 
           Global`d4] - TBgamma[1, Global`a$3604, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3604]) - 
       (TBgamma[2, Global`d1, Global`a$3613]*TBgamma[3, Global`a$3613, 
           Global`d2] - TBgamma[2, Global`a$3610, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3610])*
        (TBgamma[2, Global`d3, Global`a$3619]*TBgamma[3, Global`a$3619, 
           Global`d4] - TBgamma[2, Global`a$3616, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3616]) - 
       (TBgamma[3, Global`a$3622, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$3622] - TBgamma[3, Global`a$3625, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3625])*
        (TBgamma[3, Global`a$3628, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$3628] - TBgamma[3, Global`a$3631, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3631]))*TBT[Global`flavor, 
       Global`af$3634, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$3634, Global`F3, Global`F4]) + 2*Global`Nc*Global`Nf*
    TBT[Global`color, Global`ac$3939, Global`A1, Global`A2]*
    TBT[Global`color, Global`ac$3939, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (2*(TBgamma[0, Global`d1, Global`a$3650]*TBgamma[1, Global`a$3650, 
           Global`d2] - TBgamma[0, Global`a$3653, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3653])*
        (TBgamma[0, Global`d3, Global`a$3656]*TBgamma[1, Global`a$3656, 
           Global`d4] - TBgamma[0, Global`a$3659, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3659]) - 
       (TBgamma[1, Global`a$3686, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$3686] - TBgamma[1, Global`a$3689, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3689])*
        (TBgamma[1, Global`a$3692, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$3692] - TBgamma[1, Global`a$3695, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3695]) + 
       2*(TBgamma[0, Global`d1, Global`a$3662]*TBgamma[2, Global`a$3662, 
           Global`d2] - TBgamma[0, Global`a$3665, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3665])*
        (TBgamma[0, Global`d3, Global`a$3668]*TBgamma[2, Global`a$3668, 
           Global`d4] - TBgamma[0, Global`a$3671, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3671]) - 
       (TBgamma[1, Global`d1, Global`a$3698]*TBgamma[2, Global`a$3698, 
           Global`d2] - TBgamma[1, Global`a$3701, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3701])*
        (TBgamma[1, Global`d3, Global`a$3704]*TBgamma[2, Global`a$3704, 
           Global`d4] - TBgamma[1, Global`a$3707, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3707]) - 
       (TBgamma[1, Global`d1, Global`a$3725]*TBgamma[2, Global`a$3725, 
           Global`d2] - TBgamma[1, Global`a$3722, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3722])*
        (TBgamma[1, Global`d3, Global`a$3731]*TBgamma[2, Global`a$3731, 
           Global`d4] - TBgamma[1, Global`a$3728, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3728]) - 
       (TBgamma[2, Global`a$3734, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$3734] - TBgamma[2, Global`a$3737, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3737])*
        (TBgamma[2, Global`a$3740, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$3740] - TBgamma[2, Global`a$3743, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3743]) + 
       2*(TBgamma[0, Global`d1, Global`a$3674]*TBgamma[3, Global`a$3674, 
           Global`d2] - TBgamma[0, Global`a$3677, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3677])*
        (TBgamma[0, Global`d3, Global`a$3680]*TBgamma[3, Global`a$3680, 
           Global`d4] - TBgamma[0, Global`a$3683, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3683]) - 
       (TBgamma[1, Global`d1, Global`a$3710]*TBgamma[3, Global`a$3710, 
           Global`d2] - TBgamma[1, Global`a$3713, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3713])*
        (TBgamma[1, Global`d3, Global`a$3716]*TBgamma[3, Global`a$3716, 
           Global`d4] - TBgamma[1, Global`a$3719, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3719]) - 
       (TBgamma[2, Global`d1, Global`a$3746]*TBgamma[3, Global`a$3746, 
           Global`d2] - TBgamma[2, Global`a$3749, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3749])*
        (TBgamma[2, Global`d3, Global`a$3752]*TBgamma[3, Global`a$3752, 
           Global`d4] - TBgamma[2, Global`a$3755, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3755]) - 
       (TBgamma[1, Global`d1, Global`a$3761]*TBgamma[3, Global`a$3761, 
           Global`d2] - TBgamma[1, Global`a$3758, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3758])*
        (TBgamma[1, Global`d3, Global`a$3767]*TBgamma[3, Global`a$3767, 
           Global`d4] - TBgamma[1, Global`a$3764, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3764]) - 
       (TBgamma[2, Global`d1, Global`a$3773]*TBgamma[3, Global`a$3773, 
           Global`d2] - TBgamma[2, Global`a$3770, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3770])*
        (TBgamma[2, Global`d3, Global`a$3779]*TBgamma[3, Global`a$3779, 
           Global`d4] - TBgamma[2, Global`a$3776, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3776]) - 
       (TBgamma[3, Global`a$3782, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$3782] - TBgamma[3, Global`a$3785, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3785])*
        (TBgamma[3, Global`a$3789, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$3789] - TBgamma[3, Global`a$3792, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3792])) + 
     9*(2*(TBgamma[0, Global`d1, Global`a$3795]*TBgamma[1, Global`a$3795, 
           Global`d2] - TBgamma[0, Global`a$3798, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3798])*
        (TBgamma[0, Global`d3, Global`a$3801]*TBgamma[1, Global`a$3801, 
           Global`d4] - TBgamma[0, Global`a$3804, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3804]) - 
       (TBgamma[1, Global`a$3831, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$3831] - TBgamma[1, Global`a$3834, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3834])*
        (TBgamma[1, Global`a$3837, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$3837] - TBgamma[1, Global`a$3840, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3840]) + 
       2*(TBgamma[0, Global`d1, Global`a$3807]*TBgamma[2, Global`a$3807, 
           Global`d2] - TBgamma[0, Global`a$3810, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3810])*
        (TBgamma[0, Global`d3, Global`a$3813]*TBgamma[2, Global`a$3813, 
           Global`d4] - TBgamma[0, Global`a$3816, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3816]) - 
       (TBgamma[1, Global`d1, Global`a$3843]*TBgamma[2, Global`a$3843, 
           Global`d2] - TBgamma[1, Global`a$3846, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3846])*
        (TBgamma[1, Global`d3, Global`a$3849]*TBgamma[2, Global`a$3849, 
           Global`d4] - TBgamma[1, Global`a$3852, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3852]) - 
       (TBgamma[1, Global`d1, Global`a$3870]*TBgamma[2, Global`a$3870, 
           Global`d2] - TBgamma[1, Global`a$3867, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3867])*
        (TBgamma[1, Global`d3, Global`a$3876]*TBgamma[2, Global`a$3876, 
           Global`d4] - TBgamma[1, Global`a$3873, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3873]) - 
       (TBgamma[2, Global`a$3879, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$3879] - TBgamma[2, Global`a$3882, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3882])*
        (TBgamma[2, Global`a$3885, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$3885] - TBgamma[2, Global`a$3888, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3888]) + 
       2*(TBgamma[0, Global`d1, Global`a$3819]*TBgamma[3, Global`a$3819, 
           Global`d2] - TBgamma[0, Global`a$3822, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3822])*
        (TBgamma[0, Global`d3, Global`a$3825]*TBgamma[3, Global`a$3825, 
           Global`d4] - TBgamma[0, Global`a$3828, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3828]) - 
       (TBgamma[1, Global`d1, Global`a$3855]*TBgamma[3, Global`a$3855, 
           Global`d2] - TBgamma[1, Global`a$3858, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3858])*
        (TBgamma[1, Global`d3, Global`a$3861]*TBgamma[3, Global`a$3861, 
           Global`d4] - TBgamma[1, Global`a$3864, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3864]) - 
       (TBgamma[2, Global`d1, Global`a$3891]*TBgamma[3, Global`a$3891, 
           Global`d2] - TBgamma[2, Global`a$3894, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3894])*
        (TBgamma[2, Global`d3, Global`a$3897]*TBgamma[3, Global`a$3897, 
           Global`d4] - TBgamma[2, Global`a$3900, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3900]) - 
       (TBgamma[1, Global`d1, Global`a$3906]*TBgamma[3, Global`a$3906, 
           Global`d2] - TBgamma[1, Global`a$3903, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3903])*
        (TBgamma[1, Global`d3, Global`a$3912]*TBgamma[3, Global`a$3912, 
           Global`d4] - TBgamma[1, Global`a$3909, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3909]) - 
       (TBgamma[2, Global`d1, Global`a$3918]*TBgamma[3, Global`a$3918, 
           Global`d2] - TBgamma[2, Global`a$3915, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3915])*
        (TBgamma[2, Global`d3, Global`a$3924]*TBgamma[3, Global`a$3924, 
           Global`d4] - TBgamma[2, Global`a$3921, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3921]) - 
       (TBgamma[3, Global`a$3927, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$3927] - TBgamma[3, Global`a$3930, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3930])*
        (TBgamma[3, Global`a$3933, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$3933] - TBgamma[3, Global`a$3936, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3936]))*TBT[Global`flavor, 
       Global`af$3942, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$3942, Global`F3, Global`F4]) + 24*(-1 + Global`Nc^2)*
    Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     9*TBT[Global`flavor, Global`f$3309, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3309, Global`F3, Global`F4]) - 
   48*Global`Nc*Global`Nf*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4] - TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4])*TBT[Global`color, Global`a$3325, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$3325, Global`A3, 
     Global`A4]*(4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     9*TBT[Global`flavor, Global`f$3328, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3328, Global`F3, Global`F4]))/
  (128*Global`Nc^2*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
   (-2 + Global`Nf^2)), 
 (3*((TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
        TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$1752]*TBgamma[0, Global`d3, 
         Global`dc$1755]*TBgamma5[Global`dc$1752, Global`d2]*
        TBgamma5[Global`dc$1755, Global`d4]))/(Global`Nc^2*(-2 + Global`Nf)*
      Global`Nf) - (TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*((-(TBdeltaLorentz[Global`i$1771, 0]*
           TBgamma[0, Global`d1, Global`d2]) + TBgamma[Global`i$1771, 
          Global`d1, Global`d2])*(-(TBdeltaLorentz[Global`i$1771, 0]*
           TBgamma[0, Global`d3, Global`d4]) + TBgamma[Global`i$1771, 
          Global`d3, Global`d4]) + 
       (-(TBdeltaLorentz[Global`i$1771, 0]*TBgamma[0, Global`d1, 
            Global`dc$1774]) + TBgamma[Global`i$1771, Global`d1, 
          Global`dc$1774])*(-(TBdeltaLorentz[Global`i$1771, 0]*
           TBgamma[0, Global`d3, Global`dc$1777]) + TBgamma[Global`i$1771, 
          Global`d3, Global`dc$1777])*TBgamma5[Global`dc$1774, Global`d2]*
        TBgamma5[Global`dc$1777, Global`d4]))/(Global`Nc^2*(-2 + Global`Nf)*
      Global`Nf) - (2*TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
      TBdeltaFund[Global`flavor, Global`F4, 3]*
      (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$1906]*TBgamma[0, Global`d3, 
         Global`dc$1909]*TBgamma5[Global`dc$1906, Global`d2]*
        TBgamma5[Global`dc$1909, Global`d4]))/((-2 + Global`Nc)*Global`Nc) + 
    (2*(-1 + Global`Nc*(-2 + Global`Nf^2))*
      (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
        TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$1840]*TBgamma[0, Global`d3, 
         Global`dc$1843]*TBgamma5[Global`dc$1840, Global`d2]*
        TBgamma5[Global`dc$1843, Global`d4])*TBT[Global`color, Global`a$1846, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$1846, Global`A3, 
       Global`A4])/(Global`Nc*(-1 + Global`Nc^2)*(-2 + Global`Nf)*
      Global`Nf) + (2*(TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*((-(TBdeltaLorentz[Global`i$1862, 0]*
           TBgamma[0, Global`d1, Global`d2]) + TBgamma[Global`i$1862, 
          Global`d1, Global`d2])*(-(TBdeltaLorentz[Global`i$1862, 0]*
           TBgamma[0, Global`d3, Global`d4]) + TBgamma[Global`i$1862, 
          Global`d3, Global`d4]) + 
       (-(TBdeltaLorentz[Global`i$1862, 0]*TBgamma[0, Global`d1, 
            Global`dc$1865]) + TBgamma[Global`i$1862, Global`d1, 
          Global`dc$1865])*(-(TBdeltaLorentz[Global`i$1862, 0]*
           TBgamma[0, Global`d3, Global`dc$1868]) + TBgamma[Global`i$1862, 
          Global`d3, Global`dc$1868])*TBgamma5[Global`dc$1865, Global`d2]*
        TBgamma5[Global`dc$1868, Global`d4])*TBT[Global`color, Global`a$1871, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$1871, Global`A3, 
       Global`A4])/(Global`Nc*(-1 + Global`Nc^2)*(-2 + Global`Nf)*
      Global`Nf) + (2*Global`Nc*TBdeltaFund[Global`flavor, Global`F1, 3]*
      TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
       Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
      ((-(TBdeltaLorentz[Global`i$1950, 0]*TBgamma[0, Global`d1, 
            Global`d2]) + TBgamma[Global`i$1950, Global`d1, Global`d2])*
        (-(TBdeltaLorentz[Global`i$1950, 0]*TBgamma[0, Global`d3, 
            Global`d4]) + TBgamma[Global`i$1950, Global`d3, Global`d4]) + 
       (-(TBdeltaLorentz[Global`i$1950, 0]*TBgamma[0, Global`d1, 
            Global`dc$1953]) + TBgamma[Global`i$1950, Global`d1, 
          Global`dc$1953])*(-(TBdeltaLorentz[Global`i$1950, 0]*
           TBgamma[0, Global`d3, Global`dc$1956]) + TBgamma[Global`i$1950, 
          Global`d3, Global`dc$1956])*TBgamma5[Global`dc$1953, Global`d2]*
        TBgamma5[Global`dc$1956, Global`d4])*TBT[Global`color, Global`a$1959, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$1959, Global`A3, 
       Global`A4])/((-2 + Global`Nc)*(-1 + Global`Nc^2)) - 
    (2*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$2133]*TBgamma[0, Global`d3, 
         Global`dc$2136]*TBgamma5[Global`dc$2133, Global`d2]*
        TBgamma5[Global`dc$2136, Global`d4])*TBT[Global`color, Global`a$2139, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$2139, Global`A3, 
       Global`A4])/(-1 + Global`Nc^2)))/(32*(-1 + Global`Nf)), 
 (-3*(-1 + Global`Nc^2)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
      TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$2874]*TBgamma[0, Global`d3, 
       Global`dc$2877]*TBgamma5[Global`dc$2874, Global`d2]*
      TBgamma5[Global`dc$2877, Global`d4]) + (1 - Global`Nc^2)*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$2893, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$2893, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$2893, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$2893, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$2893, 0]*TBgamma[0, Global`d1, 
          Global`dc$2896]) + TBgamma[Global`i$2893, Global`d1, 
        Global`dc$2896])*(-(TBdeltaLorentz[Global`i$2893, 0]*
         TBgamma[0, Global`d3, Global`dc$2899]) + TBgamma[Global`i$2893, 
        Global`d3, Global`dc$2899])*TBgamma5[Global`dc$2896, Global`d2]*
      TBgamma5[Global`dc$2899, Global`d4]) + 
   6*Global`Nc*(TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
      TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$2962]*TBgamma[0, Global`d3, 
       Global`dc$2965]*TBgamma5[Global`dc$2962, Global`d2]*
      TBgamma5[Global`dc$2965, Global`d4])*TBT[Global`color, Global`a$2968, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$2968, Global`A3, 
     Global`A4] + 2*Global`Nc*(1 + Global`Nc*(-2 + Global`Nf^2))*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$2984, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$2984, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$2984, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$2984, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$2984, 0]*TBgamma[0, Global`d1, 
          Global`dc$2987]) + TBgamma[Global`i$2984, Global`d1, 
        Global`dc$2987])*(-(TBdeltaLorentz[Global`i$2984, 0]*
         TBgamma[0, Global`d3, Global`dc$2990]) + TBgamma[Global`i$2984, 
        Global`d3, Global`dc$2990])*TBgamma5[Global`dc$2987, Global`d2]*
      TBgamma5[Global`dc$2990, Global`d4])*TBT[Global`color, Global`a$2993, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$2993, Global`A3, 
     Global`A4] - 2*Global`Nc^2*(2 - Global`Nf)*Global`Nf*
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
     Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
    TBdeltaFund[Global`flavor, Global`F4, 3]*
    ((-(TBdeltaLorentz[Global`i$3072, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$3072, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$3072, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$3072, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$3072, 0]*TBgamma[0, Global`d1, 
          Global`dc$3075]) + TBgamma[Global`i$3072, Global`d1, 
        Global`dc$3075])*(-(TBdeltaLorentz[Global`i$3072, 0]*
         TBgamma[0, Global`d3, Global`dc$3078]) + TBgamma[Global`i$3072, 
        Global`d3, Global`dc$3078])*TBgamma5[Global`dc$3075, Global`d2]*
      TBgamma5[Global`dc$3078, Global`d4])*TBT[Global`color, Global`a$3081, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$3081, Global`A3, 
     Global`A4] + 2*Global`Nc^2*(2 - Global`Nf)*Global`Nf*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$3277, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$3277, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$3277, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$3277, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$3277, 0]*TBgamma[0, Global`d1, 
          Global`dc$3280]) + TBgamma[Global`i$3277, Global`d1, 
        Global`dc$3280])*(-(TBdeltaLorentz[Global`i$3277, 0]*
         TBgamma[0, Global`d3, Global`dc$3283]) + TBgamma[Global`i$3277, 
        Global`d3, Global`dc$3283])*TBgamma5[Global`dc$3280, Global`d2]*
      TBgamma5[Global`dc$3283, Global`d4])*TBT[Global`color, Global`a$3286, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$3286, Global`A3, 
     Global`A4])/(32*Global`Nc^2*(-1 + Global`Nc^2)*(-2 + Global`Nf)*
   (-1 + Global`Nf)*Global`Nf), 
 (2*(9 - 8*Global`Nf)*Global`Nf*(2 + Global`Nf - 2*Global`Nf^2)*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
     Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
    TBdeltaFund[Global`flavor, Global`F4, 3]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
   3*Global`Nc*Global`Nf^2*(-9 + 8*Global`Nf)*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
      TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$1717]*TBgamma[0, Global`d3, 
       Global`dc$1720]*TBgamma5[Global`dc$1717, Global`d2]*
      TBgamma5[Global`dc$1720, Global`d4]) + Global`Nc*(9 - 8*Global`Nf)*
    Global`Nf^2*TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$1736, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$1736, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$1736, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$1736, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$1736, 0]*TBgamma[0, Global`d1, 
          Global`dc$1739]) + TBgamma[Global`i$1736, Global`d1, 
        Global`dc$1739])*(-(TBdeltaLorentz[Global`i$1736, 0]*
         TBgamma[0, Global`d3, Global`dc$1742]) + TBgamma[Global`i$1736, 
        Global`d3, Global`dc$1742])*TBgamma5[Global`dc$1739, Global`d2]*
      TBgamma5[Global`dc$1742, Global`d4]) + 4*Global`Nc*(9 - 8*Global`Nf)*
    Global`Nf*(2 + Global`Nf - 2*Global`Nf^2)*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
     Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
    TBdeltaFund[Global`flavor, Global`F4, 3]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$1893]*TBgamma[0, Global`d3, 
       Global`dc$1896]*TBgamma5[Global`dc$1893, Global`d2]*
      TBgamma5[Global`dc$1896, Global`d4]) - 
   3*Global`Nc*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$2010]*TBgamma[0, Global`d3, 
       Global`dc$2013]*TBgamma5[Global`dc$2010, Global`d2]*
      TBgamma5[Global`dc$2013, Global`d4]) + 
   Global`Nc*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$2029, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$2029, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$2029, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$2029, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$2029, 0]*TBgamma[0, Global`d1, 
          Global`dc$2032]) + TBgamma[Global`i$2029, Global`d1, 
        Global`dc$2032])*(-(TBdeltaLorentz[Global`i$2029, 0]*
         TBgamma[0, Global`d3, Global`dc$2035]) + TBgamma[Global`i$2029, 
        Global`d3, Global`dc$2035])*TBgamma5[Global`dc$2032, Global`d2]*
      TBgamma5[Global`dc$2035, Global`d4]) + 4*Global`Nc*(9 - 8*Global`Nf)*
    Global`Nf*(2 + Global`Nf - 2*Global`Nf^2)*TBdeltaFund[Global`flavor, 
     Global`F1, 3]*TBdeltaFund[Global`flavor, Global`F2, 3]*
    TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
     Global`F4, 3]*(TBdeltaDirac[Global`d1, Global`d2]*
      TBdeltaDirac[Global`d3, Global`d4] - TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4])*TBT[Global`color, Global`a$1994, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1994, Global`A3, 
     Global`A4] - (1 - Global`Nf)*Global`Nf*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (2*(TBgamma[0, Global`d1, Global`a$2221]*TBgamma[1, Global`a$2221, 
           Global`d2] - TBgamma[0, Global`a$2224, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2224])*
        (TBgamma[0, Global`d3, Global`a$2227]*TBgamma[1, Global`a$2227, 
           Global`d4] - TBgamma[0, Global`a$2230, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2230]) - 
       (TBgamma[1, Global`a$2258, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$2258] - TBgamma[1, Global`a$2261, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2261])*
        (TBgamma[1, Global`a$2264, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$2264] - TBgamma[1, Global`a$2267, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2267]) + 
       2*(TBgamma[0, Global`d1, Global`a$2233]*TBgamma[2, Global`a$2233, 
           Global`d2] - TBgamma[0, Global`a$2236, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2236])*
        (TBgamma[0, Global`d3, Global`a$2239]*TBgamma[2, Global`a$2239, 
           Global`d4] - TBgamma[0, Global`a$2242, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2242]) - 
       (TBgamma[1, Global`d1, Global`a$2270]*TBgamma[2, Global`a$2270, 
           Global`d2] - TBgamma[1, Global`a$2273, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2273])*
        (TBgamma[1, Global`d3, Global`a$2276]*TBgamma[2, Global`a$2276, 
           Global`d4] - TBgamma[1, Global`a$2279, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2279]) - 
       (TBgamma[1, Global`d1, Global`a$2297]*TBgamma[2, Global`a$2297, 
           Global`d2] - TBgamma[1, Global`a$2294, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2294])*
        (TBgamma[1, Global`d3, Global`a$2303]*TBgamma[2, Global`a$2303, 
           Global`d4] - TBgamma[1, Global`a$2300, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2300]) - 
       (TBgamma[2, Global`a$2306, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$2306] - TBgamma[2, Global`a$2309, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2309])*
        (TBgamma[2, Global`a$2312, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$2312] - TBgamma[2, Global`a$2315, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2315]) + 
       2*(TBgamma[0, Global`d1, Global`a$2246]*TBgamma[3, Global`a$2246, 
           Global`d2] - TBgamma[0, Global`a$2249, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2249])*
        (TBgamma[0, Global`d3, Global`a$2252]*TBgamma[3, Global`a$2252, 
           Global`d4] - TBgamma[0, Global`a$2255, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2255]) - 
       (TBgamma[1, Global`d1, Global`a$2282]*TBgamma[3, Global`a$2282, 
           Global`d2] - TBgamma[1, Global`a$2285, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2285])*
        (TBgamma[1, Global`d3, Global`a$2288]*TBgamma[3, Global`a$2288, 
           Global`d4] - TBgamma[1, Global`a$2291, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2291]) - 
       (TBgamma[2, Global`d1, Global`a$2318]*TBgamma[3, Global`a$2318, 
           Global`d2] - TBgamma[2, Global`a$2321, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2321])*
        (TBgamma[2, Global`d3, Global`a$2324]*TBgamma[3, Global`a$2324, 
           Global`d4] - TBgamma[2, Global`a$2327, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2327]) - 
       (TBgamma[1, Global`d1, Global`a$2333]*TBgamma[3, Global`a$2333, 
           Global`d2] - TBgamma[1, Global`a$2330, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2330])*
        (TBgamma[1, Global`d3, Global`a$2339]*TBgamma[3, Global`a$2339, 
           Global`d4] - TBgamma[1, Global`a$2336, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2336]) - 
       (TBgamma[2, Global`d1, Global`a$2345]*TBgamma[3, Global`a$2345, 
           Global`d2] - TBgamma[2, Global`a$2342, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2342])*
        (TBgamma[2, Global`d3, Global`a$2351]*TBgamma[3, Global`a$2351, 
           Global`d4] - TBgamma[2, Global`a$2348, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2348]) - 
       (TBgamma[3, Global`a$2354, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$2354] - TBgamma[3, Global`a$2357, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2357])*
        (TBgamma[3, Global`a$2360, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$2360] - TBgamma[3, Global`a$2363, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2363])) + 
     9*(2*(TBgamma[0, Global`d1, Global`a$2366]*TBgamma[1, Global`a$2366, 
           Global`d2] - TBgamma[0, Global`a$2369, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2369])*
        (TBgamma[0, Global`d3, Global`a$2372]*TBgamma[1, Global`a$2372, 
           Global`d4] - TBgamma[0, Global`a$2375, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2375]) - 
       (TBgamma[1, Global`a$2402, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$2402] - TBgamma[1, Global`a$2405, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2405])*
        (TBgamma[1, Global`a$2408, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$2408] - TBgamma[1, Global`a$2411, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2411]) + 
       2*(TBgamma[0, Global`d1, Global`a$2378]*TBgamma[2, Global`a$2378, 
           Global`d2] - TBgamma[0, Global`a$2381, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2381])*
        (TBgamma[0, Global`d3, Global`a$2384]*TBgamma[2, Global`a$2384, 
           Global`d4] - TBgamma[0, Global`a$2387, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2387]) - 
       (TBgamma[1, Global`d1, Global`a$2414]*TBgamma[2, Global`a$2414, 
           Global`d2] - TBgamma[1, Global`a$2417, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2417])*
        (TBgamma[1, Global`d3, Global`a$2420]*TBgamma[2, Global`a$2420, 
           Global`d4] - TBgamma[1, Global`a$2423, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2423]) - 
       (TBgamma[1, Global`d1, Global`a$2441]*TBgamma[2, Global`a$2441, 
           Global`d2] - TBgamma[1, Global`a$2438, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2438])*
        (TBgamma[1, Global`d3, Global`a$2447]*TBgamma[2, Global`a$2447, 
           Global`d4] - TBgamma[1, Global`a$2444, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2444]) - 
       (TBgamma[2, Global`a$2450, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$2450] - TBgamma[2, Global`a$2453, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2453])*
        (TBgamma[2, Global`a$2456, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$2456] - TBgamma[2, Global`a$2459, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2459]) + 
       2*(TBgamma[0, Global`d1, Global`a$2390]*TBgamma[3, Global`a$2390, 
           Global`d2] - TBgamma[0, Global`a$2393, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2393])*
        (TBgamma[0, Global`d3, Global`a$2396]*TBgamma[3, Global`a$2396, 
           Global`d4] - TBgamma[0, Global`a$2399, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2399]) - 
       (TBgamma[1, Global`d1, Global`a$2426]*TBgamma[3, Global`a$2426, 
           Global`d2] - TBgamma[1, Global`a$2429, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2429])*
        (TBgamma[1, Global`d3, Global`a$2432]*TBgamma[3, Global`a$2432, 
           Global`d4] - TBgamma[1, Global`a$2435, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2435]) - 
       (TBgamma[2, Global`d1, Global`a$2462]*TBgamma[3, Global`a$2462, 
           Global`d2] - TBgamma[2, Global`a$2465, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2465])*
        (TBgamma[2, Global`d3, Global`a$2468]*TBgamma[3, Global`a$2468, 
           Global`d4] - TBgamma[2, Global`a$2471, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2471]) - 
       (TBgamma[1, Global`d1, Global`a$2477]*TBgamma[3, Global`a$2477, 
           Global`d2] - TBgamma[1, Global`a$2474, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2474])*
        (TBgamma[1, Global`d3, Global`a$2483]*TBgamma[3, Global`a$2483, 
           Global`d4] - TBgamma[1, Global`a$2480, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2480]) - 
       (TBgamma[2, Global`d1, Global`a$2489]*TBgamma[3, Global`a$2489, 
           Global`d2] - TBgamma[2, Global`a$2486, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2486])*
        (TBgamma[2, Global`d3, Global`a$2495]*TBgamma[3, Global`a$2495, 
           Global`d4] - TBgamma[2, Global`a$2492, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2492]) - 
       (TBgamma[3, Global`a$2498, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$2498] - TBgamma[3, Global`a$2501, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2501])*
        (TBgamma[3, Global`a$2504, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$2504] - TBgamma[3, Global`a$2507, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2507]))*TBT[Global`flavor, 
       Global`af$2510, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$2510, Global`F3, Global`F4]) - 2*Global`Nc*(1 - Global`Nf)*
    Global`Nf*TBT[Global`color, Global`ac$2816, Global`A1, Global`A2]*
    TBT[Global`color, Global`ac$2816, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (2*(TBgamma[0, Global`d1, Global`a$2526]*TBgamma[1, Global`a$2526, 
           Global`d2] - TBgamma[0, Global`a$2529, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2529])*
        (TBgamma[0, Global`d3, Global`a$2532]*TBgamma[1, Global`a$2532, 
           Global`d4] - TBgamma[0, Global`a$2535, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2535]) - 
       (TBgamma[1, Global`a$2562, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$2562] - TBgamma[1, Global`a$2565, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2565])*
        (TBgamma[1, Global`a$2568, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$2568] - TBgamma[1, Global`a$2571, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2571]) + 
       2*(TBgamma[0, Global`d1, Global`a$2538]*TBgamma[2, Global`a$2538, 
           Global`d2] - TBgamma[0, Global`a$2541, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2541])*
        (TBgamma[0, Global`d3, Global`a$2544]*TBgamma[2, Global`a$2544, 
           Global`d4] - TBgamma[0, Global`a$2547, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2547]) - 
       (TBgamma[1, Global`d1, Global`a$2574]*TBgamma[2, Global`a$2574, 
           Global`d2] - TBgamma[1, Global`a$2577, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2577])*
        (TBgamma[1, Global`d3, Global`a$2580]*TBgamma[2, Global`a$2580, 
           Global`d4] - TBgamma[1, Global`a$2583, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2583]) - 
       (TBgamma[1, Global`d1, Global`a$2601]*TBgamma[2, Global`a$2601, 
           Global`d2] - TBgamma[1, Global`a$2598, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2598])*
        (TBgamma[1, Global`d3, Global`a$2607]*TBgamma[2, Global`a$2607, 
           Global`d4] - TBgamma[1, Global`a$2604, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2604]) - 
       (TBgamma[2, Global`a$2610, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$2610] - TBgamma[2, Global`a$2613, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2613])*
        (TBgamma[2, Global`a$2616, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$2616] - TBgamma[2, Global`a$2619, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2619]) + 
       2*(TBgamma[0, Global`d1, Global`a$2550]*TBgamma[3, Global`a$2550, 
           Global`d2] - TBgamma[0, Global`a$2553, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2553])*
        (TBgamma[0, Global`d3, Global`a$2556]*TBgamma[3, Global`a$2556, 
           Global`d4] - TBgamma[0, Global`a$2559, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2559]) - 
       (TBgamma[1, Global`d1, Global`a$2586]*TBgamma[3, Global`a$2586, 
           Global`d2] - TBgamma[1, Global`a$2589, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2589])*
        (TBgamma[1, Global`d3, Global`a$2592]*TBgamma[3, Global`a$2592, 
           Global`d4] - TBgamma[1, Global`a$2595, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2595]) - 
       (TBgamma[2, Global`d1, Global`a$2622]*TBgamma[3, Global`a$2622, 
           Global`d2] - TBgamma[2, Global`a$2625, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2625])*
        (TBgamma[2, Global`d3, Global`a$2628]*TBgamma[3, Global`a$2628, 
           Global`d4] - TBgamma[2, Global`a$2631, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2631]) - 
       (TBgamma[1, Global`d1, Global`a$2637]*TBgamma[3, Global`a$2637, 
           Global`d2] - TBgamma[1, Global`a$2634, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2634])*
        (TBgamma[1, Global`d3, Global`a$2644]*TBgamma[3, Global`a$2644, 
           Global`d4] - TBgamma[1, Global`a$2640, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2640]) - 
       (TBgamma[2, Global`d1, Global`a$2650]*TBgamma[3, Global`a$2650, 
           Global`d2] - TBgamma[2, Global`a$2647, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2647])*
        (TBgamma[2, Global`d3, Global`a$2656]*TBgamma[3, Global`a$2656, 
           Global`d4] - TBgamma[2, Global`a$2653, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2653]) - 
       (TBgamma[3, Global`a$2659, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$2659] - TBgamma[3, Global`a$2662, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2662])*
        (TBgamma[3, Global`a$2665, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$2665] - TBgamma[3, Global`a$2668, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2668])) + 
     9*(2*(TBgamma[0, Global`d1, Global`a$2671]*TBgamma[1, Global`a$2671, 
           Global`d2] - TBgamma[0, Global`a$2674, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2674])*
        (TBgamma[0, Global`d3, Global`a$2677]*TBgamma[1, Global`a$2677, 
           Global`d4] - TBgamma[0, Global`a$2680, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2680]) - 
       (TBgamma[1, Global`a$2707, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$2707] - TBgamma[1, Global`a$2710, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2710])*
        (TBgamma[1, Global`a$2713, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$2713] - TBgamma[1, Global`a$2716, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2716]) + 
       2*(TBgamma[0, Global`d1, Global`a$2683]*TBgamma[2, Global`a$2683, 
           Global`d2] - TBgamma[0, Global`a$2686, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2686])*
        (TBgamma[0, Global`d3, Global`a$2689]*TBgamma[2, Global`a$2689, 
           Global`d4] - TBgamma[0, Global`a$2692, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2692]) - 
       (TBgamma[1, Global`d1, Global`a$2719]*TBgamma[2, Global`a$2719, 
           Global`d2] - TBgamma[1, Global`a$2722, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2722])*
        (TBgamma[1, Global`d3, Global`a$2725]*TBgamma[2, Global`a$2725, 
           Global`d4] - TBgamma[1, Global`a$2728, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2728]) - 
       (TBgamma[1, Global`d1, Global`a$2746]*TBgamma[2, Global`a$2746, 
           Global`d2] - TBgamma[1, Global`a$2743, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2743])*
        (TBgamma[1, Global`d3, Global`a$2752]*TBgamma[2, Global`a$2752, 
           Global`d4] - TBgamma[1, Global`a$2749, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2749]) - 
       (TBgamma[2, Global`a$2755, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$2755] - TBgamma[2, Global`a$2758, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2758])*
        (TBgamma[2, Global`a$2761, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$2761] - TBgamma[2, Global`a$2764, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2764]) + 
       2*(TBgamma[0, Global`d1, Global`a$2695]*TBgamma[3, Global`a$2695, 
           Global`d2] - TBgamma[0, Global`a$2698, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2698])*
        (TBgamma[0, Global`d3, Global`a$2701]*TBgamma[3, Global`a$2701, 
           Global`d4] - TBgamma[0, Global`a$2704, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2704]) - 
       (TBgamma[1, Global`d1, Global`a$2731]*TBgamma[3, Global`a$2731, 
           Global`d2] - TBgamma[1, Global`a$2734, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2734])*
        (TBgamma[1, Global`d3, Global`a$2737]*TBgamma[3, Global`a$2737, 
           Global`d4] - TBgamma[1, Global`a$2740, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2740]) - 
       (TBgamma[2, Global`d1, Global`a$2767]*TBgamma[3, Global`a$2767, 
           Global`d2] - TBgamma[2, Global`a$2770, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2770])*
        (TBgamma[2, Global`d3, Global`a$2773]*TBgamma[3, Global`a$2773, 
           Global`d4] - TBgamma[2, Global`a$2776, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2776]) - 
       (TBgamma[1, Global`d1, Global`a$2782]*TBgamma[3, Global`a$2782, 
           Global`d2] - TBgamma[1, Global`a$2779, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2779])*
        (TBgamma[1, Global`d3, Global`a$2788]*TBgamma[3, Global`a$2788, 
           Global`d4] - TBgamma[1, Global`a$2785, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2785]) - 
       (TBgamma[2, Global`d1, Global`a$2794]*TBgamma[3, Global`a$2794, 
           Global`d2] - TBgamma[2, Global`a$2791, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2791])*
        (TBgamma[2, Global`d3, Global`a$2800]*TBgamma[3, Global`a$2800, 
           Global`d4] - TBgamma[2, Global`a$2797, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2797]) - 
       (TBgamma[3, Global`a$2803, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$2803] - TBgamma[3, Global`a$2806, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2806])*
        (TBgamma[3, Global`a$2809, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$2809] - TBgamma[3, Global`a$2813, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2813]))*TBT[Global`flavor, 
       Global`af$2819, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$2819, Global`F3, Global`F4]))/
  (64*Global`Nc^3*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
 (3*((-2 + Global`Nc)^2*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$2881]*TBgamma[0, Global`d3, 
        Global`dc$2884]*TBgamma5[Global`dc$2881, Global`d2]*
       TBgamma5[Global`dc$2884, Global`d4]) + (2 - Global`Nc)*Global`Nc*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$2900, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2900, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2900, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2900, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$2900, 0]*TBgamma[0, Global`d1, 
           Global`dc$2903]) + TBgamma[Global`i$2900, Global`d1, 
         Global`dc$2903])*(-(TBdeltaLorentz[Global`i$2900, 0]*
          TBgamma[0, Global`d3, Global`dc$2906]) + TBgamma[Global`i$2900, 
         Global`d3, Global`dc$2906])*TBgamma5[Global`dc$2903, Global`d2]*
       TBgamma5[Global`dc$2906, Global`d4]) + 4*Global`Nc*(-1 + 2*Global`Nc)*
     Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$3035]*TBgamma[0, Global`d3, 
        Global`dc$3038]*TBgamma5[Global`dc$3035, Global`d2]*
       TBgamma5[Global`dc$3038, Global`d4]) - (-2 + Global`Nc)^2*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$3174]*TBgamma[0, Global`d3, 
        Global`dc$3177]*TBgamma5[Global`dc$3174, Global`d2]*
       TBgamma5[Global`dc$3177, Global`d4]) - (2 - Global`Nc)*Global`Nc*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$3193, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$3193, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$3193, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$3193, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$3193, 0]*TBgamma[0, Global`d1, 
           Global`dc$3196]) + TBgamma[Global`i$3193, Global`d1, 
         Global`dc$3196])*(-(TBdeltaLorentz[Global`i$3193, 0]*
          TBgamma[0, Global`d3, Global`dc$3199]) + TBgamma[Global`i$3193, 
         Global`d3, Global`dc$3199])*TBgamma5[Global`dc$3196, Global`d2]*
       TBgamma5[Global`dc$3199, Global`d4]) - 4*(-2 + Global`Nc)*Global`Nc*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$2969]*TBgamma[0, Global`d3, 
        Global`dc$2972]*TBgamma5[Global`dc$2969, Global`d2]*
       TBgamma5[Global`dc$2972, Global`d4])*TBT[Global`color, Global`a$2975, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2975, Global`A3, 
      Global`A4] - 8*Global`Nc^2*Global`Nf*TBdeltaFund[Global`flavor, 
      Global`F1, 3]*TBdeltaFund[Global`flavor, Global`F2, 3]*
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
      Global`F4, 3]*((-(TBdeltaLorentz[Global`i$3079, 0]*
          TBgamma[0, Global`d1, Global`d2]) + TBgamma[Global`i$3079, 
         Global`d1, Global`d2])*(-(TBdeltaLorentz[Global`i$3079, 0]*
          TBgamma[0, Global`d3, Global`d4]) + TBgamma[Global`i$3079, 
         Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$3079, 0]*TBgamma[0, Global`d1, 
           Global`dc$3082]) + TBgamma[Global`i$3079, Global`d1, 
         Global`dc$3082])*(-(TBdeltaLorentz[Global`i$3079, 0]*
          TBgamma[0, Global`d3, Global`dc$3085]) + TBgamma[Global`i$3079, 
         Global`d3, Global`dc$3085])*TBgamma5[Global`dc$3082, Global`d2]*
       TBgamma5[Global`dc$3085, Global`d4])*TBT[Global`color, Global`a$3088, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3088, Global`A3, 
      Global`A4] + 4*(-2 + Global`Nc)*Global`Nc*TBdeltaFund[Global`flavor, 
      Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$3262]*TBgamma[0, Global`d3, 
        Global`dc$3265]*TBgamma5[Global`dc$3262, Global`d2]*
       TBgamma5[Global`dc$3265, Global`d4])*TBT[Global`color, Global`a$3268, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3268, Global`A3, 
      Global`A4]))/(64*(-2 + Global`Nc)^2*Global`Nc^2*(-1 + Global`Nf)), 
 -1/32*(6*(1 - Global`Nc^2)*(9 - 8*Global`Nf)*Global`Nf*
     (2 + Global`Nf - 2*Global`Nf^2)*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
    6*Global`Nc^2*Global`Nf^2*(-9 + 8*Global`Nf)*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1799]*TBgamma[0, Global`d3, 
        Global`dc$1802]*TBgamma5[Global`dc$1799, Global`d2]*
       TBgamma5[Global`dc$1802, Global`d4])*TBT[Global`color, Global`a$1805, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1805, Global`A3, 
      Global`A4] + 2*Global`Nc^2*(9 - 8*Global`Nf)*Global`Nf^2*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$1821, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1821, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1821, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1821, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1821, 0]*TBgamma[0, Global`d1, 
           Global`dc$1824]) + TBgamma[Global`i$1821, Global`d1, 
         Global`dc$1824])*(-(TBdeltaLorentz[Global`i$1821, 0]*
          TBgamma[0, Global`d3, Global`dc$1827]) + TBgamma[Global`i$1821, 
         Global`d3, Global`dc$1827])*TBgamma5[Global`dc$1824, Global`d2]*
       TBgamma5[Global`dc$1827, Global`d4])*TBT[Global`color, Global`a$1830, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1830, Global`A3, 
      Global`A4] - 8*Global`Nc^2*(9 - 8*Global`Nf)*Global`Nf*
     (2 + Global`Nf - 2*Global`Nf^2)*TBdeltaFund[Global`flavor, Global`F1, 3]*
     TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
      Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
     ((-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1931, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1931, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d1, 
           Global`dc$1934]) + TBgamma[Global`i$1931, Global`d1, 
         Global`dc$1934])*(-(TBdeltaLorentz[Global`i$1931, 0]*
          TBgamma[0, Global`d3, Global`dc$1937]) + TBgamma[Global`i$1931, 
         Global`d3, Global`dc$1937])*TBgamma5[Global`dc$1934, Global`d2]*
       TBgamma5[Global`dc$1937, Global`d4])*TBT[Global`color, Global`a$1940, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1940, Global`A3, 
      Global`A4] + 12*Global`Nc*(9 - 8*Global`Nf)*Global`Nf*
     (2 + Global`Nf - 2*Global`Nf^2)*TBdeltaFund[Global`flavor, Global`F1, 3]*
     TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
      Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$1994, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$1994, Global`A3, Global`A4] - 
    6*Global`Nc^2*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2092]*TBgamma[0, Global`d3, 
        Global`dc$2095]*TBgamma5[Global`dc$2092, Global`d2]*
       TBgamma5[Global`dc$2095, Global`d4])*TBT[Global`color, Global`a$2098, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2098, Global`A3, 
      Global`A4] + 2*Global`Nc^2*(18 + 2*Global`Nf - 27*Global`Nf^2 + 
      8*Global`Nf^3)*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$2114, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2114, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2114, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2114, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$2114, 0]*TBgamma[0, Global`d1, 
           Global`dc$2117]) + TBgamma[Global`i$2114, Global`d1, 
         Global`dc$2117])*(-(TBdeltaLorentz[Global`i$2114, 0]*
          TBgamma[0, Global`d3, Global`dc$2120]) + TBgamma[Global`i$2114, 
         Global`d3, Global`dc$2120])*TBgamma5[Global`dc$2117, Global`d2]*
       TBgamma5[Global`dc$2120, Global`d4])*TBT[Global`color, Global`a$2123, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2123, Global`A3, 
      Global`A4] + (1 - Global`Nc^2)*(1 - Global`Nf)*Global`Nf*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$2221]*TBgamma[1, Global`a$2221, 
            Global`d2] - TBgamma[0, Global`a$2224, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2224])*
         (TBgamma[0, Global`d3, Global`a$2227]*TBgamma[1, Global`a$2227, 
            Global`d4] - TBgamma[0, Global`a$2230, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2230]) - 
        (TBgamma[1, Global`a$2258, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2258] - TBgamma[1, Global`a$2261, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2261])*
         (TBgamma[1, Global`a$2264, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2264] - TBgamma[1, Global`a$2267, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2267]) + 
        2*(TBgamma[0, Global`d1, Global`a$2233]*TBgamma[2, Global`a$2233, 
            Global`d2] - TBgamma[0, Global`a$2236, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2236])*
         (TBgamma[0, Global`d3, Global`a$2239]*TBgamma[2, Global`a$2239, 
            Global`d4] - TBgamma[0, Global`a$2242, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2242]) - 
        (TBgamma[1, Global`d1, Global`a$2270]*TBgamma[2, Global`a$2270, 
            Global`d2] - TBgamma[1, Global`a$2273, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2273])*
         (TBgamma[1, Global`d3, Global`a$2276]*TBgamma[2, Global`a$2276, 
            Global`d4] - TBgamma[1, Global`a$2279, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2279]) - 
        (TBgamma[1, Global`d1, Global`a$2297]*TBgamma[2, Global`a$2297, 
            Global`d2] - TBgamma[1, Global`a$2294, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2294])*
         (TBgamma[1, Global`d3, Global`a$2303]*TBgamma[2, Global`a$2303, 
            Global`d4] - TBgamma[1, Global`a$2300, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2300]) - 
        (TBgamma[2, Global`a$2306, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2306] - TBgamma[2, Global`a$2309, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2309])*
         (TBgamma[2, Global`a$2312, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2312] - TBgamma[2, Global`a$2315, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2315]) + 
        2*(TBgamma[0, Global`d1, Global`a$2246]*TBgamma[3, Global`a$2246, 
            Global`d2] - TBgamma[0, Global`a$2249, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2249])*
         (TBgamma[0, Global`d3, Global`a$2252]*TBgamma[3, Global`a$2252, 
            Global`d4] - TBgamma[0, Global`a$2255, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2255]) - 
        (TBgamma[1, Global`d1, Global`a$2282]*TBgamma[3, Global`a$2282, 
            Global`d2] - TBgamma[1, Global`a$2285, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2285])*
         (TBgamma[1, Global`d3, Global`a$2288]*TBgamma[3, Global`a$2288, 
            Global`d4] - TBgamma[1, Global`a$2291, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2291]) - 
        (TBgamma[2, Global`d1, Global`a$2318]*TBgamma[3, Global`a$2318, 
            Global`d2] - TBgamma[2, Global`a$2321, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2321])*
         (TBgamma[2, Global`d3, Global`a$2324]*TBgamma[3, Global`a$2324, 
            Global`d4] - TBgamma[2, Global`a$2327, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2327]) - 
        (TBgamma[1, Global`d1, Global`a$2333]*TBgamma[3, Global`a$2333, 
            Global`d2] - TBgamma[1, Global`a$2330, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2330])*
         (TBgamma[1, Global`d3, Global`a$2339]*TBgamma[3, Global`a$2339, 
            Global`d4] - TBgamma[1, Global`a$2336, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2336]) - 
        (TBgamma[2, Global`d1, Global`a$2345]*TBgamma[3, Global`a$2345, 
            Global`d2] - TBgamma[2, Global`a$2342, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2342])*
         (TBgamma[2, Global`d3, Global`a$2351]*TBgamma[3, Global`a$2351, 
            Global`d4] - TBgamma[2, Global`a$2348, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2348]) - 
        (TBgamma[3, Global`a$2354, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2354] - TBgamma[3, Global`a$2357, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2357])*
         (TBgamma[3, Global`a$2360, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2360] - TBgamma[3, Global`a$2363, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2363])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$2366]*TBgamma[1, Global`a$2366, 
            Global`d2] - TBgamma[0, Global`a$2369, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2369])*
         (TBgamma[0, Global`d3, Global`a$2372]*TBgamma[1, Global`a$2372, 
            Global`d4] - TBgamma[0, Global`a$2375, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2375]) - 
        (TBgamma[1, Global`a$2402, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2402] - TBgamma[1, Global`a$2405, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2405])*
         (TBgamma[1, Global`a$2408, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2408] - TBgamma[1, Global`a$2411, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2411]) + 
        2*(TBgamma[0, Global`d1, Global`a$2378]*TBgamma[2, Global`a$2378, 
            Global`d2] - TBgamma[0, Global`a$2381, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2381])*
         (TBgamma[0, Global`d3, Global`a$2384]*TBgamma[2, Global`a$2384, 
            Global`d4] - TBgamma[0, Global`a$2387, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2387]) - 
        (TBgamma[1, Global`d1, Global`a$2414]*TBgamma[2, Global`a$2414, 
            Global`d2] - TBgamma[1, Global`a$2417, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2417])*
         (TBgamma[1, Global`d3, Global`a$2420]*TBgamma[2, Global`a$2420, 
            Global`d4] - TBgamma[1, Global`a$2423, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2423]) - 
        (TBgamma[1, Global`d1, Global`a$2441]*TBgamma[2, Global`a$2441, 
            Global`d2] - TBgamma[1, Global`a$2438, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2438])*
         (TBgamma[1, Global`d3, Global`a$2447]*TBgamma[2, Global`a$2447, 
            Global`d4] - TBgamma[1, Global`a$2444, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2444]) - 
        (TBgamma[2, Global`a$2450, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2450] - TBgamma[2, Global`a$2453, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2453])*
         (TBgamma[2, Global`a$2456, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2456] - TBgamma[2, Global`a$2459, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2459]) + 
        2*(TBgamma[0, Global`d1, Global`a$2390]*TBgamma[3, Global`a$2390, 
            Global`d2] - TBgamma[0, Global`a$2393, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2393])*
         (TBgamma[0, Global`d3, Global`a$2396]*TBgamma[3, Global`a$2396, 
            Global`d4] - TBgamma[0, Global`a$2399, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2399]) - 
        (TBgamma[1, Global`d1, Global`a$2426]*TBgamma[3, Global`a$2426, 
            Global`d2] - TBgamma[1, Global`a$2429, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2429])*
         (TBgamma[1, Global`d3, Global`a$2432]*TBgamma[3, Global`a$2432, 
            Global`d4] - TBgamma[1, Global`a$2435, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2435]) - 
        (TBgamma[2, Global`d1, Global`a$2462]*TBgamma[3, Global`a$2462, 
            Global`d2] - TBgamma[2, Global`a$2465, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2465])*
         (TBgamma[2, Global`d3, Global`a$2468]*TBgamma[3, Global`a$2468, 
            Global`d4] - TBgamma[2, Global`a$2471, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2471]) - 
        (TBgamma[1, Global`d1, Global`a$2477]*TBgamma[3, Global`a$2477, 
            Global`d2] - TBgamma[1, Global`a$2474, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2474])*
         (TBgamma[1, Global`d3, Global`a$2483]*TBgamma[3, Global`a$2483, 
            Global`d4] - TBgamma[1, Global`a$2480, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2480]) - 
        (TBgamma[2, Global`d1, Global`a$2489]*TBgamma[3, Global`a$2489, 
            Global`d2] - TBgamma[2, Global`a$2486, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2486])*
         (TBgamma[2, Global`d3, Global`a$2495]*TBgamma[3, Global`a$2495, 
            Global`d4] - TBgamma[2, Global`a$2492, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2492]) - 
        (TBgamma[3, Global`a$2498, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2498] - TBgamma[3, Global`a$2501, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2501])*
         (TBgamma[3, Global`a$2504, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2504] - TBgamma[3, Global`a$2507, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2507]))*TBT[Global`flavor, 
        Global`af$2510, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$2510, Global`F3, Global`F4]) + 2*Global`Nc*(1 - Global`Nf)*
     Global`Nf*TBT[Global`color, Global`ac$2816, Global`A1, Global`A2]*
     TBT[Global`color, Global`ac$2816, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$2526]*TBgamma[1, Global`a$2526, 
            Global`d2] - TBgamma[0, Global`a$2529, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2529])*
         (TBgamma[0, Global`d3, Global`a$2532]*TBgamma[1, Global`a$2532, 
            Global`d4] - TBgamma[0, Global`a$2535, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2535]) - 
        (TBgamma[1, Global`a$2562, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2562] - TBgamma[1, Global`a$2565, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2565])*
         (TBgamma[1, Global`a$2568, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2568] - TBgamma[1, Global`a$2571, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2571]) + 
        2*(TBgamma[0, Global`d1, Global`a$2538]*TBgamma[2, Global`a$2538, 
            Global`d2] - TBgamma[0, Global`a$2541, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2541])*
         (TBgamma[0, Global`d3, Global`a$2544]*TBgamma[2, Global`a$2544, 
            Global`d4] - TBgamma[0, Global`a$2547, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2547]) - 
        (TBgamma[1, Global`d1, Global`a$2574]*TBgamma[2, Global`a$2574, 
            Global`d2] - TBgamma[1, Global`a$2577, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2577])*
         (TBgamma[1, Global`d3, Global`a$2580]*TBgamma[2, Global`a$2580, 
            Global`d4] - TBgamma[1, Global`a$2583, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2583]) - 
        (TBgamma[1, Global`d1, Global`a$2601]*TBgamma[2, Global`a$2601, 
            Global`d2] - TBgamma[1, Global`a$2598, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2598])*
         (TBgamma[1, Global`d3, Global`a$2607]*TBgamma[2, Global`a$2607, 
            Global`d4] - TBgamma[1, Global`a$2604, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2604]) - 
        (TBgamma[2, Global`a$2610, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2610] - TBgamma[2, Global`a$2613, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2613])*
         (TBgamma[2, Global`a$2616, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2616] - TBgamma[2, Global`a$2619, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2619]) + 
        2*(TBgamma[0, Global`d1, Global`a$2550]*TBgamma[3, Global`a$2550, 
            Global`d2] - TBgamma[0, Global`a$2553, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2553])*
         (TBgamma[0, Global`d3, Global`a$2556]*TBgamma[3, Global`a$2556, 
            Global`d4] - TBgamma[0, Global`a$2559, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2559]) - 
        (TBgamma[1, Global`d1, Global`a$2586]*TBgamma[3, Global`a$2586, 
            Global`d2] - TBgamma[1, Global`a$2589, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2589])*
         (TBgamma[1, Global`d3, Global`a$2592]*TBgamma[3, Global`a$2592, 
            Global`d4] - TBgamma[1, Global`a$2595, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2595]) - 
        (TBgamma[2, Global`d1, Global`a$2622]*TBgamma[3, Global`a$2622, 
            Global`d2] - TBgamma[2, Global`a$2625, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2625])*
         (TBgamma[2, Global`d3, Global`a$2628]*TBgamma[3, Global`a$2628, 
            Global`d4] - TBgamma[2, Global`a$2631, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2631]) - 
        (TBgamma[1, Global`d1, Global`a$2637]*TBgamma[3, Global`a$2637, 
            Global`d2] - TBgamma[1, Global`a$2634, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2634])*
         (TBgamma[1, Global`d3, Global`a$2644]*TBgamma[3, Global`a$2644, 
            Global`d4] - TBgamma[1, Global`a$2640, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2640]) - 
        (TBgamma[2, Global`d1, Global`a$2650]*TBgamma[3, Global`a$2650, 
            Global`d2] - TBgamma[2, Global`a$2647, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2647])*
         (TBgamma[2, Global`d3, Global`a$2656]*TBgamma[3, Global`a$2656, 
            Global`d4] - TBgamma[2, Global`a$2653, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2653]) - 
        (TBgamma[3, Global`a$2659, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2659] - TBgamma[3, Global`a$2662, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2662])*
         (TBgamma[3, Global`a$2665, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2665] - TBgamma[3, Global`a$2668, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2668])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$2671]*TBgamma[1, Global`a$2671, 
            Global`d2] - TBgamma[0, Global`a$2674, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2674])*
         (TBgamma[0, Global`d3, Global`a$2677]*TBgamma[1, Global`a$2677, 
            Global`d4] - TBgamma[0, Global`a$2680, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2680]) - 
        (TBgamma[1, Global`a$2707, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2707] - TBgamma[1, Global`a$2710, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2710])*
         (TBgamma[1, Global`a$2713, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2713] - TBgamma[1, Global`a$2716, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2716]) + 
        2*(TBgamma[0, Global`d1, Global`a$2683]*TBgamma[2, Global`a$2683, 
            Global`d2] - TBgamma[0, Global`a$2686, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2686])*
         (TBgamma[0, Global`d3, Global`a$2689]*TBgamma[2, Global`a$2689, 
            Global`d4] - TBgamma[0, Global`a$2692, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2692]) - 
        (TBgamma[1, Global`d1, Global`a$2719]*TBgamma[2, Global`a$2719, 
            Global`d2] - TBgamma[1, Global`a$2722, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2722])*
         (TBgamma[1, Global`d3, Global`a$2725]*TBgamma[2, Global`a$2725, 
            Global`d4] - TBgamma[1, Global`a$2728, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2728]) - 
        (TBgamma[1, Global`d1, Global`a$2746]*TBgamma[2, Global`a$2746, 
            Global`d2] - TBgamma[1, Global`a$2743, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2743])*
         (TBgamma[1, Global`d3, Global`a$2752]*TBgamma[2, Global`a$2752, 
            Global`d4] - TBgamma[1, Global`a$2749, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2749]) - 
        (TBgamma[2, Global`a$2755, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2755] - TBgamma[2, Global`a$2758, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2758])*
         (TBgamma[2, Global`a$2761, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2761] - TBgamma[2, Global`a$2764, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2764]) + 
        2*(TBgamma[0, Global`d1, Global`a$2695]*TBgamma[3, Global`a$2695, 
            Global`d2] - TBgamma[0, Global`a$2698, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2698])*
         (TBgamma[0, Global`d3, Global`a$2701]*TBgamma[3, Global`a$2701, 
            Global`d4] - TBgamma[0, Global`a$2704, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2704]) - 
        (TBgamma[1, Global`d1, Global`a$2731]*TBgamma[3, Global`a$2731, 
            Global`d2] - TBgamma[1, Global`a$2734, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2734])*
         (TBgamma[1, Global`d3, Global`a$2737]*TBgamma[3, Global`a$2737, 
            Global`d4] - TBgamma[1, Global`a$2740, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2740]) - 
        (TBgamma[2, Global`d1, Global`a$2767]*TBgamma[3, Global`a$2767, 
            Global`d2] - TBgamma[2, Global`a$2770, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2770])*
         (TBgamma[2, Global`d3, Global`a$2773]*TBgamma[3, Global`a$2773, 
            Global`d4] - TBgamma[2, Global`a$2776, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2776]) - 
        (TBgamma[1, Global`d1, Global`a$2782]*TBgamma[3, Global`a$2782, 
            Global`d2] - TBgamma[1, Global`a$2779, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2779])*
         (TBgamma[1, Global`d3, Global`a$2788]*TBgamma[3, Global`a$2788, 
            Global`d4] - TBgamma[1, Global`a$2785, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2785]) - 
        (TBgamma[2, Global`d1, Global`a$2794]*TBgamma[3, Global`a$2794, 
            Global`d2] - TBgamma[2, Global`a$2791, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2791])*
         (TBgamma[2, Global`d3, Global`a$2800]*TBgamma[3, Global`a$2800, 
            Global`d4] - TBgamma[2, Global`a$2797, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2797]) - 
        (TBgamma[3, Global`a$2803, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2803] - TBgamma[3, Global`a$2806, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2806])*
         (TBgamma[3, Global`a$2809, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2809] - TBgamma[3, Global`a$2813, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2813]))*TBT[Global`flavor, 
        Global`af$2819, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$2819, Global`F3, Global`F4]))/
   (Global`Nc^2*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), 
 ((TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
      Global`A3, Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, 
       Global`F2] - TBdeltaFund[Global`flavor, Global`F1, 3]*
       TBdeltaFund[Global`flavor, Global`F2, 3])*
     (TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$2900, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2900, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2900, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2900, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$2900, 0]*TBgamma[0, Global`d1, 
           Global`dc$2903]) + TBgamma[Global`i$2900, Global`d1, 
         Global`dc$2903])*(-(TBdeltaLorentz[Global`i$2900, 0]*
          TBgamma[0, Global`d3, Global`dc$2906]) + TBgamma[Global`i$2900, 
         Global`d3, Global`dc$2906])*TBgamma5[Global`dc$2903, Global`d2]*
       TBgamma5[Global`dc$2906, Global`d4]))/((-2 + Global`Nc)*Global`Nc) - 
   (6*Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$3035]*TBgamma[0, Global`d3, 
        Global`dc$3038]*TBgamma5[Global`dc$3035, Global`d2]*
       TBgamma5[Global`dc$3038, Global`d4]))/(-2 + Global`Nc)^2 - 
   (TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$3193, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$3193, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$3193, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$3193, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$3193, 0]*TBgamma[0, Global`d1, 
           Global`dc$3196]) + TBgamma[Global`i$3193, Global`d1, 
         Global`dc$3196])*(-(TBdeltaLorentz[Global`i$3193, 0]*
          TBgamma[0, Global`d3, Global`dc$3199]) + TBgamma[Global`i$3193, 
         Global`d3, Global`dc$3199])*TBgamma5[Global`dc$3196, Global`d2]*
       TBgamma5[Global`dc$3199, Global`d4]))/((-2 + Global`Nc)*Global`Nc) + 
   (3*Global`Nc*(TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$2969]*TBgamma[0, Global`d3, 
        Global`dc$2972]*TBgamma5[Global`dc$2969, Global`d2]*
       TBgamma5[Global`dc$2972, Global`d4])*TBT[Global`color, Global`a$2975, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2975, Global`A3, 
      Global`A4])/((-2 + Global`Nc)*(-1 + Global`Nc^2)) + 
   ((TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$2991, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2991, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2991, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2991, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$2991, 0]*TBgamma[0, Global`d1, 
           Global`dc$2994]) + TBgamma[Global`i$2991, Global`d1, 
         Global`dc$2994])*(-(TBdeltaLorentz[Global`i$2991, 0]*
          TBgamma[0, Global`d3, Global`dc$2997]) + TBgamma[Global`i$2991, 
         Global`d3, Global`dc$2997])*TBgamma5[Global`dc$2994, Global`d2]*
       TBgamma5[Global`dc$2997, Global`d4])*TBT[Global`color, Global`a$3000, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3000, Global`A3, 
      Global`A4])/(-1 + Global`Nc^2) + 
   (4*Global`Nc*(-1 + 2*Global`Nc)*Global`Nf*TBdeltaFund[Global`flavor, 
      Global`F1, 3]*TBdeltaFund[Global`flavor, Global`F2, 3]*
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
      Global`F4, 3]*((-(TBdeltaLorentz[Global`i$3079, 0]*
          TBgamma[0, Global`d1, Global`d2]) + TBgamma[Global`i$3079, 
         Global`d1, Global`d2])*(-(TBdeltaLorentz[Global`i$3079, 0]*
          TBgamma[0, Global`d3, Global`d4]) + TBgamma[Global`i$3079, 
         Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$3079, 0]*TBgamma[0, Global`d1, 
           Global`dc$3082]) + TBgamma[Global`i$3079, Global`d1, 
         Global`dc$3082])*(-(TBdeltaLorentz[Global`i$3079, 0]*
          TBgamma[0, Global`d3, Global`dc$3085]) + TBgamma[Global`i$3079, 
         Global`d3, Global`dc$3085])*TBgamma5[Global`dc$3082, Global`d2]*
       TBgamma5[Global`dc$3085, Global`d4])*TBT[Global`color, Global`a$3088, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3088, Global`A3, 
      Global`A4])/((-2 + Global`Nc)^2*(-1 + Global`Nc^2)) - 
   (3*Global`Nc*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$3262]*TBgamma[0, Global`d3, 
        Global`dc$3265]*TBgamma5[Global`dc$3262, Global`d2]*
       TBgamma5[Global`dc$3265, Global`d4])*TBT[Global`color, Global`a$3268, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3268, Global`A3, 
      Global`A4])/((-2 + Global`Nc)*(-1 + Global`Nc^2)) - 
   (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$3284, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$3284, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$3284, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$3284, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$3284, 0]*TBgamma[0, Global`d1, 
           Global`dc$3287]) + TBgamma[Global`i$3284, Global`d1, 
         Global`dc$3287])*(-(TBdeltaLorentz[Global`i$3284, 0]*
          TBgamma[0, Global`d3, Global`dc$3290]) + TBgamma[Global`i$3284, 
         Global`d3, Global`dc$3290])*TBgamma5[Global`dc$3287, Global`d2]*
       TBgamma5[Global`dc$3290, Global`d4])*TBT[Global`color, Global`a$3293, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3293, Global`A3, 
      Global`A4])/(-1 + Global`Nc^2))/(16*(-1 + Global`Nf)), 
 (-8*(2 - 3*Global`Nc^2)*(9 - 8*Global`Nf)*Global`Nf*
    (2 + Global`Nf - 2*Global`Nf^2)*TBdeltaFund[Global`color, Global`A1, 
     Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
     Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
    TBdeltaFund[Global`flavor, Global`F4, 3]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
   4*Global`Nc*(9 - 8*Global`Nf)*Global`Nf^2*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$1736, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$1736, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$1736, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$1736, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$1736, 0]*TBgamma[0, Global`d1, 
          Global`dc$1739]) + TBgamma[Global`i$1736, Global`d1, 
        Global`dc$1739])*(-(TBdeltaLorentz[Global`i$1736, 0]*
         TBgamma[0, Global`d3, Global`dc$1742]) + TBgamma[Global`i$1736, 
        Global`d3, Global`dc$1742])*TBgamma5[Global`dc$1739, Global`d2]*
      TBgamma5[Global`dc$1742, Global`d4]) + 4*Global`Nc*(9 - 8*Global`Nf)*
    Global`Nf*(2 + Global`Nf - 2*Global`Nf^2)*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
     Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
    TBdeltaFund[Global`flavor, Global`F4, 3]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$1893]*TBgamma[0, Global`d3, 
       Global`dc$1896]*TBgamma5[Global`dc$1893, Global`d2]*
      TBgamma5[Global`dc$1896, Global`d4]) + 
   4*Global`Nc*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$2029, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$2029, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$2029, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$2029, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$2029, 0]*TBgamma[0, Global`d1, 
          Global`dc$2032]) + TBgamma[Global`i$2029, Global`d1, 
        Global`dc$2032])*(-(TBdeltaLorentz[Global`i$2029, 0]*
         TBgamma[0, Global`d3, Global`dc$2035]) + TBgamma[Global`i$2029, 
        Global`d3, Global`dc$2035])*TBgamma5[Global`dc$2032, Global`d2]*
      TBgamma5[Global`dc$2035, Global`d4]) + 24*Global`Nc^2*(9 - 8*Global`Nf)*
    Global`Nf^2*(TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
      TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$1799]*TBgamma[0, Global`d3, 
       Global`dc$1802]*TBgamma5[Global`dc$1799, Global`d2]*
      TBgamma5[Global`dc$1802, Global`d4])*TBT[Global`color, Global`a$1805, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1805, Global`A3, 
     Global`A4] + 24*Global`Nc^2*(9 - 8*Global`Nf)*Global`Nf*
    (2 + Global`Nf - 2*Global`Nf^2)*TBdeltaFund[Global`flavor, Global`F1, 3]*
    TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
     Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
    ((-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$1931, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$1931, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d1, 
          Global`dc$1934]) + TBgamma[Global`i$1931, Global`d1, 
        Global`dc$1934])*(-(TBdeltaLorentz[Global`i$1931, 0]*
         TBgamma[0, Global`d3, Global`dc$1937]) + TBgamma[Global`i$1931, 
        Global`d3, Global`dc$1937])*TBgamma5[Global`dc$1934, Global`d2]*
      TBgamma5[Global`dc$1937, Global`d4])*TBT[Global`color, Global`a$1940, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1940, Global`A3, 
     Global`A4] - 32*Global`Nc*(9 - 8*Global`Nf)*Global`Nf*
    (2 + Global`Nf - 2*Global`Nf^2)*TBdeltaFund[Global`flavor, Global`F1, 3]*
    TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
     Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    TBT[Global`color, Global`a$1994, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$1994, Global`A3, Global`A4] + 
   24*Global`Nc^2*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$2092]*TBgamma[0, Global`d3, 
       Global`dc$2095]*TBgamma5[Global`dc$2092, Global`d2]*
      TBgamma5[Global`dc$2095, Global`d4])*TBT[Global`color, Global`a$2098, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$2098, Global`A3, 
     Global`A4] - (4 - 3*Global`Nc^2)*(1 - Global`Nf)*Global`Nf*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (2*(TBgamma[0, Global`d1, Global`a$2221]*TBgamma[1, Global`a$2221, 
           Global`d2] - TBgamma[0, Global`a$2224, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2224])*
        (TBgamma[0, Global`d3, Global`a$2227]*TBgamma[1, Global`a$2227, 
           Global`d4] - TBgamma[0, Global`a$2230, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2230]) - 
       (TBgamma[1, Global`a$2258, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$2258] - TBgamma[1, Global`a$2261, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2261])*
        (TBgamma[1, Global`a$2264, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$2264] - TBgamma[1, Global`a$2267, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2267]) + 
       2*(TBgamma[0, Global`d1, Global`a$2233]*TBgamma[2, Global`a$2233, 
           Global`d2] - TBgamma[0, Global`a$2236, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2236])*
        (TBgamma[0, Global`d3, Global`a$2239]*TBgamma[2, Global`a$2239, 
           Global`d4] - TBgamma[0, Global`a$2242, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2242]) - 
       (TBgamma[1, Global`d1, Global`a$2270]*TBgamma[2, Global`a$2270, 
           Global`d2] - TBgamma[1, Global`a$2273, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2273])*
        (TBgamma[1, Global`d3, Global`a$2276]*TBgamma[2, Global`a$2276, 
           Global`d4] - TBgamma[1, Global`a$2279, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2279]) - 
       (TBgamma[1, Global`d1, Global`a$2297]*TBgamma[2, Global`a$2297, 
           Global`d2] - TBgamma[1, Global`a$2294, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2294])*
        (TBgamma[1, Global`d3, Global`a$2303]*TBgamma[2, Global`a$2303, 
           Global`d4] - TBgamma[1, Global`a$2300, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2300]) - 
       (TBgamma[2, Global`a$2306, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$2306] - TBgamma[2, Global`a$2309, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2309])*
        (TBgamma[2, Global`a$2312, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$2312] - TBgamma[2, Global`a$2315, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2315]) + 
       2*(TBgamma[0, Global`d1, Global`a$2246]*TBgamma[3, Global`a$2246, 
           Global`d2] - TBgamma[0, Global`a$2249, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2249])*
        (TBgamma[0, Global`d3, Global`a$2252]*TBgamma[3, Global`a$2252, 
           Global`d4] - TBgamma[0, Global`a$2255, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2255]) - 
       (TBgamma[1, Global`d1, Global`a$2282]*TBgamma[3, Global`a$2282, 
           Global`d2] - TBgamma[1, Global`a$2285, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2285])*
        (TBgamma[1, Global`d3, Global`a$2288]*TBgamma[3, Global`a$2288, 
           Global`d4] - TBgamma[1, Global`a$2291, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2291]) - 
       (TBgamma[2, Global`d1, Global`a$2318]*TBgamma[3, Global`a$2318, 
           Global`d2] - TBgamma[2, Global`a$2321, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2321])*
        (TBgamma[2, Global`d3, Global`a$2324]*TBgamma[3, Global`a$2324, 
           Global`d4] - TBgamma[2, Global`a$2327, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2327]) - 
       (TBgamma[1, Global`d1, Global`a$2333]*TBgamma[3, Global`a$2333, 
           Global`d2] - TBgamma[1, Global`a$2330, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2330])*
        (TBgamma[1, Global`d3, Global`a$2339]*TBgamma[3, Global`a$2339, 
           Global`d4] - TBgamma[1, Global`a$2336, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2336]) - 
       (TBgamma[2, Global`d1, Global`a$2345]*TBgamma[3, Global`a$2345, 
           Global`d2] - TBgamma[2, Global`a$2342, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2342])*
        (TBgamma[2, Global`d3, Global`a$2351]*TBgamma[3, Global`a$2351, 
           Global`d4] - TBgamma[2, Global`a$2348, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2348]) - 
       (TBgamma[3, Global`a$2354, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$2354] - TBgamma[3, Global`a$2357, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2357])*
        (TBgamma[3, Global`a$2360, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$2360] - TBgamma[3, Global`a$2363, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2363])) + 
     9*(2*(TBgamma[0, Global`d1, Global`a$2366]*TBgamma[1, Global`a$2366, 
           Global`d2] - TBgamma[0, Global`a$2369, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2369])*
        (TBgamma[0, Global`d3, Global`a$2372]*TBgamma[1, Global`a$2372, 
           Global`d4] - TBgamma[0, Global`a$2375, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2375]) - 
       (TBgamma[1, Global`a$2402, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$2402] - TBgamma[1, Global`a$2405, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2405])*
        (TBgamma[1, Global`a$2408, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$2408] - TBgamma[1, Global`a$2411, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2411]) + 
       2*(TBgamma[0, Global`d1, Global`a$2378]*TBgamma[2, Global`a$2378, 
           Global`d2] - TBgamma[0, Global`a$2381, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2381])*
        (TBgamma[0, Global`d3, Global`a$2384]*TBgamma[2, Global`a$2384, 
           Global`d4] - TBgamma[0, Global`a$2387, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2387]) - 
       (TBgamma[1, Global`d1, Global`a$2414]*TBgamma[2, Global`a$2414, 
           Global`d2] - TBgamma[1, Global`a$2417, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2417])*
        (TBgamma[1, Global`d3, Global`a$2420]*TBgamma[2, Global`a$2420, 
           Global`d4] - TBgamma[1, Global`a$2423, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2423]) - 
       (TBgamma[1, Global`d1, Global`a$2441]*TBgamma[2, Global`a$2441, 
           Global`d2] - TBgamma[1, Global`a$2438, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2438])*
        (TBgamma[1, Global`d3, Global`a$2447]*TBgamma[2, Global`a$2447, 
           Global`d4] - TBgamma[1, Global`a$2444, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2444]) - 
       (TBgamma[2, Global`a$2450, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$2450] - TBgamma[2, Global`a$2453, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2453])*
        (TBgamma[2, Global`a$2456, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$2456] - TBgamma[2, Global`a$2459, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2459]) + 
       2*(TBgamma[0, Global`d1, Global`a$2390]*TBgamma[3, Global`a$2390, 
           Global`d2] - TBgamma[0, Global`a$2393, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2393])*
        (TBgamma[0, Global`d3, Global`a$2396]*TBgamma[3, Global`a$2396, 
           Global`d4] - TBgamma[0, Global`a$2399, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2399]) - 
       (TBgamma[1, Global`d1, Global`a$2426]*TBgamma[3, Global`a$2426, 
           Global`d2] - TBgamma[1, Global`a$2429, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2429])*
        (TBgamma[1, Global`d3, Global`a$2432]*TBgamma[3, Global`a$2432, 
           Global`d4] - TBgamma[1, Global`a$2435, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2435]) - 
       (TBgamma[2, Global`d1, Global`a$2462]*TBgamma[3, Global`a$2462, 
           Global`d2] - TBgamma[2, Global`a$2465, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2465])*
        (TBgamma[2, Global`d3, Global`a$2468]*TBgamma[3, Global`a$2468, 
           Global`d4] - TBgamma[2, Global`a$2471, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2471]) - 
       (TBgamma[1, Global`d1, Global`a$2477]*TBgamma[3, Global`a$2477, 
           Global`d2] - TBgamma[1, Global`a$2474, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2474])*
        (TBgamma[1, Global`d3, Global`a$2483]*TBgamma[3, Global`a$2483, 
           Global`d4] - TBgamma[1, Global`a$2480, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2480]) - 
       (TBgamma[2, Global`d1, Global`a$2489]*TBgamma[3, Global`a$2489, 
           Global`d2] - TBgamma[2, Global`a$2486, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2486])*
        (TBgamma[2, Global`d3, Global`a$2495]*TBgamma[3, Global`a$2495, 
           Global`d4] - TBgamma[2, Global`a$2492, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2492]) - 
       (TBgamma[3, Global`a$2498, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$2498] - TBgamma[3, Global`a$2501, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2501])*
        (TBgamma[3, Global`a$2504, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$2504] - TBgamma[3, Global`a$2507, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2507]))*TBT[Global`flavor, 
       Global`af$2510, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$2510, Global`F3, Global`F4]) - 8*Global`Nc*(1 - Global`Nf)*
    Global`Nf*TBT[Global`color, Global`ac$2816, Global`A1, Global`A2]*
    TBT[Global`color, Global`ac$2816, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (2*(TBgamma[0, Global`d1, Global`a$2526]*TBgamma[1, Global`a$2526, 
           Global`d2] - TBgamma[0, Global`a$2529, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2529])*
        (TBgamma[0, Global`d3, Global`a$2532]*TBgamma[1, Global`a$2532, 
           Global`d4] - TBgamma[0, Global`a$2535, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2535]) - 
       (TBgamma[1, Global`a$2562, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$2562] - TBgamma[1, Global`a$2565, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2565])*
        (TBgamma[1, Global`a$2568, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$2568] - TBgamma[1, Global`a$2571, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2571]) + 
       2*(TBgamma[0, Global`d1, Global`a$2538]*TBgamma[2, Global`a$2538, 
           Global`d2] - TBgamma[0, Global`a$2541, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2541])*
        (TBgamma[0, Global`d3, Global`a$2544]*TBgamma[2, Global`a$2544, 
           Global`d4] - TBgamma[0, Global`a$2547, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2547]) - 
       (TBgamma[1, Global`d1, Global`a$2574]*TBgamma[2, Global`a$2574, 
           Global`d2] - TBgamma[1, Global`a$2577, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2577])*
        (TBgamma[1, Global`d3, Global`a$2580]*TBgamma[2, Global`a$2580, 
           Global`d4] - TBgamma[1, Global`a$2583, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2583]) - 
       (TBgamma[1, Global`d1, Global`a$2601]*TBgamma[2, Global`a$2601, 
           Global`d2] - TBgamma[1, Global`a$2598, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2598])*
        (TBgamma[1, Global`d3, Global`a$2607]*TBgamma[2, Global`a$2607, 
           Global`d4] - TBgamma[1, Global`a$2604, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2604]) - 
       (TBgamma[2, Global`a$2610, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$2610] - TBgamma[2, Global`a$2613, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2613])*
        (TBgamma[2, Global`a$2616, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$2616] - TBgamma[2, Global`a$2619, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2619]) + 
       2*(TBgamma[0, Global`d1, Global`a$2550]*TBgamma[3, Global`a$2550, 
           Global`d2] - TBgamma[0, Global`a$2553, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2553])*
        (TBgamma[0, Global`d3, Global`a$2556]*TBgamma[3, Global`a$2556, 
           Global`d4] - TBgamma[0, Global`a$2559, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2559]) - 
       (TBgamma[1, Global`d1, Global`a$2586]*TBgamma[3, Global`a$2586, 
           Global`d2] - TBgamma[1, Global`a$2589, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2589])*
        (TBgamma[1, Global`d3, Global`a$2592]*TBgamma[3, Global`a$2592, 
           Global`d4] - TBgamma[1, Global`a$2595, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2595]) - 
       (TBgamma[2, Global`d1, Global`a$2622]*TBgamma[3, Global`a$2622, 
           Global`d2] - TBgamma[2, Global`a$2625, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2625])*
        (TBgamma[2, Global`d3, Global`a$2628]*TBgamma[3, Global`a$2628, 
           Global`d4] - TBgamma[2, Global`a$2631, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2631]) - 
       (TBgamma[1, Global`d1, Global`a$2637]*TBgamma[3, Global`a$2637, 
           Global`d2] - TBgamma[1, Global`a$2634, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2634])*
        (TBgamma[1, Global`d3, Global`a$2644]*TBgamma[3, Global`a$2644, 
           Global`d4] - TBgamma[1, Global`a$2640, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2640]) - 
       (TBgamma[2, Global`d1, Global`a$2650]*TBgamma[3, Global`a$2650, 
           Global`d2] - TBgamma[2, Global`a$2647, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2647])*
        (TBgamma[2, Global`d3, Global`a$2656]*TBgamma[3, Global`a$2656, 
           Global`d4] - TBgamma[2, Global`a$2653, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2653]) - 
       (TBgamma[3, Global`a$2659, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$2659] - TBgamma[3, Global`a$2662, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2662])*
        (TBgamma[3, Global`a$2665, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$2665] - TBgamma[3, Global`a$2668, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2668])) + 
     9*(2*(TBgamma[0, Global`d1, Global`a$2671]*TBgamma[1, Global`a$2671, 
           Global`d2] - TBgamma[0, Global`a$2674, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2674])*
        (TBgamma[0, Global`d3, Global`a$2677]*TBgamma[1, Global`a$2677, 
           Global`d4] - TBgamma[0, Global`a$2680, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2680]) - 
       (TBgamma[1, Global`a$2707, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$2707] - TBgamma[1, Global`a$2710, Global`d2]*
          TBgamma[1, Global`d1, Global`a$2710])*
        (TBgamma[1, Global`a$2713, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$2713] - TBgamma[1, Global`a$2716, Global`d4]*
          TBgamma[1, Global`d3, Global`a$2716]) + 
       2*(TBgamma[0, Global`d1, Global`a$2683]*TBgamma[2, Global`a$2683, 
           Global`d2] - TBgamma[0, Global`a$2686, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2686])*
        (TBgamma[0, Global`d3, Global`a$2689]*TBgamma[2, Global`a$2689, 
           Global`d4] - TBgamma[0, Global`a$2692, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2692]) - 
       (TBgamma[1, Global`d1, Global`a$2719]*TBgamma[2, Global`a$2719, 
           Global`d2] - TBgamma[1, Global`a$2722, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2722])*
        (TBgamma[1, Global`d3, Global`a$2725]*TBgamma[2, Global`a$2725, 
           Global`d4] - TBgamma[1, Global`a$2728, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2728]) - 
       (TBgamma[1, Global`d1, Global`a$2746]*TBgamma[2, Global`a$2746, 
           Global`d2] - TBgamma[1, Global`a$2743, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2743])*
        (TBgamma[1, Global`d3, Global`a$2752]*TBgamma[2, Global`a$2752, 
           Global`d4] - TBgamma[1, Global`a$2749, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2749]) - 
       (TBgamma[2, Global`a$2755, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$2755] - TBgamma[2, Global`a$2758, Global`d2]*
          TBgamma[2, Global`d1, Global`a$2758])*
        (TBgamma[2, Global`a$2761, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$2761] - TBgamma[2, Global`a$2764, Global`d4]*
          TBgamma[2, Global`d3, Global`a$2764]) + 
       2*(TBgamma[0, Global`d1, Global`a$2695]*TBgamma[3, Global`a$2695, 
           Global`d2] - TBgamma[0, Global`a$2698, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2698])*
        (TBgamma[0, Global`d3, Global`a$2701]*TBgamma[3, Global`a$2701, 
           Global`d4] - TBgamma[0, Global`a$2704, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2704]) - 
       (TBgamma[1, Global`d1, Global`a$2731]*TBgamma[3, Global`a$2731, 
           Global`d2] - TBgamma[1, Global`a$2734, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2734])*
        (TBgamma[1, Global`d3, Global`a$2737]*TBgamma[3, Global`a$2737, 
           Global`d4] - TBgamma[1, Global`a$2740, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2740]) - 
       (TBgamma[2, Global`d1, Global`a$2767]*TBgamma[3, Global`a$2767, 
           Global`d2] - TBgamma[2, Global`a$2770, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2770])*
        (TBgamma[2, Global`d3, Global`a$2773]*TBgamma[3, Global`a$2773, 
           Global`d4] - TBgamma[2, Global`a$2776, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2776]) - 
       (TBgamma[1, Global`d1, Global`a$2782]*TBgamma[3, Global`a$2782, 
           Global`d2] - TBgamma[1, Global`a$2779, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2779])*
        (TBgamma[1, Global`d3, Global`a$2788]*TBgamma[3, Global`a$2788, 
           Global`d4] - TBgamma[1, Global`a$2785, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2785]) - 
       (TBgamma[2, Global`d1, Global`a$2794]*TBgamma[3, Global`a$2794, 
           Global`d2] - TBgamma[2, Global`a$2791, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2791])*
        (TBgamma[2, Global`d3, Global`a$2800]*TBgamma[3, Global`a$2800, 
           Global`d4] - TBgamma[2, Global`a$2797, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2797]) - 
       (TBgamma[3, Global`a$2803, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$2803] - TBgamma[3, Global`a$2806, Global`d2]*
          TBgamma[3, Global`d1, Global`a$2806])*
        (TBgamma[3, Global`a$2809, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$2809] - TBgamma[3, Global`a$2813, Global`d4]*
          TBgamma[3, Global`d3, Global`a$2813]))*TBT[Global`flavor, 
       Global`af$2819, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$2819, Global`F3, Global`F4]) - 
   24*Global`Nc^2*(-1 + Global`Nf)*Global`Nf*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     9*TBT[Global`flavor, Global`f$2186, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$2186, Global`F3, Global`F4]))/
  (128*Global`Nc^4*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*(-2 + Global`Nf^2)), 
 -1/32*(8*(-1 + Global`Nc^2)*Global`Nf*(-9 + 8*Global`Nf)*
     (-2 - Global`Nf + 2*Global`Nf^2)*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
    2*Global`Nc*(1 - Global`Nc^2)*(9 - 8*Global`Nf)*Global`Nf^2*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$2859, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2859, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2859, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2859, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$2859, 0]*TBgamma[0, Global`d1, 
           Global`dc$2862]) + TBgamma[Global`i$2859, Global`d1, 
         Global`dc$2862])*(-(TBdeltaLorentz[Global`i$2859, 0]*
          TBgamma[0, Global`d3, Global`dc$2865]) + TBgamma[Global`i$2859, 
         Global`d3, Global`dc$2865])*TBgamma5[Global`dc$2862, Global`d2]*
       TBgamma5[Global`dc$2865, Global`d4]) + 2*Global`Nc*(1 - Global`Nc^2)*
     (9 - 8*Global`Nf)*Global`Nf*(2 + Global`Nf - 2*Global`Nf^2)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$3016]*TBgamma[0, Global`d3, 
        Global`dc$3019]*TBgamma5[Global`dc$3016, Global`d2]*
       TBgamma5[Global`dc$3019, Global`d4]) + 2*Global`Nc*(1 - Global`Nc^2)*
     (18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$3152, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$3152, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$3152, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$3152, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$3152, 0]*TBgamma[0, Global`d1, 
           Global`dc$3155]) + TBgamma[Global`i$3152, Global`d1, 
         Global`dc$3155])*(-(TBdeltaLorentz[Global`i$3152, 0]*
          TBgamma[0, Global`d3, Global`dc$3158]) + TBgamma[Global`i$3152, 
         Global`d3, Global`dc$3158])*TBgamma5[Global`dc$3155, Global`d2]*
       TBgamma5[Global`dc$3158, Global`d4]) + 
    12*Global`Nc^2*(9 - 8*Global`Nf)*Global`Nf^2*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2922]*TBgamma[0, Global`d3, 
        Global`dc$2925]*TBgamma5[Global`dc$2922, Global`d2]*
       TBgamma5[Global`dc$2925, Global`d4])*TBT[Global`color, Global`a$2928, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2928, Global`A3, 
      Global`A4] + 12*Global`Nc^2*(9 - 8*Global`Nf)*Global`Nf*
     (2 + Global`Nf - 2*Global`Nf^2)*TBdeltaFund[Global`flavor, Global`F1, 3]*
     TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
      Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
     ((-(TBdeltaLorentz[Global`i$3054, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$3054, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$3054, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$3054, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$3054, 0]*TBgamma[0, Global`d1, 
           Global`dc$3057]) + TBgamma[Global`i$3054, Global`d1, 
         Global`dc$3057])*(-(TBdeltaLorentz[Global`i$3054, 0]*
          TBgamma[0, Global`d3, Global`dc$3060]) + TBgamma[Global`i$3054, 
         Global`d3, Global`dc$3060])*TBgamma5[Global`dc$3057, Global`d2]*
       TBgamma5[Global`dc$3060, Global`d4])*TBT[Global`color, Global`a$3063, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3063, Global`A3, 
      Global`A4] - 8*Global`Nc*(2 + Global`Nc^2)*(9 - 8*Global`Nf)*Global`Nf*
     (2 + Global`Nf - 2*Global`Nf^2)*TBdeltaFund[Global`flavor, Global`F1, 3]*
     TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
      Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$3117, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$3117, Global`A3, Global`A4] + 
    12*Global`Nc^2*(18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$3215]*TBgamma[0, Global`d3, 
        Global`dc$3218]*TBgamma5[Global`dc$3215, Global`d2]*
       TBgamma5[Global`dc$3218, Global`d4])*TBT[Global`color, Global`a$3221, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3221, Global`A3, 
      Global`A4] - 2*(1 - Global`Nc^2)*(1 - Global`Nf)*Global`Nf*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$3344]*TBgamma[1, Global`a$3344, 
            Global`d2] - TBgamma[0, Global`a$3347, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3347])*
         (TBgamma[0, Global`d3, Global`a$3350]*TBgamma[1, Global`a$3350, 
            Global`d4] - TBgamma[0, Global`a$3353, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3353]) - 
        (TBgamma[1, Global`a$3381, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$3381] - TBgamma[1, Global`a$3384, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3384])*
         (TBgamma[1, Global`a$3387, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$3387] - TBgamma[1, Global`a$3390, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3390]) + 
        2*(TBgamma[0, Global`d1, Global`a$3356]*TBgamma[2, Global`a$3356, 
            Global`d2] - TBgamma[0, Global`a$3359, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3359])*
         (TBgamma[0, Global`d3, Global`a$3362]*TBgamma[2, Global`a$3362, 
            Global`d4] - TBgamma[0, Global`a$3365, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3365]) - 
        (TBgamma[1, Global`d1, Global`a$3393]*TBgamma[2, Global`a$3393, 
            Global`d2] - TBgamma[1, Global`a$3396, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3396])*
         (TBgamma[1, Global`d3, Global`a$3400]*TBgamma[2, Global`a$3400, 
            Global`d4] - TBgamma[1, Global`a$3403, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3403]) - 
        (TBgamma[1, Global`d1, Global`a$3421]*TBgamma[2, Global`a$3421, 
            Global`d2] - TBgamma[1, Global`a$3418, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3418])*
         (TBgamma[1, Global`d3, Global`a$3427]*TBgamma[2, Global`a$3427, 
            Global`d4] - TBgamma[1, Global`a$3424, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3424]) - 
        (TBgamma[2, Global`a$3430, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$3430] - TBgamma[2, Global`a$3433, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3433])*
         (TBgamma[2, Global`a$3436, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$3436] - TBgamma[2, Global`a$3439, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3439]) + 
        2*(TBgamma[0, Global`d1, Global`a$3368]*TBgamma[3, Global`a$3368, 
            Global`d2] - TBgamma[0, Global`a$3371, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3371])*
         (TBgamma[0, Global`d3, Global`a$3374]*TBgamma[3, Global`a$3374, 
            Global`d4] - TBgamma[0, Global`a$3377, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3377]) - 
        (TBgamma[1, Global`d1, Global`a$3406]*TBgamma[3, Global`a$3406, 
            Global`d2] - TBgamma[1, Global`a$3409, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3409])*
         (TBgamma[1, Global`d3, Global`a$3412]*TBgamma[3, Global`a$3412, 
            Global`d4] - TBgamma[1, Global`a$3415, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3415]) - 
        (TBgamma[2, Global`d1, Global`a$3442]*TBgamma[3, Global`a$3442, 
            Global`d2] - TBgamma[2, Global`a$3445, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3445])*
         (TBgamma[2, Global`d3, Global`a$3448]*TBgamma[3, Global`a$3448, 
            Global`d4] - TBgamma[2, Global`a$3451, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3451]) - 
        (TBgamma[1, Global`d1, Global`a$3457]*TBgamma[3, Global`a$3457, 
            Global`d2] - TBgamma[1, Global`a$3454, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3454])*
         (TBgamma[1, Global`d3, Global`a$3463]*TBgamma[3, Global`a$3463, 
            Global`d4] - TBgamma[1, Global`a$3460, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3460]) - 
        (TBgamma[2, Global`d1, Global`a$3469]*TBgamma[3, Global`a$3469, 
            Global`d2] - TBgamma[2, Global`a$3466, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3466])*
         (TBgamma[2, Global`d3, Global`a$3475]*TBgamma[3, Global`a$3475, 
            Global`d4] - TBgamma[2, Global`a$3472, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3472]) - 
        (TBgamma[3, Global`a$3478, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$3478] - TBgamma[3, Global`a$3481, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3481])*
         (TBgamma[3, Global`a$3484, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$3484] - TBgamma[3, Global`a$3487, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3487])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$3490]*TBgamma[1, Global`a$3490, 
            Global`d2] - TBgamma[0, Global`a$3493, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3493])*
         (TBgamma[0, Global`d3, Global`a$3496]*TBgamma[1, Global`a$3496, 
            Global`d4] - TBgamma[0, Global`a$3499, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3499]) - 
        (TBgamma[1, Global`a$3526, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$3526] - TBgamma[1, Global`a$3529, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3529])*
         (TBgamma[1, Global`a$3532, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$3532] - TBgamma[1, Global`a$3535, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3535]) + 
        2*(TBgamma[0, Global`d1, Global`a$3502]*TBgamma[2, Global`a$3502, 
            Global`d2] - TBgamma[0, Global`a$3505, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3505])*
         (TBgamma[0, Global`d3, Global`a$3508]*TBgamma[2, Global`a$3508, 
            Global`d4] - TBgamma[0, Global`a$3511, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3511]) - 
        (TBgamma[1, Global`d1, Global`a$3538]*TBgamma[2, Global`a$3538, 
            Global`d2] - TBgamma[1, Global`a$3541, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3541])*
         (TBgamma[1, Global`d3, Global`a$3544]*TBgamma[2, Global`a$3544, 
            Global`d4] - TBgamma[1, Global`a$3547, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3547]) - 
        (TBgamma[1, Global`d1, Global`a$3565]*TBgamma[2, Global`a$3565, 
            Global`d2] - TBgamma[1, Global`a$3562, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3562])*
         (TBgamma[1, Global`d3, Global`a$3571]*TBgamma[2, Global`a$3571, 
            Global`d4] - TBgamma[1, Global`a$3568, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3568]) - 
        (TBgamma[2, Global`a$3574, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$3574] - TBgamma[2, Global`a$3577, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3577])*
         (TBgamma[2, Global`a$3580, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$3580] - TBgamma[2, Global`a$3583, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3583]) + 
        2*(TBgamma[0, Global`d1, Global`a$3514]*TBgamma[3, Global`a$3514, 
            Global`d2] - TBgamma[0, Global`a$3517, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3517])*
         (TBgamma[0, Global`d3, Global`a$3520]*TBgamma[3, Global`a$3520, 
            Global`d4] - TBgamma[0, Global`a$3523, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3523]) - 
        (TBgamma[1, Global`d1, Global`a$3550]*TBgamma[3, Global`a$3550, 
            Global`d2] - TBgamma[1, Global`a$3553, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3553])*
         (TBgamma[1, Global`d3, Global`a$3556]*TBgamma[3, Global`a$3556, 
            Global`d4] - TBgamma[1, Global`a$3559, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3559]) - 
        (TBgamma[2, Global`d1, Global`a$3586]*TBgamma[3, Global`a$3586, 
            Global`d2] - TBgamma[2, Global`a$3589, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3589])*
         (TBgamma[2, Global`d3, Global`a$3592]*TBgamma[3, Global`a$3592, 
            Global`d4] - TBgamma[2, Global`a$3595, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3595]) - 
        (TBgamma[1, Global`d1, Global`a$3601]*TBgamma[3, Global`a$3601, 
            Global`d2] - TBgamma[1, Global`a$3598, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3598])*
         (TBgamma[1, Global`d3, Global`a$3607]*TBgamma[3, Global`a$3607, 
            Global`d4] - TBgamma[1, Global`a$3604, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3604]) - 
        (TBgamma[2, Global`d1, Global`a$3613]*TBgamma[3, Global`a$3613, 
            Global`d2] - TBgamma[2, Global`a$3610, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3610])*
         (TBgamma[2, Global`d3, Global`a$3619]*TBgamma[3, Global`a$3619, 
            Global`d4] - TBgamma[2, Global`a$3616, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3616]) - 
        (TBgamma[3, Global`a$3622, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$3622] - TBgamma[3, Global`a$3625, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3625])*
         (TBgamma[3, Global`a$3628, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$3628] - TBgamma[3, Global`a$3631, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3631]))*TBT[Global`flavor, 
        Global`af$3634, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$3634, Global`F3, Global`F4]) - Global`Nc*(4 - Global`Nc^2)*
     (1 - Global`Nf)*Global`Nf*TBT[Global`color, Global`ac$3939, Global`A1, 
      Global`A2]*TBT[Global`color, Global`ac$3939, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$3650]*TBgamma[1, Global`a$3650, 
            Global`d2] - TBgamma[0, Global`a$3653, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3653])*
         (TBgamma[0, Global`d3, Global`a$3656]*TBgamma[1, Global`a$3656, 
            Global`d4] - TBgamma[0, Global`a$3659, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3659]) - 
        (TBgamma[1, Global`a$3686, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$3686] - TBgamma[1, Global`a$3689, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3689])*
         (TBgamma[1, Global`a$3692, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$3692] - TBgamma[1, Global`a$3695, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3695]) + 
        2*(TBgamma[0, Global`d1, Global`a$3662]*TBgamma[2, Global`a$3662, 
            Global`d2] - TBgamma[0, Global`a$3665, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3665])*
         (TBgamma[0, Global`d3, Global`a$3668]*TBgamma[2, Global`a$3668, 
            Global`d4] - TBgamma[0, Global`a$3671, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3671]) - 
        (TBgamma[1, Global`d1, Global`a$3698]*TBgamma[2, Global`a$3698, 
            Global`d2] - TBgamma[1, Global`a$3701, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3701])*
         (TBgamma[1, Global`d3, Global`a$3704]*TBgamma[2, Global`a$3704, 
            Global`d4] - TBgamma[1, Global`a$3707, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3707]) - 
        (TBgamma[1, Global`d1, Global`a$3725]*TBgamma[2, Global`a$3725, 
            Global`d2] - TBgamma[1, Global`a$3722, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3722])*
         (TBgamma[1, Global`d3, Global`a$3731]*TBgamma[2, Global`a$3731, 
            Global`d4] - TBgamma[1, Global`a$3728, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3728]) - 
        (TBgamma[2, Global`a$3734, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$3734] - TBgamma[2, Global`a$3737, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3737])*
         (TBgamma[2, Global`a$3740, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$3740] - TBgamma[2, Global`a$3743, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3743]) + 
        2*(TBgamma[0, Global`d1, Global`a$3674]*TBgamma[3, Global`a$3674, 
            Global`d2] - TBgamma[0, Global`a$3677, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3677])*
         (TBgamma[0, Global`d3, Global`a$3680]*TBgamma[3, Global`a$3680, 
            Global`d4] - TBgamma[0, Global`a$3683, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3683]) - 
        (TBgamma[1, Global`d1, Global`a$3710]*TBgamma[3, Global`a$3710, 
            Global`d2] - TBgamma[1, Global`a$3713, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3713])*
         (TBgamma[1, Global`d3, Global`a$3716]*TBgamma[3, Global`a$3716, 
            Global`d4] - TBgamma[1, Global`a$3719, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3719]) - 
        (TBgamma[2, Global`d1, Global`a$3746]*TBgamma[3, Global`a$3746, 
            Global`d2] - TBgamma[2, Global`a$3749, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3749])*
         (TBgamma[2, Global`d3, Global`a$3752]*TBgamma[3, Global`a$3752, 
            Global`d4] - TBgamma[2, Global`a$3755, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3755]) - 
        (TBgamma[1, Global`d1, Global`a$3761]*TBgamma[3, Global`a$3761, 
            Global`d2] - TBgamma[1, Global`a$3758, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3758])*
         (TBgamma[1, Global`d3, Global`a$3767]*TBgamma[3, Global`a$3767, 
            Global`d4] - TBgamma[1, Global`a$3764, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3764]) - 
        (TBgamma[2, Global`d1, Global`a$3773]*TBgamma[3, Global`a$3773, 
            Global`d2] - TBgamma[2, Global`a$3770, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3770])*
         (TBgamma[2, Global`d3, Global`a$3779]*TBgamma[3, Global`a$3779, 
            Global`d4] - TBgamma[2, Global`a$3776, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3776]) - 
        (TBgamma[3, Global`a$3782, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$3782] - TBgamma[3, Global`a$3785, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3785])*
         (TBgamma[3, Global`a$3789, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$3789] - TBgamma[3, Global`a$3792, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3792])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$3795]*TBgamma[1, Global`a$3795, 
            Global`d2] - TBgamma[0, Global`a$3798, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3798])*
         (TBgamma[0, Global`d3, Global`a$3801]*TBgamma[1, Global`a$3801, 
            Global`d4] - TBgamma[0, Global`a$3804, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3804]) - 
        (TBgamma[1, Global`a$3831, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$3831] - TBgamma[1, Global`a$3834, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3834])*
         (TBgamma[1, Global`a$3837, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$3837] - TBgamma[1, Global`a$3840, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3840]) + 
        2*(TBgamma[0, Global`d1, Global`a$3807]*TBgamma[2, Global`a$3807, 
            Global`d2] - TBgamma[0, Global`a$3810, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3810])*
         (TBgamma[0, Global`d3, Global`a$3813]*TBgamma[2, Global`a$3813, 
            Global`d4] - TBgamma[0, Global`a$3816, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3816]) - 
        (TBgamma[1, Global`d1, Global`a$3843]*TBgamma[2, Global`a$3843, 
            Global`d2] - TBgamma[1, Global`a$3846, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3846])*
         (TBgamma[1, Global`d3, Global`a$3849]*TBgamma[2, Global`a$3849, 
            Global`d4] - TBgamma[1, Global`a$3852, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3852]) - 
        (TBgamma[1, Global`d1, Global`a$3870]*TBgamma[2, Global`a$3870, 
            Global`d2] - TBgamma[1, Global`a$3867, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3867])*
         (TBgamma[1, Global`d3, Global`a$3876]*TBgamma[2, Global`a$3876, 
            Global`d4] - TBgamma[1, Global`a$3873, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3873]) - 
        (TBgamma[2, Global`a$3879, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$3879] - TBgamma[2, Global`a$3882, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3882])*
         (TBgamma[2, Global`a$3885, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$3885] - TBgamma[2, Global`a$3888, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3888]) + 
        2*(TBgamma[0, Global`d1, Global`a$3819]*TBgamma[3, Global`a$3819, 
            Global`d2] - TBgamma[0, Global`a$3822, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3822])*
         (TBgamma[0, Global`d3, Global`a$3825]*TBgamma[3, Global`a$3825, 
            Global`d4] - TBgamma[0, Global`a$3828, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3828]) - 
        (TBgamma[1, Global`d1, Global`a$3855]*TBgamma[3, Global`a$3855, 
            Global`d2] - TBgamma[1, Global`a$3858, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3858])*
         (TBgamma[1, Global`d3, Global`a$3861]*TBgamma[3, Global`a$3861, 
            Global`d4] - TBgamma[1, Global`a$3864, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3864]) - 
        (TBgamma[2, Global`d1, Global`a$3891]*TBgamma[3, Global`a$3891, 
            Global`d2] - TBgamma[2, Global`a$3894, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3894])*
         (TBgamma[2, Global`d3, Global`a$3897]*TBgamma[3, Global`a$3897, 
            Global`d4] - TBgamma[2, Global`a$3900, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3900]) - 
        (TBgamma[1, Global`d1, Global`a$3906]*TBgamma[3, Global`a$3906, 
            Global`d2] - TBgamma[1, Global`a$3903, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3903])*
         (TBgamma[1, Global`d3, Global`a$3912]*TBgamma[3, Global`a$3912, 
            Global`d4] - TBgamma[1, Global`a$3909, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3909]) - 
        (TBgamma[2, Global`d1, Global`a$3918]*TBgamma[3, Global`a$3918, 
            Global`d2] - TBgamma[2, Global`a$3915, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3915])*
         (TBgamma[2, Global`d3, Global`a$3924]*TBgamma[3, Global`a$3924, 
            Global`d4] - TBgamma[2, Global`a$3921, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3921]) - 
        (TBgamma[3, Global`a$3927, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$3927] - TBgamma[3, Global`a$3930, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3930])*
         (TBgamma[3, Global`a$3933, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$3933] - TBgamma[3, Global`a$3936, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3936]))*TBT[Global`flavor, 
        Global`af$3942, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$3942, Global`F3, Global`F4]) + 
    24*Global`Nc^3*(-1 + Global`Nf)*Global`Nf*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$3325, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$3325, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$3328, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$3328, Global`F3, Global`F4]))/
   (Global`Nc^3*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
    (-2 + Global`Nf^2)), 
 (-3*(4*Global`Nc*(-9 + 8*Global`Nf)*(18 - 34*Global`Nf - 9*Global`Nf^2 + 
      8*Global`Nf^3)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1717]*TBgamma[0, Global`d3, 
        Global`dc$1720]*TBgamma5[Global`dc$1717, Global`d2]*
       TBgamma5[Global`dc$1720, Global`d4]) + 4*Global`Nc*(-9 + 8*Global`Nf)*
     (18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1893]*TBgamma[0, Global`d3, 
        Global`dc$1896]*TBgamma5[Global`dc$1893, Global`d2]*
       TBgamma5[Global`dc$1896, Global`d4]) - 
    4*Global`Nc*(-162 + 288*Global`Nf - 209*Global`Nf^2 + 18*Global`Nf^3 + 
      64*Global`Nf^4)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2010]*TBgamma[0, Global`d3, 
        Global`dc$2013]*TBgamma5[Global`dc$2010, Global`d2]*
       TBgamma5[Global`dc$2013, Global`d4]) + 9*(1 - Global`Nf)*Global`Nf^2*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$2221]*TBgamma[1, Global`a$2221, 
            Global`d2] - TBgamma[0, Global`a$2224, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2224])*
         (TBgamma[0, Global`d3, Global`a$2227]*TBgamma[1, Global`a$2227, 
            Global`d4] - TBgamma[0, Global`a$2230, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2230]) - 
        (TBgamma[1, Global`a$2258, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2258] - TBgamma[1, Global`a$2261, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2261])*
         (TBgamma[1, Global`a$2264, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2264] - TBgamma[1, Global`a$2267, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2267]) + 
        2*(TBgamma[0, Global`d1, Global`a$2233]*TBgamma[2, Global`a$2233, 
            Global`d2] - TBgamma[0, Global`a$2236, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2236])*
         (TBgamma[0, Global`d3, Global`a$2239]*TBgamma[2, Global`a$2239, 
            Global`d4] - TBgamma[0, Global`a$2242, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2242]) - 
        (TBgamma[1, Global`d1, Global`a$2270]*TBgamma[2, Global`a$2270, 
            Global`d2] - TBgamma[1, Global`a$2273, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2273])*
         (TBgamma[1, Global`d3, Global`a$2276]*TBgamma[2, Global`a$2276, 
            Global`d4] - TBgamma[1, Global`a$2279, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2279]) - 
        (TBgamma[1, Global`d1, Global`a$2297]*TBgamma[2, Global`a$2297, 
            Global`d2] - TBgamma[1, Global`a$2294, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2294])*
         (TBgamma[1, Global`d3, Global`a$2303]*TBgamma[2, Global`a$2303, 
            Global`d4] - TBgamma[1, Global`a$2300, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2300]) - 
        (TBgamma[2, Global`a$2306, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2306] - TBgamma[2, Global`a$2309, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2309])*
         (TBgamma[2, Global`a$2312, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2312] - TBgamma[2, Global`a$2315, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2315]) + 
        2*(TBgamma[0, Global`d1, Global`a$2246]*TBgamma[3, Global`a$2246, 
            Global`d2] - TBgamma[0, Global`a$2249, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2249])*
         (TBgamma[0, Global`d3, Global`a$2252]*TBgamma[3, Global`a$2252, 
            Global`d4] - TBgamma[0, Global`a$2255, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2255]) - 
        (TBgamma[1, Global`d1, Global`a$2282]*TBgamma[3, Global`a$2282, 
            Global`d2] - TBgamma[1, Global`a$2285, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2285])*
         (TBgamma[1, Global`d3, Global`a$2288]*TBgamma[3, Global`a$2288, 
            Global`d4] - TBgamma[1, Global`a$2291, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2291]) - 
        (TBgamma[2, Global`d1, Global`a$2318]*TBgamma[3, Global`a$2318, 
            Global`d2] - TBgamma[2, Global`a$2321, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2321])*
         (TBgamma[2, Global`d3, Global`a$2324]*TBgamma[3, Global`a$2324, 
            Global`d4] - TBgamma[2, Global`a$2327, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2327]) - 
        (TBgamma[1, Global`d1, Global`a$2333]*TBgamma[3, Global`a$2333, 
            Global`d2] - TBgamma[1, Global`a$2330, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2330])*
         (TBgamma[1, Global`d3, Global`a$2339]*TBgamma[3, Global`a$2339, 
            Global`d4] - TBgamma[1, Global`a$2336, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2336]) - 
        (TBgamma[2, Global`d1, Global`a$2345]*TBgamma[3, Global`a$2345, 
            Global`d2] - TBgamma[2, Global`a$2342, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2342])*
         (TBgamma[2, Global`d3, Global`a$2351]*TBgamma[3, Global`a$2351, 
            Global`d4] - TBgamma[2, Global`a$2348, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2348]) - 
        (TBgamma[3, Global`a$2354, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2354] - TBgamma[3, Global`a$2357, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2357])*
         (TBgamma[3, Global`a$2360, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2360] - TBgamma[3, Global`a$2363, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2363])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$2366]*TBgamma[1, Global`a$2366, 
            Global`d2] - TBgamma[0, Global`a$2369, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2369])*
         (TBgamma[0, Global`d3, Global`a$2372]*TBgamma[1, Global`a$2372, 
            Global`d4] - TBgamma[0, Global`a$2375, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2375]) - 
        (TBgamma[1, Global`a$2402, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2402] - TBgamma[1, Global`a$2405, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2405])*
         (TBgamma[1, Global`a$2408, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2408] - TBgamma[1, Global`a$2411, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2411]) + 
        2*(TBgamma[0, Global`d1, Global`a$2378]*TBgamma[2, Global`a$2378, 
            Global`d2] - TBgamma[0, Global`a$2381, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2381])*
         (TBgamma[0, Global`d3, Global`a$2384]*TBgamma[2, Global`a$2384, 
            Global`d4] - TBgamma[0, Global`a$2387, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2387]) - 
        (TBgamma[1, Global`d1, Global`a$2414]*TBgamma[2, Global`a$2414, 
            Global`d2] - TBgamma[1, Global`a$2417, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2417])*
         (TBgamma[1, Global`d3, Global`a$2420]*TBgamma[2, Global`a$2420, 
            Global`d4] - TBgamma[1, Global`a$2423, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2423]) - 
        (TBgamma[1, Global`d1, Global`a$2441]*TBgamma[2, Global`a$2441, 
            Global`d2] - TBgamma[1, Global`a$2438, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2438])*
         (TBgamma[1, Global`d3, Global`a$2447]*TBgamma[2, Global`a$2447, 
            Global`d4] - TBgamma[1, Global`a$2444, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2444]) - 
        (TBgamma[2, Global`a$2450, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2450] - TBgamma[2, Global`a$2453, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2453])*
         (TBgamma[2, Global`a$2456, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2456] - TBgamma[2, Global`a$2459, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2459]) + 
        2*(TBgamma[0, Global`d1, Global`a$2390]*TBgamma[3, Global`a$2390, 
            Global`d2] - TBgamma[0, Global`a$2393, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2393])*
         (TBgamma[0, Global`d3, Global`a$2396]*TBgamma[3, Global`a$2396, 
            Global`d4] - TBgamma[0, Global`a$2399, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2399]) - 
        (TBgamma[1, Global`d1, Global`a$2426]*TBgamma[3, Global`a$2426, 
            Global`d2] - TBgamma[1, Global`a$2429, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2429])*
         (TBgamma[1, Global`d3, Global`a$2432]*TBgamma[3, Global`a$2432, 
            Global`d4] - TBgamma[1, Global`a$2435, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2435]) - 
        (TBgamma[2, Global`d1, Global`a$2462]*TBgamma[3, Global`a$2462, 
            Global`d2] - TBgamma[2, Global`a$2465, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2465])*
         (TBgamma[2, Global`d3, Global`a$2468]*TBgamma[3, Global`a$2468, 
            Global`d4] - TBgamma[2, Global`a$2471, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2471]) - 
        (TBgamma[1, Global`d1, Global`a$2477]*TBgamma[3, Global`a$2477, 
            Global`d2] - TBgamma[1, Global`a$2474, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2474])*
         (TBgamma[1, Global`d3, Global`a$2483]*TBgamma[3, Global`a$2483, 
            Global`d4] - TBgamma[1, Global`a$2480, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2480]) - 
        (TBgamma[2, Global`d1, Global`a$2489]*TBgamma[3, Global`a$2489, 
            Global`d2] - TBgamma[2, Global`a$2486, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2486])*
         (TBgamma[2, Global`d3, Global`a$2495]*TBgamma[3, Global`a$2495, 
            Global`d4] - TBgamma[2, Global`a$2492, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2492]) - 
        (TBgamma[3, Global`a$2498, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2498] - TBgamma[3, Global`a$2501, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2501])*
         (TBgamma[3, Global`a$2504, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2504] - TBgamma[3, Global`a$2507, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2507]))*TBT[Global`flavor, 
        Global`af$2510, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$2510, Global`F3, Global`F4]) + 18*Global`Nc*(1 - Global`Nf)*
     Global`Nf^2*TBT[Global`color, Global`ac$2816, Global`A1, Global`A2]*
     TBT[Global`color, Global`ac$2816, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$2526]*TBgamma[1, Global`a$2526, 
            Global`d2] - TBgamma[0, Global`a$2529, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2529])*
         (TBgamma[0, Global`d3, Global`a$2532]*TBgamma[1, Global`a$2532, 
            Global`d4] - TBgamma[0, Global`a$2535, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2535]) - 
        (TBgamma[1, Global`a$2562, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2562] - TBgamma[1, Global`a$2565, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2565])*
         (TBgamma[1, Global`a$2568, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2568] - TBgamma[1, Global`a$2571, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2571]) + 
        2*(TBgamma[0, Global`d1, Global`a$2538]*TBgamma[2, Global`a$2538, 
            Global`d2] - TBgamma[0, Global`a$2541, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2541])*
         (TBgamma[0, Global`d3, Global`a$2544]*TBgamma[2, Global`a$2544, 
            Global`d4] - TBgamma[0, Global`a$2547, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2547]) - 
        (TBgamma[1, Global`d1, Global`a$2574]*TBgamma[2, Global`a$2574, 
            Global`d2] - TBgamma[1, Global`a$2577, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2577])*
         (TBgamma[1, Global`d3, Global`a$2580]*TBgamma[2, Global`a$2580, 
            Global`d4] - TBgamma[1, Global`a$2583, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2583]) - 
        (TBgamma[1, Global`d1, Global`a$2601]*TBgamma[2, Global`a$2601, 
            Global`d2] - TBgamma[1, Global`a$2598, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2598])*
         (TBgamma[1, Global`d3, Global`a$2607]*TBgamma[2, Global`a$2607, 
            Global`d4] - TBgamma[1, Global`a$2604, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2604]) - 
        (TBgamma[2, Global`a$2610, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2610] - TBgamma[2, Global`a$2613, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2613])*
         (TBgamma[2, Global`a$2616, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2616] - TBgamma[2, Global`a$2619, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2619]) + 
        2*(TBgamma[0, Global`d1, Global`a$2550]*TBgamma[3, Global`a$2550, 
            Global`d2] - TBgamma[0, Global`a$2553, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2553])*
         (TBgamma[0, Global`d3, Global`a$2556]*TBgamma[3, Global`a$2556, 
            Global`d4] - TBgamma[0, Global`a$2559, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2559]) - 
        (TBgamma[1, Global`d1, Global`a$2586]*TBgamma[3, Global`a$2586, 
            Global`d2] - TBgamma[1, Global`a$2589, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2589])*
         (TBgamma[1, Global`d3, Global`a$2592]*TBgamma[3, Global`a$2592, 
            Global`d4] - TBgamma[1, Global`a$2595, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2595]) - 
        (TBgamma[2, Global`d1, Global`a$2622]*TBgamma[3, Global`a$2622, 
            Global`d2] - TBgamma[2, Global`a$2625, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2625])*
         (TBgamma[2, Global`d3, Global`a$2628]*TBgamma[3, Global`a$2628, 
            Global`d4] - TBgamma[2, Global`a$2631, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2631]) - 
        (TBgamma[1, Global`d1, Global`a$2637]*TBgamma[3, Global`a$2637, 
            Global`d2] - TBgamma[1, Global`a$2634, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2634])*
         (TBgamma[1, Global`d3, Global`a$2644]*TBgamma[3, Global`a$2644, 
            Global`d4] - TBgamma[1, Global`a$2640, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2640]) - 
        (TBgamma[2, Global`d1, Global`a$2650]*TBgamma[3, Global`a$2650, 
            Global`d2] - TBgamma[2, Global`a$2647, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2647])*
         (TBgamma[2, Global`d3, Global`a$2656]*TBgamma[3, Global`a$2656, 
            Global`d4] - TBgamma[2, Global`a$2653, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2653]) - 
        (TBgamma[3, Global`a$2659, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2659] - TBgamma[3, Global`a$2662, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2662])*
         (TBgamma[3, Global`a$2665, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2665] - TBgamma[3, Global`a$2668, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2668])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$2671]*TBgamma[1, Global`a$2671, 
            Global`d2] - TBgamma[0, Global`a$2674, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2674])*
         (TBgamma[0, Global`d3, Global`a$2677]*TBgamma[1, Global`a$2677, 
            Global`d4] - TBgamma[0, Global`a$2680, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2680]) - 
        (TBgamma[1, Global`a$2707, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2707] - TBgamma[1, Global`a$2710, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2710])*
         (TBgamma[1, Global`a$2713, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2713] - TBgamma[1, Global`a$2716, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2716]) + 
        2*(TBgamma[0, Global`d1, Global`a$2683]*TBgamma[2, Global`a$2683, 
            Global`d2] - TBgamma[0, Global`a$2686, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2686])*
         (TBgamma[0, Global`d3, Global`a$2689]*TBgamma[2, Global`a$2689, 
            Global`d4] - TBgamma[0, Global`a$2692, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2692]) - 
        (TBgamma[1, Global`d1, Global`a$2719]*TBgamma[2, Global`a$2719, 
            Global`d2] - TBgamma[1, Global`a$2722, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2722])*
         (TBgamma[1, Global`d3, Global`a$2725]*TBgamma[2, Global`a$2725, 
            Global`d4] - TBgamma[1, Global`a$2728, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2728]) - 
        (TBgamma[1, Global`d1, Global`a$2746]*TBgamma[2, Global`a$2746, 
            Global`d2] - TBgamma[1, Global`a$2743, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2743])*
         (TBgamma[1, Global`d3, Global`a$2752]*TBgamma[2, Global`a$2752, 
            Global`d4] - TBgamma[1, Global`a$2749, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2749]) - 
        (TBgamma[2, Global`a$2755, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2755] - TBgamma[2, Global`a$2758, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2758])*
         (TBgamma[2, Global`a$2761, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2761] - TBgamma[2, Global`a$2764, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2764]) + 
        2*(TBgamma[0, Global`d1, Global`a$2695]*TBgamma[3, Global`a$2695, 
            Global`d2] - TBgamma[0, Global`a$2698, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2698])*
         (TBgamma[0, Global`d3, Global`a$2701]*TBgamma[3, Global`a$2701, 
            Global`d4] - TBgamma[0, Global`a$2704, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2704]) - 
        (TBgamma[1, Global`d1, Global`a$2731]*TBgamma[3, Global`a$2731, 
            Global`d2] - TBgamma[1, Global`a$2734, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2734])*
         (TBgamma[1, Global`d3, Global`a$2737]*TBgamma[3, Global`a$2737, 
            Global`d4] - TBgamma[1, Global`a$2740, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2740]) - 
        (TBgamma[2, Global`d1, Global`a$2767]*TBgamma[3, Global`a$2767, 
            Global`d2] - TBgamma[2, Global`a$2770, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2770])*
         (TBgamma[2, Global`d3, Global`a$2773]*TBgamma[3, Global`a$2773, 
            Global`d4] - TBgamma[2, Global`a$2776, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2776]) - 
        (TBgamma[1, Global`d1, Global`a$2782]*TBgamma[3, Global`a$2782, 
            Global`d2] - TBgamma[1, Global`a$2779, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2779])*
         (TBgamma[1, Global`d3, Global`a$2788]*TBgamma[3, Global`a$2788, 
            Global`d4] - TBgamma[1, Global`a$2785, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2785]) - 
        (TBgamma[2, Global`d1, Global`a$2794]*TBgamma[3, Global`a$2794, 
            Global`d2] - TBgamma[2, Global`a$2791, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2791])*
         (TBgamma[2, Global`d3, Global`a$2800]*TBgamma[3, Global`a$2800, 
            Global`d4] - TBgamma[2, Global`a$2797, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2797]) - 
        (TBgamma[3, Global`a$2803, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2803] - TBgamma[3, Global`a$2806, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2806])*
         (TBgamma[3, Global`a$2809, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2809] - TBgamma[3, Global`a$2813, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2813]))*TBT[Global`flavor, 
        Global`af$2819, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$2819, Global`F3, Global`F4]) - 72*(-1 + Global`Nf)*
     Global`Nf^2*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$2186, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$2186, Global`F3, Global`F4]) - 
    144*Global`Nc*(-1 + Global`Nf)*Global`Nf^2*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$2202, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$2202, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$2205, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$2205, Global`F3, Global`F4])))/
  (256*Global`Nc^3*(9 - 8*Global`Nf)^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
 -1/256*(8*(9 - 8*Global`Nf)*(18 + 2*Global`Nf - 27*Global`Nf^2 + 
      8*Global`Nf^3)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) - 
    4*Global`Nc*(9 - 8*Global`Nf)*(18 - 34*Global`Nf - 9*Global`Nf^2 + 
      8*Global`Nf^3)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$2859, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2859, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2859, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2859, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$2859, 0]*TBgamma[0, Global`d1, 
           Global`dc$2862]) + TBgamma[Global`i$2859, Global`d1, 
         Global`dc$2862])*(-(TBdeltaLorentz[Global`i$2859, 0]*
          TBgamma[0, Global`d3, Global`dc$2865]) + TBgamma[Global`i$2859, 
         Global`d3, Global`dc$2865])*TBgamma5[Global`dc$2862, Global`d2]*
       TBgamma5[Global`dc$2865, Global`d4]) + 4*Global`Nc*(9 - 8*Global`Nf)*
     (18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$3016]*TBgamma[0, Global`d3, 
        Global`dc$3019]*TBgamma5[Global`dc$3016, Global`d2]*
       TBgamma5[Global`dc$3019, Global`d4]) + 
    4*Global`Nc*(162 - 288*Global`Nf + 209*Global`Nf^2 - 18*Global`Nf^3 - 
      64*Global`Nf^4)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$3152, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$3152, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$3152, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$3152, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$3152, 0]*TBgamma[0, Global`d1, 
           Global`dc$3155]) + TBgamma[Global`i$3152, Global`d1, 
         Global`dc$3155])*(-(TBdeltaLorentz[Global`i$3152, 0]*
          TBgamma[0, Global`d3, Global`dc$3158]) + TBgamma[Global`i$3152, 
         Global`d3, Global`dc$3158])*TBgamma5[Global`dc$3155, Global`d2]*
       TBgamma5[Global`dc$3158, Global`d4]) + 16*Global`Nc*(9 - 8*Global`Nf)*
     (18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$3117, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$3117, Global`A3, Global`A4] - 
    9*(1 - Global`Nf)*Global`Nf^2*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$3344]*TBgamma[1, Global`a$3344, 
            Global`d2] - TBgamma[0, Global`a$3347, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3347])*
         (TBgamma[0, Global`d3, Global`a$3350]*TBgamma[1, Global`a$3350, 
            Global`d4] - TBgamma[0, Global`a$3353, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3353]) - 
        (TBgamma[1, Global`a$3381, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$3381] - TBgamma[1, Global`a$3384, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3384])*
         (TBgamma[1, Global`a$3387, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$3387] - TBgamma[1, Global`a$3390, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3390]) + 
        2*(TBgamma[0, Global`d1, Global`a$3356]*TBgamma[2, Global`a$3356, 
            Global`d2] - TBgamma[0, Global`a$3359, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3359])*
         (TBgamma[0, Global`d3, Global`a$3362]*TBgamma[2, Global`a$3362, 
            Global`d4] - TBgamma[0, Global`a$3365, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3365]) - 
        (TBgamma[1, Global`d1, Global`a$3393]*TBgamma[2, Global`a$3393, 
            Global`d2] - TBgamma[1, Global`a$3396, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3396])*
         (TBgamma[1, Global`d3, Global`a$3400]*TBgamma[2, Global`a$3400, 
            Global`d4] - TBgamma[1, Global`a$3403, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3403]) - 
        (TBgamma[1, Global`d1, Global`a$3421]*TBgamma[2, Global`a$3421, 
            Global`d2] - TBgamma[1, Global`a$3418, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3418])*
         (TBgamma[1, Global`d3, Global`a$3427]*TBgamma[2, Global`a$3427, 
            Global`d4] - TBgamma[1, Global`a$3424, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3424]) - 
        (TBgamma[2, Global`a$3430, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$3430] - TBgamma[2, Global`a$3433, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3433])*
         (TBgamma[2, Global`a$3436, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$3436] - TBgamma[2, Global`a$3439, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3439]) + 
        2*(TBgamma[0, Global`d1, Global`a$3368]*TBgamma[3, Global`a$3368, 
            Global`d2] - TBgamma[0, Global`a$3371, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3371])*
         (TBgamma[0, Global`d3, Global`a$3374]*TBgamma[3, Global`a$3374, 
            Global`d4] - TBgamma[0, Global`a$3377, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3377]) - 
        (TBgamma[1, Global`d1, Global`a$3406]*TBgamma[3, Global`a$3406, 
            Global`d2] - TBgamma[1, Global`a$3409, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3409])*
         (TBgamma[1, Global`d3, Global`a$3412]*TBgamma[3, Global`a$3412, 
            Global`d4] - TBgamma[1, Global`a$3415, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3415]) - 
        (TBgamma[2, Global`d1, Global`a$3442]*TBgamma[3, Global`a$3442, 
            Global`d2] - TBgamma[2, Global`a$3445, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3445])*
         (TBgamma[2, Global`d3, Global`a$3448]*TBgamma[3, Global`a$3448, 
            Global`d4] - TBgamma[2, Global`a$3451, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3451]) - 
        (TBgamma[1, Global`d1, Global`a$3457]*TBgamma[3, Global`a$3457, 
            Global`d2] - TBgamma[1, Global`a$3454, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3454])*
         (TBgamma[1, Global`d3, Global`a$3463]*TBgamma[3, Global`a$3463, 
            Global`d4] - TBgamma[1, Global`a$3460, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3460]) - 
        (TBgamma[2, Global`d1, Global`a$3469]*TBgamma[3, Global`a$3469, 
            Global`d2] - TBgamma[2, Global`a$3466, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3466])*
         (TBgamma[2, Global`d3, Global`a$3475]*TBgamma[3, Global`a$3475, 
            Global`d4] - TBgamma[2, Global`a$3472, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3472]) - 
        (TBgamma[3, Global`a$3478, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$3478] - TBgamma[3, Global`a$3481, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3481])*
         (TBgamma[3, Global`a$3484, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$3484] - TBgamma[3, Global`a$3487, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3487])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$3490]*TBgamma[1, Global`a$3490, 
            Global`d2] - TBgamma[0, Global`a$3493, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3493])*
         (TBgamma[0, Global`d3, Global`a$3496]*TBgamma[1, Global`a$3496, 
            Global`d4] - TBgamma[0, Global`a$3499, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3499]) - 
        (TBgamma[1, Global`a$3526, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$3526] - TBgamma[1, Global`a$3529, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3529])*
         (TBgamma[1, Global`a$3532, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$3532] - TBgamma[1, Global`a$3535, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3535]) + 
        2*(TBgamma[0, Global`d1, Global`a$3502]*TBgamma[2, Global`a$3502, 
            Global`d2] - TBgamma[0, Global`a$3505, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3505])*
         (TBgamma[0, Global`d3, Global`a$3508]*TBgamma[2, Global`a$3508, 
            Global`d4] - TBgamma[0, Global`a$3511, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3511]) - 
        (TBgamma[1, Global`d1, Global`a$3538]*TBgamma[2, Global`a$3538, 
            Global`d2] - TBgamma[1, Global`a$3541, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3541])*
         (TBgamma[1, Global`d3, Global`a$3544]*TBgamma[2, Global`a$3544, 
            Global`d4] - TBgamma[1, Global`a$3547, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3547]) - 
        (TBgamma[1, Global`d1, Global`a$3565]*TBgamma[2, Global`a$3565, 
            Global`d2] - TBgamma[1, Global`a$3562, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3562])*
         (TBgamma[1, Global`d3, Global`a$3571]*TBgamma[2, Global`a$3571, 
            Global`d4] - TBgamma[1, Global`a$3568, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3568]) - 
        (TBgamma[2, Global`a$3574, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$3574] - TBgamma[2, Global`a$3577, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3577])*
         (TBgamma[2, Global`a$3580, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$3580] - TBgamma[2, Global`a$3583, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3583]) + 
        2*(TBgamma[0, Global`d1, Global`a$3514]*TBgamma[3, Global`a$3514, 
            Global`d2] - TBgamma[0, Global`a$3517, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3517])*
         (TBgamma[0, Global`d3, Global`a$3520]*TBgamma[3, Global`a$3520, 
            Global`d4] - TBgamma[0, Global`a$3523, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3523]) - 
        (TBgamma[1, Global`d1, Global`a$3550]*TBgamma[3, Global`a$3550, 
            Global`d2] - TBgamma[1, Global`a$3553, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3553])*
         (TBgamma[1, Global`d3, Global`a$3556]*TBgamma[3, Global`a$3556, 
            Global`d4] - TBgamma[1, Global`a$3559, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3559]) - 
        (TBgamma[2, Global`d1, Global`a$3586]*TBgamma[3, Global`a$3586, 
            Global`d2] - TBgamma[2, Global`a$3589, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3589])*
         (TBgamma[2, Global`d3, Global`a$3592]*TBgamma[3, Global`a$3592, 
            Global`d4] - TBgamma[2, Global`a$3595, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3595]) - 
        (TBgamma[1, Global`d1, Global`a$3601]*TBgamma[3, Global`a$3601, 
            Global`d2] - TBgamma[1, Global`a$3598, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3598])*
         (TBgamma[1, Global`d3, Global`a$3607]*TBgamma[3, Global`a$3607, 
            Global`d4] - TBgamma[1, Global`a$3604, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3604]) - 
        (TBgamma[2, Global`d1, Global`a$3613]*TBgamma[3, Global`a$3613, 
            Global`d2] - TBgamma[2, Global`a$3610, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3610])*
         (TBgamma[2, Global`d3, Global`a$3619]*TBgamma[3, Global`a$3619, 
            Global`d4] - TBgamma[2, Global`a$3616, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3616]) - 
        (TBgamma[3, Global`a$3622, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$3622] - TBgamma[3, Global`a$3625, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3625])*
         (TBgamma[3, Global`a$3628, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$3628] - TBgamma[3, Global`a$3631, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3631]))*TBT[Global`flavor, 
        Global`af$3634, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$3634, Global`F3, Global`F4]) - 18*Global`Nc*(1 - Global`Nf)*
     Global`Nf^2*TBT[Global`color, Global`ac$3939, Global`A1, Global`A2]*
     TBT[Global`color, Global`ac$3939, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$3650]*TBgamma[1, Global`a$3650, 
            Global`d2] - TBgamma[0, Global`a$3653, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3653])*
         (TBgamma[0, Global`d3, Global`a$3656]*TBgamma[1, Global`a$3656, 
            Global`d4] - TBgamma[0, Global`a$3659, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3659]) - 
        (TBgamma[1, Global`a$3686, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$3686] - TBgamma[1, Global`a$3689, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3689])*
         (TBgamma[1, Global`a$3692, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$3692] - TBgamma[1, Global`a$3695, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3695]) + 
        2*(TBgamma[0, Global`d1, Global`a$3662]*TBgamma[2, Global`a$3662, 
            Global`d2] - TBgamma[0, Global`a$3665, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3665])*
         (TBgamma[0, Global`d3, Global`a$3668]*TBgamma[2, Global`a$3668, 
            Global`d4] - TBgamma[0, Global`a$3671, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3671]) - 
        (TBgamma[1, Global`d1, Global`a$3698]*TBgamma[2, Global`a$3698, 
            Global`d2] - TBgamma[1, Global`a$3701, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3701])*
         (TBgamma[1, Global`d3, Global`a$3704]*TBgamma[2, Global`a$3704, 
            Global`d4] - TBgamma[1, Global`a$3707, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3707]) - 
        (TBgamma[1, Global`d1, Global`a$3725]*TBgamma[2, Global`a$3725, 
            Global`d2] - TBgamma[1, Global`a$3722, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3722])*
         (TBgamma[1, Global`d3, Global`a$3731]*TBgamma[2, Global`a$3731, 
            Global`d4] - TBgamma[1, Global`a$3728, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3728]) - 
        (TBgamma[2, Global`a$3734, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$3734] - TBgamma[2, Global`a$3737, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3737])*
         (TBgamma[2, Global`a$3740, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$3740] - TBgamma[2, Global`a$3743, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3743]) + 
        2*(TBgamma[0, Global`d1, Global`a$3674]*TBgamma[3, Global`a$3674, 
            Global`d2] - TBgamma[0, Global`a$3677, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3677])*
         (TBgamma[0, Global`d3, Global`a$3680]*TBgamma[3, Global`a$3680, 
            Global`d4] - TBgamma[0, Global`a$3683, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3683]) - 
        (TBgamma[1, Global`d1, Global`a$3710]*TBgamma[3, Global`a$3710, 
            Global`d2] - TBgamma[1, Global`a$3713, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3713])*
         (TBgamma[1, Global`d3, Global`a$3716]*TBgamma[3, Global`a$3716, 
            Global`d4] - TBgamma[1, Global`a$3719, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3719]) - 
        (TBgamma[2, Global`d1, Global`a$3746]*TBgamma[3, Global`a$3746, 
            Global`d2] - TBgamma[2, Global`a$3749, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3749])*
         (TBgamma[2, Global`d3, Global`a$3752]*TBgamma[3, Global`a$3752, 
            Global`d4] - TBgamma[2, Global`a$3755, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3755]) - 
        (TBgamma[1, Global`d1, Global`a$3761]*TBgamma[3, Global`a$3761, 
            Global`d2] - TBgamma[1, Global`a$3758, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3758])*
         (TBgamma[1, Global`d3, Global`a$3767]*TBgamma[3, Global`a$3767, 
            Global`d4] - TBgamma[1, Global`a$3764, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3764]) - 
        (TBgamma[2, Global`d1, Global`a$3773]*TBgamma[3, Global`a$3773, 
            Global`d2] - TBgamma[2, Global`a$3770, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3770])*
         (TBgamma[2, Global`d3, Global`a$3779]*TBgamma[3, Global`a$3779, 
            Global`d4] - TBgamma[2, Global`a$3776, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3776]) - 
        (TBgamma[3, Global`a$3782, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$3782] - TBgamma[3, Global`a$3785, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3785])*
         (TBgamma[3, Global`a$3789, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$3789] - TBgamma[3, Global`a$3792, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3792])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$3795]*TBgamma[1, Global`a$3795, 
            Global`d2] - TBgamma[0, Global`a$3798, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3798])*
         (TBgamma[0, Global`d3, Global`a$3801]*TBgamma[1, Global`a$3801, 
            Global`d4] - TBgamma[0, Global`a$3804, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3804]) - 
        (TBgamma[1, Global`a$3831, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$3831] - TBgamma[1, Global`a$3834, Global`d2]*
           TBgamma[1, Global`d1, Global`a$3834])*
         (TBgamma[1, Global`a$3837, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$3837] - TBgamma[1, Global`a$3840, Global`d4]*
           TBgamma[1, Global`d3, Global`a$3840]) + 
        2*(TBgamma[0, Global`d1, Global`a$3807]*TBgamma[2, Global`a$3807, 
            Global`d2] - TBgamma[0, Global`a$3810, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3810])*
         (TBgamma[0, Global`d3, Global`a$3813]*TBgamma[2, Global`a$3813, 
            Global`d4] - TBgamma[0, Global`a$3816, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3816]) - 
        (TBgamma[1, Global`d1, Global`a$3843]*TBgamma[2, Global`a$3843, 
            Global`d2] - TBgamma[1, Global`a$3846, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3846])*
         (TBgamma[1, Global`d3, Global`a$3849]*TBgamma[2, Global`a$3849, 
            Global`d4] - TBgamma[1, Global`a$3852, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3852]) - 
        (TBgamma[1, Global`d1, Global`a$3870]*TBgamma[2, Global`a$3870, 
            Global`d2] - TBgamma[1, Global`a$3867, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3867])*
         (TBgamma[1, Global`d3, Global`a$3876]*TBgamma[2, Global`a$3876, 
            Global`d4] - TBgamma[1, Global`a$3873, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3873]) - 
        (TBgamma[2, Global`a$3879, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$3879] - TBgamma[2, Global`a$3882, Global`d2]*
           TBgamma[2, Global`d1, Global`a$3882])*
         (TBgamma[2, Global`a$3885, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$3885] - TBgamma[2, Global`a$3888, Global`d4]*
           TBgamma[2, Global`d3, Global`a$3888]) + 
        2*(TBgamma[0, Global`d1, Global`a$3819]*TBgamma[3, Global`a$3819, 
            Global`d2] - TBgamma[0, Global`a$3822, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3822])*
         (TBgamma[0, Global`d3, Global`a$3825]*TBgamma[3, Global`a$3825, 
            Global`d4] - TBgamma[0, Global`a$3828, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3828]) - 
        (TBgamma[1, Global`d1, Global`a$3855]*TBgamma[3, Global`a$3855, 
            Global`d2] - TBgamma[1, Global`a$3858, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3858])*
         (TBgamma[1, Global`d3, Global`a$3861]*TBgamma[3, Global`a$3861, 
            Global`d4] - TBgamma[1, Global`a$3864, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3864]) - 
        (TBgamma[2, Global`d1, Global`a$3891]*TBgamma[3, Global`a$3891, 
            Global`d2] - TBgamma[2, Global`a$3894, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3894])*
         (TBgamma[2, Global`d3, Global`a$3897]*TBgamma[3, Global`a$3897, 
            Global`d4] - TBgamma[2, Global`a$3900, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3900]) - 
        (TBgamma[1, Global`d1, Global`a$3906]*TBgamma[3, Global`a$3906, 
            Global`d2] - TBgamma[1, Global`a$3903, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3903])*
         (TBgamma[1, Global`d3, Global`a$3912]*TBgamma[3, Global`a$3912, 
            Global`d4] - TBgamma[1, Global`a$3909, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3909]) - 
        (TBgamma[2, Global`d1, Global`a$3918]*TBgamma[3, Global`a$3918, 
            Global`d2] - TBgamma[2, Global`a$3915, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3915])*
         (TBgamma[2, Global`d3, Global`a$3924]*TBgamma[3, Global`a$3924, 
            Global`d4] - TBgamma[2, Global`a$3921, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3921]) - 
        (TBgamma[3, Global`a$3927, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$3927] - TBgamma[3, Global`a$3930, Global`d2]*
           TBgamma[3, Global`d1, Global`a$3930])*
         (TBgamma[3, Global`a$3933, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$3933] - TBgamma[3, Global`a$3936, Global`d4]*
           TBgamma[3, Global`d3, Global`a$3936]))*TBT[Global`flavor, 
        Global`af$3942, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$3942, Global`F3, Global`F4]) - 216*(-1 + Global`Nf)*
     Global`Nf^2*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$3309, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$3309, Global`F3, Global`F4]) - 
    432*Global`Nc*(-1 + Global`Nf)*Global`Nf^2*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$3325, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$3325, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$3328, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$3328, Global`F3, Global`F4]))/
   (Global`Nc^3*(9 - 8*Global`Nf)^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
 (3*TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`color, Global`A3, Global`A4]*
   (TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*(TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
        TBgamma[0, Global`d1, Global`dc$1752]*TBgamma[0, Global`d3, 
          Global`dc$1755]*TBgamma5[Global`dc$1752, Global`d2]*
         TBgamma5[Global`dc$1755, Global`d4]) - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3]*(2*TBgamma[0, Global`d1, Global`d2]*
         TBgamma[0, Global`d3, Global`d4] + TBgamma[0, Global`d1, 
          Global`dc$1752]*TBgamma[0, Global`d3, Global`dc$1755]*
         TBgamma5[Global`dc$1752, Global`d2]*TBgamma5[Global`dc$1755, 
          Global`d4] + TBgamma[0, Global`d1, Global`dc$1906]*
         TBgamma[0, Global`d3, Global`dc$1909]*TBgamma5[Global`dc$1906, 
          Global`d2]*TBgamma5[Global`dc$1909, Global`d4])) + 
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     (TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3]*(TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, 
          Global`d4] + TBgamma[0, Global`d1, Global`dc$1752]*
         TBgamma[0, Global`d3, Global`dc$1755]*TBgamma5[Global`dc$1752, 
          Global`d2]*TBgamma5[Global`dc$1755, Global`d4]) + 
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (-(TBgamma[0, Global`d1, Global`dc$1752]*TBgamma[0, Global`d3, 
           Global`dc$1755]*TBgamma5[Global`dc$1752, Global`d2]*
          TBgamma5[Global`dc$1755, Global`d4]) + 
        TBgamma[0, Global`d1, Global`dc$2045]*TBgamma[0, Global`d3, 
          Global`dc$2048]*TBgamma5[Global`dc$2045, Global`d2]*
         TBgamma5[Global`dc$2048, Global`d4]))))/
  (64*Global`Nc^2*(-1 + Global`Nf)), 
 (-(TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$2893, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2893, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2893, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2893, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$2893, 0]*TBgamma[0, Global`d1, 
           Global`dc$2896]) + TBgamma[Global`i$2893, Global`d1, 
         Global`dc$2896])*(-(TBdeltaLorentz[Global`i$2893, 0]*
          TBgamma[0, Global`d3, Global`dc$2899]) + TBgamma[Global`i$2893, 
         Global`d3, Global`dc$2899])*TBgamma5[Global`dc$2896, Global`d2]*
       TBgamma5[Global`dc$2899, Global`d4])) + 
   (3*Global`Nc*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$3028]*TBgamma[0, Global`d3, 
        Global`dc$3031]*TBgamma5[Global`dc$3028, Global`d2]*
       TBgamma5[Global`dc$3031, Global`d4]))/(-2 + Global`Nc) + 
   TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$3186, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$3186, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$3186, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$3186, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$3186, 0]*TBgamma[0, Global`d1, 
          Global`dc$3189]) + TBgamma[Global`i$3186, Global`d1, 
        Global`dc$3189])*(-(TBdeltaLorentz[Global`i$3186, 0]*
         TBgamma[0, Global`d3, Global`dc$3192]) + TBgamma[Global`i$3186, 
        Global`d3, Global`dc$3192])*TBgamma5[Global`dc$3189, Global`d2]*
      TBgamma5[Global`dc$3192, Global`d4]) - 
   (4*Global`Nc*TBdeltaFund[Global`flavor, Global`F1, 3]*
     TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
      Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
     ((-(TBdeltaLorentz[Global`i$3072, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$3072, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$3072, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$3072, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$3072, 0]*TBgamma[0, Global`d1, 
           Global`dc$3075]) + TBgamma[Global`i$3072, Global`d1, 
         Global`dc$3075])*(-(TBdeltaLorentz[Global`i$3072, 0]*
          TBgamma[0, Global`d3, Global`dc$3078]) + TBgamma[Global`i$3072, 
         Global`d3, Global`dc$3078])*TBgamma5[Global`dc$3075, Global`d2]*
       TBgamma5[Global`dc$3078, Global`d4])*TBT[Global`color, Global`a$3081, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3081, Global`A3, 
      Global`A4])/(-2 + Global`Nc))/(64*Global`Nc^2*(-1 + Global`Nf)), 
 (3*(8*(-1 + Global`Nc^2)*(-9 + 8*Global`Nf)*(18 + 2*Global`Nf - 
      27*Global`Nf^2 + 8*Global`Nf^3)*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
    8*Global`Nc^2*(9 - 8*Global`Nf)*(18 - 34*Global`Nf - 9*Global`Nf^2 + 
      8*Global`Nf^3)*(TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1799]*TBgamma[0, Global`d3, 
        Global`dc$1802]*TBgamma5[Global`dc$1799, Global`d2]*
       TBgamma5[Global`dc$1802, Global`d4])*TBT[Global`color, Global`a$1805, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1805, Global`A3, 
      Global`A4] - 8*Global`Nc^2*(9 - 8*Global`Nf)*
     (18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     ((-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1931, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1931, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d1, 
           Global`dc$1934]) + TBgamma[Global`i$1931, Global`d1, 
         Global`dc$1934])*(-(TBdeltaLorentz[Global`i$1931, 0]*
          TBgamma[0, Global`d3, Global`dc$1937]) + TBgamma[Global`i$1931, 
         Global`d3, Global`dc$1937])*TBgamma5[Global`dc$1934, Global`d2]*
       TBgamma5[Global`dc$1937, Global`d4])*TBT[Global`color, Global`a$1940, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1940, Global`A3, 
      Global`A4] + 16*Global`Nc*(9 - 8*Global`Nf)*(18 + 2*Global`Nf - 
      27*Global`Nf^2 + 8*Global`Nf^3)*TBdeltaFund[Global`flavor, Global`F1, 
      3]*TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
      Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$1994, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$1994, Global`A3, Global`A4] + 
    8*Global`Nc^2*(-162 + 288*Global`Nf - 209*Global`Nf^2 + 18*Global`Nf^3 + 
      64*Global`Nf^4)*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2092]*TBgamma[0, Global`d3, 
        Global`dc$2095]*TBgamma5[Global`dc$2092, Global`d2]*
       TBgamma5[Global`dc$2095, Global`d4])*TBT[Global`color, Global`a$2098, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2098, Global`A3, 
      Global`A4] + 9*(1 - Global`Nc^2)*(1 - Global`Nf)*Global`Nf^2*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$2221]*TBgamma[1, Global`a$2221, 
            Global`d2] - TBgamma[0, Global`a$2224, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2224])*
         (TBgamma[0, Global`d3, Global`a$2227]*TBgamma[1, Global`a$2227, 
            Global`d4] - TBgamma[0, Global`a$2230, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2230]) - 
        (TBgamma[1, Global`a$2258, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2258] - TBgamma[1, Global`a$2261, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2261])*
         (TBgamma[1, Global`a$2264, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2264] - TBgamma[1, Global`a$2267, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2267]) + 
        2*(TBgamma[0, Global`d1, Global`a$2233]*TBgamma[2, Global`a$2233, 
            Global`d2] - TBgamma[0, Global`a$2236, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2236])*
         (TBgamma[0, Global`d3, Global`a$2239]*TBgamma[2, Global`a$2239, 
            Global`d4] - TBgamma[0, Global`a$2242, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2242]) - 
        (TBgamma[1, Global`d1, Global`a$2270]*TBgamma[2, Global`a$2270, 
            Global`d2] - TBgamma[1, Global`a$2273, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2273])*
         (TBgamma[1, Global`d3, Global`a$2276]*TBgamma[2, Global`a$2276, 
            Global`d4] - TBgamma[1, Global`a$2279, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2279]) - 
        (TBgamma[1, Global`d1, Global`a$2297]*TBgamma[2, Global`a$2297, 
            Global`d2] - TBgamma[1, Global`a$2294, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2294])*
         (TBgamma[1, Global`d3, Global`a$2303]*TBgamma[2, Global`a$2303, 
            Global`d4] - TBgamma[1, Global`a$2300, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2300]) - 
        (TBgamma[2, Global`a$2306, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2306] - TBgamma[2, Global`a$2309, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2309])*
         (TBgamma[2, Global`a$2312, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2312] - TBgamma[2, Global`a$2315, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2315]) + 
        2*(TBgamma[0, Global`d1, Global`a$2246]*TBgamma[3, Global`a$2246, 
            Global`d2] - TBgamma[0, Global`a$2249, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2249])*
         (TBgamma[0, Global`d3, Global`a$2252]*TBgamma[3, Global`a$2252, 
            Global`d4] - TBgamma[0, Global`a$2255, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2255]) - 
        (TBgamma[1, Global`d1, Global`a$2282]*TBgamma[3, Global`a$2282, 
            Global`d2] - TBgamma[1, Global`a$2285, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2285])*
         (TBgamma[1, Global`d3, Global`a$2288]*TBgamma[3, Global`a$2288, 
            Global`d4] - TBgamma[1, Global`a$2291, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2291]) - 
        (TBgamma[2, Global`d1, Global`a$2318]*TBgamma[3, Global`a$2318, 
            Global`d2] - TBgamma[2, Global`a$2321, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2321])*
         (TBgamma[2, Global`d3, Global`a$2324]*TBgamma[3, Global`a$2324, 
            Global`d4] - TBgamma[2, Global`a$2327, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2327]) - 
        (TBgamma[1, Global`d1, Global`a$2333]*TBgamma[3, Global`a$2333, 
            Global`d2] - TBgamma[1, Global`a$2330, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2330])*
         (TBgamma[1, Global`d3, Global`a$2339]*TBgamma[3, Global`a$2339, 
            Global`d4] - TBgamma[1, Global`a$2336, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2336]) - 
        (TBgamma[2, Global`d1, Global`a$2345]*TBgamma[3, Global`a$2345, 
            Global`d2] - TBgamma[2, Global`a$2342, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2342])*
         (TBgamma[2, Global`d3, Global`a$2351]*TBgamma[3, Global`a$2351, 
            Global`d4] - TBgamma[2, Global`a$2348, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2348]) - 
        (TBgamma[3, Global`a$2354, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2354] - TBgamma[3, Global`a$2357, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2357])*
         (TBgamma[3, Global`a$2360, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2360] - TBgamma[3, Global`a$2363, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2363])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$2366]*TBgamma[1, Global`a$2366, 
            Global`d2] - TBgamma[0, Global`a$2369, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2369])*
         (TBgamma[0, Global`d3, Global`a$2372]*TBgamma[1, Global`a$2372, 
            Global`d4] - TBgamma[0, Global`a$2375, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2375]) - 
        (TBgamma[1, Global`a$2402, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2402] - TBgamma[1, Global`a$2405, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2405])*
         (TBgamma[1, Global`a$2408, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2408] - TBgamma[1, Global`a$2411, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2411]) + 
        2*(TBgamma[0, Global`d1, Global`a$2378]*TBgamma[2, Global`a$2378, 
            Global`d2] - TBgamma[0, Global`a$2381, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2381])*
         (TBgamma[0, Global`d3, Global`a$2384]*TBgamma[2, Global`a$2384, 
            Global`d4] - TBgamma[0, Global`a$2387, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2387]) - 
        (TBgamma[1, Global`d1, Global`a$2414]*TBgamma[2, Global`a$2414, 
            Global`d2] - TBgamma[1, Global`a$2417, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2417])*
         (TBgamma[1, Global`d3, Global`a$2420]*TBgamma[2, Global`a$2420, 
            Global`d4] - TBgamma[1, Global`a$2423, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2423]) - 
        (TBgamma[1, Global`d1, Global`a$2441]*TBgamma[2, Global`a$2441, 
            Global`d2] - TBgamma[1, Global`a$2438, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2438])*
         (TBgamma[1, Global`d3, Global`a$2447]*TBgamma[2, Global`a$2447, 
            Global`d4] - TBgamma[1, Global`a$2444, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2444]) - 
        (TBgamma[2, Global`a$2450, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2450] - TBgamma[2, Global`a$2453, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2453])*
         (TBgamma[2, Global`a$2456, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2456] - TBgamma[2, Global`a$2459, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2459]) + 
        2*(TBgamma[0, Global`d1, Global`a$2390]*TBgamma[3, Global`a$2390, 
            Global`d2] - TBgamma[0, Global`a$2393, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2393])*
         (TBgamma[0, Global`d3, Global`a$2396]*TBgamma[3, Global`a$2396, 
            Global`d4] - TBgamma[0, Global`a$2399, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2399]) - 
        (TBgamma[1, Global`d1, Global`a$2426]*TBgamma[3, Global`a$2426, 
            Global`d2] - TBgamma[1, Global`a$2429, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2429])*
         (TBgamma[1, Global`d3, Global`a$2432]*TBgamma[3, Global`a$2432, 
            Global`d4] - TBgamma[1, Global`a$2435, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2435]) - 
        (TBgamma[2, Global`d1, Global`a$2462]*TBgamma[3, Global`a$2462, 
            Global`d2] - TBgamma[2, Global`a$2465, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2465])*
         (TBgamma[2, Global`d3, Global`a$2468]*TBgamma[3, Global`a$2468, 
            Global`d4] - TBgamma[2, Global`a$2471, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2471]) - 
        (TBgamma[1, Global`d1, Global`a$2477]*TBgamma[3, Global`a$2477, 
            Global`d2] - TBgamma[1, Global`a$2474, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2474])*
         (TBgamma[1, Global`d3, Global`a$2483]*TBgamma[3, Global`a$2483, 
            Global`d4] - TBgamma[1, Global`a$2480, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2480]) - 
        (TBgamma[2, Global`d1, Global`a$2489]*TBgamma[3, Global`a$2489, 
            Global`d2] - TBgamma[2, Global`a$2486, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2486])*
         (TBgamma[2, Global`d3, Global`a$2495]*TBgamma[3, Global`a$2495, 
            Global`d4] - TBgamma[2, Global`a$2492, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2492]) - 
        (TBgamma[3, Global`a$2498, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2498] - TBgamma[3, Global`a$2501, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2501])*
         (TBgamma[3, Global`a$2504, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2504] - TBgamma[3, Global`a$2507, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2507]))*TBT[Global`flavor, 
        Global`af$2510, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$2510, Global`F3, Global`F4]) + 18*Global`Nc*(1 - Global`Nf)*
     Global`Nf^2*TBT[Global`color, Global`ac$2816, Global`A1, Global`A2]*
     TBT[Global`color, Global`ac$2816, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$2526]*TBgamma[1, Global`a$2526, 
            Global`d2] - TBgamma[0, Global`a$2529, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2529])*
         (TBgamma[0, Global`d3, Global`a$2532]*TBgamma[1, Global`a$2532, 
            Global`d4] - TBgamma[0, Global`a$2535, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2535]) - 
        (TBgamma[1, Global`a$2562, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2562] - TBgamma[1, Global`a$2565, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2565])*
         (TBgamma[1, Global`a$2568, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2568] - TBgamma[1, Global`a$2571, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2571]) + 
        2*(TBgamma[0, Global`d1, Global`a$2538]*TBgamma[2, Global`a$2538, 
            Global`d2] - TBgamma[0, Global`a$2541, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2541])*
         (TBgamma[0, Global`d3, Global`a$2544]*TBgamma[2, Global`a$2544, 
            Global`d4] - TBgamma[0, Global`a$2547, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2547]) - 
        (TBgamma[1, Global`d1, Global`a$2574]*TBgamma[2, Global`a$2574, 
            Global`d2] - TBgamma[1, Global`a$2577, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2577])*
         (TBgamma[1, Global`d3, Global`a$2580]*TBgamma[2, Global`a$2580, 
            Global`d4] - TBgamma[1, Global`a$2583, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2583]) - 
        (TBgamma[1, Global`d1, Global`a$2601]*TBgamma[2, Global`a$2601, 
            Global`d2] - TBgamma[1, Global`a$2598, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2598])*
         (TBgamma[1, Global`d3, Global`a$2607]*TBgamma[2, Global`a$2607, 
            Global`d4] - TBgamma[1, Global`a$2604, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2604]) - 
        (TBgamma[2, Global`a$2610, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2610] - TBgamma[2, Global`a$2613, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2613])*
         (TBgamma[2, Global`a$2616, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2616] - TBgamma[2, Global`a$2619, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2619]) + 
        2*(TBgamma[0, Global`d1, Global`a$2550]*TBgamma[3, Global`a$2550, 
            Global`d2] - TBgamma[0, Global`a$2553, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2553])*
         (TBgamma[0, Global`d3, Global`a$2556]*TBgamma[3, Global`a$2556, 
            Global`d4] - TBgamma[0, Global`a$2559, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2559]) - 
        (TBgamma[1, Global`d1, Global`a$2586]*TBgamma[3, Global`a$2586, 
            Global`d2] - TBgamma[1, Global`a$2589, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2589])*
         (TBgamma[1, Global`d3, Global`a$2592]*TBgamma[3, Global`a$2592, 
            Global`d4] - TBgamma[1, Global`a$2595, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2595]) - 
        (TBgamma[2, Global`d1, Global`a$2622]*TBgamma[3, Global`a$2622, 
            Global`d2] - TBgamma[2, Global`a$2625, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2625])*
         (TBgamma[2, Global`d3, Global`a$2628]*TBgamma[3, Global`a$2628, 
            Global`d4] - TBgamma[2, Global`a$2631, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2631]) - 
        (TBgamma[1, Global`d1, Global`a$2637]*TBgamma[3, Global`a$2637, 
            Global`d2] - TBgamma[1, Global`a$2634, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2634])*
         (TBgamma[1, Global`d3, Global`a$2644]*TBgamma[3, Global`a$2644, 
            Global`d4] - TBgamma[1, Global`a$2640, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2640]) - 
        (TBgamma[2, Global`d1, Global`a$2650]*TBgamma[3, Global`a$2650, 
            Global`d2] - TBgamma[2, Global`a$2647, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2647])*
         (TBgamma[2, Global`d3, Global`a$2656]*TBgamma[3, Global`a$2656, 
            Global`d4] - TBgamma[2, Global`a$2653, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2653]) - 
        (TBgamma[3, Global`a$2659, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2659] - TBgamma[3, Global`a$2662, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2662])*
         (TBgamma[3, Global`a$2665, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2665] - TBgamma[3, Global`a$2668, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2668])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$2671]*TBgamma[1, Global`a$2671, 
            Global`d2] - TBgamma[0, Global`a$2674, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2674])*
         (TBgamma[0, Global`d3, Global`a$2677]*TBgamma[1, Global`a$2677, 
            Global`d4] - TBgamma[0, Global`a$2680, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2680]) - 
        (TBgamma[1, Global`a$2707, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2707] - TBgamma[1, Global`a$2710, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2710])*
         (TBgamma[1, Global`a$2713, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2713] - TBgamma[1, Global`a$2716, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2716]) + 
        2*(TBgamma[0, Global`d1, Global`a$2683]*TBgamma[2, Global`a$2683, 
            Global`d2] - TBgamma[0, Global`a$2686, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2686])*
         (TBgamma[0, Global`d3, Global`a$2689]*TBgamma[2, Global`a$2689, 
            Global`d4] - TBgamma[0, Global`a$2692, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2692]) - 
        (TBgamma[1, Global`d1, Global`a$2719]*TBgamma[2, Global`a$2719, 
            Global`d2] - TBgamma[1, Global`a$2722, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2722])*
         (TBgamma[1, Global`d3, Global`a$2725]*TBgamma[2, Global`a$2725, 
            Global`d4] - TBgamma[1, Global`a$2728, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2728]) - 
        (TBgamma[1, Global`d1, Global`a$2746]*TBgamma[2, Global`a$2746, 
            Global`d2] - TBgamma[1, Global`a$2743, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2743])*
         (TBgamma[1, Global`d3, Global`a$2752]*TBgamma[2, Global`a$2752, 
            Global`d4] - TBgamma[1, Global`a$2749, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2749]) - 
        (TBgamma[2, Global`a$2755, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2755] - TBgamma[2, Global`a$2758, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2758])*
         (TBgamma[2, Global`a$2761, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2761] - TBgamma[2, Global`a$2764, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2764]) + 
        2*(TBgamma[0, Global`d1, Global`a$2695]*TBgamma[3, Global`a$2695, 
            Global`d2] - TBgamma[0, Global`a$2698, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2698])*
         (TBgamma[0, Global`d3, Global`a$2701]*TBgamma[3, Global`a$2701, 
            Global`d4] - TBgamma[0, Global`a$2704, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2704]) - 
        (TBgamma[1, Global`d1, Global`a$2731]*TBgamma[3, Global`a$2731, 
            Global`d2] - TBgamma[1, Global`a$2734, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2734])*
         (TBgamma[1, Global`d3, Global`a$2737]*TBgamma[3, Global`a$2737, 
            Global`d4] - TBgamma[1, Global`a$2740, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2740]) - 
        (TBgamma[2, Global`d1, Global`a$2767]*TBgamma[3, Global`a$2767, 
            Global`d2] - TBgamma[2, Global`a$2770, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2770])*
         (TBgamma[2, Global`d3, Global`a$2773]*TBgamma[3, Global`a$2773, 
            Global`d4] - TBgamma[2, Global`a$2776, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2776]) - 
        (TBgamma[1, Global`d1, Global`a$2782]*TBgamma[3, Global`a$2782, 
            Global`d2] - TBgamma[1, Global`a$2779, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2779])*
         (TBgamma[1, Global`d3, Global`a$2788]*TBgamma[3, Global`a$2788, 
            Global`d4] - TBgamma[1, Global`a$2785, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2785]) - 
        (TBgamma[2, Global`d1, Global`a$2794]*TBgamma[3, Global`a$2794, 
            Global`d2] - TBgamma[2, Global`a$2791, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2791])*
         (TBgamma[2, Global`d3, Global`a$2800]*TBgamma[3, Global`a$2800, 
            Global`d4] - TBgamma[2, Global`a$2797, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2797]) - 
        (TBgamma[3, Global`a$2803, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2803] - TBgamma[3, Global`a$2806, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2806])*
         (TBgamma[3, Global`a$2809, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2809] - TBgamma[3, Global`a$2813, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2813]))*TBT[Global`flavor, 
        Global`af$2819, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$2819, Global`F3, Global`F4]) + 72*(-1 + Global`Nc^2)*
     (-1 + Global`Nf)*Global`Nf^2*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$2186, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$2186, Global`F3, Global`F4]) - 
    144*Global`Nc*(-1 + Global`Nf)*Global`Nf^2*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$2202, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$2202, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$2205, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$2205, Global`F3, Global`F4])))/
  (128*Global`Nc^2*(-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*(-1 + Global`Nf)*
   (-2 + Global`Nf^2)), 
 (8*Global`Nc^2*(9 - 8*Global`Nf)*(18 - 34*Global`Nf - 9*Global`Nf^2 + 
     8*Global`Nf^3)*(TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
       Global`F4, 3])*
    ((-(TBdeltaLorentz[Global`i$2944, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$2944, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$2944, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$2944, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$2944, 0]*TBgamma[0, Global`d1, 
          Global`dc$2947]) + TBgamma[Global`i$2944, Global`d1, 
        Global`dc$2947])*(-(TBdeltaLorentz[Global`i$2944, 0]*
         TBgamma[0, Global`d3, Global`dc$2950]) + TBgamma[Global`i$2944, 
        Global`d3, Global`dc$2950])*TBgamma5[Global`dc$2947, Global`d2]*
      TBgamma5[Global`dc$2950, Global`d4])*TBT[Global`color, Global`a$2953, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$2953, Global`A3, 
     Global`A4] + 8*Global`Nc^2*(9 - 8*Global`Nf)*
    (18 + 2*Global`Nf - 27*Global`Nf^2 + 8*Global`Nf^3)*
    TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
     Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
    TBdeltaFund[Global`flavor, Global`F4, 3]*
    ((-(TBdeltaLorentz[Global`i$3054, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$3054, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$3054, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$3054, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$3054, 0]*TBgamma[0, Global`d1, 
          Global`dc$3057]) + TBgamma[Global`i$3054, Global`d1, 
        Global`dc$3057])*(-(TBdeltaLorentz[Global`i$3054, 0]*
         TBgamma[0, Global`d3, Global`dc$3060]) + TBgamma[Global`i$3054, 
        Global`d3, Global`dc$3060])*TBgamma5[Global`dc$3057, Global`d2]*
      TBgamma5[Global`dc$3060, Global`d4])*TBT[Global`color, Global`a$3063, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$3063, Global`A3, 
     Global`A4] - 8*Global`Nc^2*(162 - 288*Global`Nf + 209*Global`Nf^2 - 
     18*Global`Nf^3 - 64*Global`Nf^4)*TBdeltaFund[Global`flavor, Global`F1, 
     Global`F2]*TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$3237, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$3237, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$3237, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$3237, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$3237, 0]*TBgamma[0, Global`d1, 
          Global`dc$3240]) + TBgamma[Global`i$3237, Global`d1, 
        Global`dc$3240])*(-(TBdeltaLorentz[Global`i$3237, 0]*
         TBgamma[0, Global`d3, Global`dc$3243]) + TBgamma[Global`i$3237, 
        Global`d3, Global`dc$3243])*TBgamma5[Global`dc$3240, Global`d2]*
      TBgamma5[Global`dc$3243, Global`d4])*TBT[Global`color, Global`a$3246, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$3246, Global`A3, 
     Global`A4] - 9*(1 - Global`Nc^2)*(1 - Global`Nf)*Global`Nf^2*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (2*(TBgamma[0, Global`d1, Global`a$3344]*TBgamma[1, Global`a$3344, 
           Global`d2] - TBgamma[0, Global`a$3347, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3347])*
        (TBgamma[0, Global`d3, Global`a$3350]*TBgamma[1, Global`a$3350, 
           Global`d4] - TBgamma[0, Global`a$3353, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3353]) - 
       (TBgamma[1, Global`a$3381, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$3381] - TBgamma[1, Global`a$3384, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3384])*
        (TBgamma[1, Global`a$3387, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$3387] - TBgamma[1, Global`a$3390, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3390]) + 
       2*(TBgamma[0, Global`d1, Global`a$3356]*TBgamma[2, Global`a$3356, 
           Global`d2] - TBgamma[0, Global`a$3359, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3359])*
        (TBgamma[0, Global`d3, Global`a$3362]*TBgamma[2, Global`a$3362, 
           Global`d4] - TBgamma[0, Global`a$3365, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3365]) - 
       (TBgamma[1, Global`d1, Global`a$3393]*TBgamma[2, Global`a$3393, 
           Global`d2] - TBgamma[1, Global`a$3396, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3396])*
        (TBgamma[1, Global`d3, Global`a$3400]*TBgamma[2, Global`a$3400, 
           Global`d4] - TBgamma[1, Global`a$3403, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3403]) - 
       (TBgamma[1, Global`d1, Global`a$3421]*TBgamma[2, Global`a$3421, 
           Global`d2] - TBgamma[1, Global`a$3418, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3418])*
        (TBgamma[1, Global`d3, Global`a$3427]*TBgamma[2, Global`a$3427, 
           Global`d4] - TBgamma[1, Global`a$3424, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3424]) - 
       (TBgamma[2, Global`a$3430, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$3430] - TBgamma[2, Global`a$3433, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3433])*
        (TBgamma[2, Global`a$3436, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$3436] - TBgamma[2, Global`a$3439, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3439]) + 
       2*(TBgamma[0, Global`d1, Global`a$3368]*TBgamma[3, Global`a$3368, 
           Global`d2] - TBgamma[0, Global`a$3371, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3371])*
        (TBgamma[0, Global`d3, Global`a$3374]*TBgamma[3, Global`a$3374, 
           Global`d4] - TBgamma[0, Global`a$3377, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3377]) - 
       (TBgamma[1, Global`d1, Global`a$3406]*TBgamma[3, Global`a$3406, 
           Global`d2] - TBgamma[1, Global`a$3409, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3409])*
        (TBgamma[1, Global`d3, Global`a$3412]*TBgamma[3, Global`a$3412, 
           Global`d4] - TBgamma[1, Global`a$3415, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3415]) - 
       (TBgamma[2, Global`d1, Global`a$3442]*TBgamma[3, Global`a$3442, 
           Global`d2] - TBgamma[2, Global`a$3445, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3445])*
        (TBgamma[2, Global`d3, Global`a$3448]*TBgamma[3, Global`a$3448, 
           Global`d4] - TBgamma[2, Global`a$3451, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3451]) - 
       (TBgamma[1, Global`d1, Global`a$3457]*TBgamma[3, Global`a$3457, 
           Global`d2] - TBgamma[1, Global`a$3454, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3454])*
        (TBgamma[1, Global`d3, Global`a$3463]*TBgamma[3, Global`a$3463, 
           Global`d4] - TBgamma[1, Global`a$3460, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3460]) - 
       (TBgamma[2, Global`d1, Global`a$3469]*TBgamma[3, Global`a$3469, 
           Global`d2] - TBgamma[2, Global`a$3466, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3466])*
        (TBgamma[2, Global`d3, Global`a$3475]*TBgamma[3, Global`a$3475, 
           Global`d4] - TBgamma[2, Global`a$3472, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3472]) - 
       (TBgamma[3, Global`a$3478, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$3478] - TBgamma[3, Global`a$3481, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3481])*
        (TBgamma[3, Global`a$3484, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$3484] - TBgamma[3, Global`a$3487, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3487])) + 
     9*(2*(TBgamma[0, Global`d1, Global`a$3490]*TBgamma[1, Global`a$3490, 
           Global`d2] - TBgamma[0, Global`a$3493, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3493])*
        (TBgamma[0, Global`d3, Global`a$3496]*TBgamma[1, Global`a$3496, 
           Global`d4] - TBgamma[0, Global`a$3499, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3499]) - 
       (TBgamma[1, Global`a$3526, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$3526] - TBgamma[1, Global`a$3529, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3529])*
        (TBgamma[1, Global`a$3532, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$3532] - TBgamma[1, Global`a$3535, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3535]) + 
       2*(TBgamma[0, Global`d1, Global`a$3502]*TBgamma[2, Global`a$3502, 
           Global`d2] - TBgamma[0, Global`a$3505, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3505])*
        (TBgamma[0, Global`d3, Global`a$3508]*TBgamma[2, Global`a$3508, 
           Global`d4] - TBgamma[0, Global`a$3511, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3511]) - 
       (TBgamma[1, Global`d1, Global`a$3538]*TBgamma[2, Global`a$3538, 
           Global`d2] - TBgamma[1, Global`a$3541, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3541])*
        (TBgamma[1, Global`d3, Global`a$3544]*TBgamma[2, Global`a$3544, 
           Global`d4] - TBgamma[1, Global`a$3547, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3547]) - 
       (TBgamma[1, Global`d1, Global`a$3565]*TBgamma[2, Global`a$3565, 
           Global`d2] - TBgamma[1, Global`a$3562, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3562])*
        (TBgamma[1, Global`d3, Global`a$3571]*TBgamma[2, Global`a$3571, 
           Global`d4] - TBgamma[1, Global`a$3568, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3568]) - 
       (TBgamma[2, Global`a$3574, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$3574] - TBgamma[2, Global`a$3577, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3577])*
        (TBgamma[2, Global`a$3580, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$3580] - TBgamma[2, Global`a$3583, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3583]) + 
       2*(TBgamma[0, Global`d1, Global`a$3514]*TBgamma[3, Global`a$3514, 
           Global`d2] - TBgamma[0, Global`a$3517, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3517])*
        (TBgamma[0, Global`d3, Global`a$3520]*TBgamma[3, Global`a$3520, 
           Global`d4] - TBgamma[0, Global`a$3523, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3523]) - 
       (TBgamma[1, Global`d1, Global`a$3550]*TBgamma[3, Global`a$3550, 
           Global`d2] - TBgamma[1, Global`a$3553, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3553])*
        (TBgamma[1, Global`d3, Global`a$3556]*TBgamma[3, Global`a$3556, 
           Global`d4] - TBgamma[1, Global`a$3559, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3559]) - 
       (TBgamma[2, Global`d1, Global`a$3586]*TBgamma[3, Global`a$3586, 
           Global`d2] - TBgamma[2, Global`a$3589, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3589])*
        (TBgamma[2, Global`d3, Global`a$3592]*TBgamma[3, Global`a$3592, 
           Global`d4] - TBgamma[2, Global`a$3595, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3595]) - 
       (TBgamma[1, Global`d1, Global`a$3601]*TBgamma[3, Global`a$3601, 
           Global`d2] - TBgamma[1, Global`a$3598, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3598])*
        (TBgamma[1, Global`d3, Global`a$3607]*TBgamma[3, Global`a$3607, 
           Global`d4] - TBgamma[1, Global`a$3604, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3604]) - 
       (TBgamma[2, Global`d1, Global`a$3613]*TBgamma[3, Global`a$3613, 
           Global`d2] - TBgamma[2, Global`a$3610, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3610])*
        (TBgamma[2, Global`d3, Global`a$3619]*TBgamma[3, Global`a$3619, 
           Global`d4] - TBgamma[2, Global`a$3616, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3616]) - 
       (TBgamma[3, Global`a$3622, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$3622] - TBgamma[3, Global`a$3625, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3625])*
        (TBgamma[3, Global`a$3628, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$3628] - TBgamma[3, Global`a$3631, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3631]))*TBT[Global`flavor, 
       Global`af$3634, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$3634, Global`F3, Global`F4]) - 18*Global`Nc*(1 - Global`Nf)*
    Global`Nf^2*TBT[Global`color, Global`ac$3939, Global`A1, Global`A2]*
    TBT[Global`color, Global`ac$3939, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (2*(TBgamma[0, Global`d1, Global`a$3650]*TBgamma[1, Global`a$3650, 
           Global`d2] - TBgamma[0, Global`a$3653, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3653])*
        (TBgamma[0, Global`d3, Global`a$3656]*TBgamma[1, Global`a$3656, 
           Global`d4] - TBgamma[0, Global`a$3659, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3659]) - 
       (TBgamma[1, Global`a$3686, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$3686] - TBgamma[1, Global`a$3689, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3689])*
        (TBgamma[1, Global`a$3692, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$3692] - TBgamma[1, Global`a$3695, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3695]) + 
       2*(TBgamma[0, Global`d1, Global`a$3662]*TBgamma[2, Global`a$3662, 
           Global`d2] - TBgamma[0, Global`a$3665, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3665])*
        (TBgamma[0, Global`d3, Global`a$3668]*TBgamma[2, Global`a$3668, 
           Global`d4] - TBgamma[0, Global`a$3671, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3671]) - 
       (TBgamma[1, Global`d1, Global`a$3698]*TBgamma[2, Global`a$3698, 
           Global`d2] - TBgamma[1, Global`a$3701, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3701])*
        (TBgamma[1, Global`d3, Global`a$3704]*TBgamma[2, Global`a$3704, 
           Global`d4] - TBgamma[1, Global`a$3707, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3707]) - 
       (TBgamma[1, Global`d1, Global`a$3725]*TBgamma[2, Global`a$3725, 
           Global`d2] - TBgamma[1, Global`a$3722, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3722])*
        (TBgamma[1, Global`d3, Global`a$3731]*TBgamma[2, Global`a$3731, 
           Global`d4] - TBgamma[1, Global`a$3728, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3728]) - 
       (TBgamma[2, Global`a$3734, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$3734] - TBgamma[2, Global`a$3737, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3737])*
        (TBgamma[2, Global`a$3740, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$3740] - TBgamma[2, Global`a$3743, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3743]) + 
       2*(TBgamma[0, Global`d1, Global`a$3674]*TBgamma[3, Global`a$3674, 
           Global`d2] - TBgamma[0, Global`a$3677, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3677])*
        (TBgamma[0, Global`d3, Global`a$3680]*TBgamma[3, Global`a$3680, 
           Global`d4] - TBgamma[0, Global`a$3683, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3683]) - 
       (TBgamma[1, Global`d1, Global`a$3710]*TBgamma[3, Global`a$3710, 
           Global`d2] - TBgamma[1, Global`a$3713, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3713])*
        (TBgamma[1, Global`d3, Global`a$3716]*TBgamma[3, Global`a$3716, 
           Global`d4] - TBgamma[1, Global`a$3719, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3719]) - 
       (TBgamma[2, Global`d1, Global`a$3746]*TBgamma[3, Global`a$3746, 
           Global`d2] - TBgamma[2, Global`a$3749, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3749])*
        (TBgamma[2, Global`d3, Global`a$3752]*TBgamma[3, Global`a$3752, 
           Global`d4] - TBgamma[2, Global`a$3755, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3755]) - 
       (TBgamma[1, Global`d1, Global`a$3761]*TBgamma[3, Global`a$3761, 
           Global`d2] - TBgamma[1, Global`a$3758, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3758])*
        (TBgamma[1, Global`d3, Global`a$3767]*TBgamma[3, Global`a$3767, 
           Global`d4] - TBgamma[1, Global`a$3764, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3764]) - 
       (TBgamma[2, Global`d1, Global`a$3773]*TBgamma[3, Global`a$3773, 
           Global`d2] - TBgamma[2, Global`a$3770, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3770])*
        (TBgamma[2, Global`d3, Global`a$3779]*TBgamma[3, Global`a$3779, 
           Global`d4] - TBgamma[2, Global`a$3776, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3776]) - 
       (TBgamma[3, Global`a$3782, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$3782] - TBgamma[3, Global`a$3785, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3785])*
        (TBgamma[3, Global`a$3789, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$3789] - TBgamma[3, Global`a$3792, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3792])) + 
     9*(2*(TBgamma[0, Global`d1, Global`a$3795]*TBgamma[1, Global`a$3795, 
           Global`d2] - TBgamma[0, Global`a$3798, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3798])*
        (TBgamma[0, Global`d3, Global`a$3801]*TBgamma[1, Global`a$3801, 
           Global`d4] - TBgamma[0, Global`a$3804, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3804]) - 
       (TBgamma[1, Global`a$3831, Global`d2]*TBgamma[1, Global`d1, 
           Global`a$3831] - TBgamma[1, Global`a$3834, Global`d2]*
          TBgamma[1, Global`d1, Global`a$3834])*
        (TBgamma[1, Global`a$3837, Global`d4]*TBgamma[1, Global`d3, 
           Global`a$3837] - TBgamma[1, Global`a$3840, Global`d4]*
          TBgamma[1, Global`d3, Global`a$3840]) + 
       2*(TBgamma[0, Global`d1, Global`a$3807]*TBgamma[2, Global`a$3807, 
           Global`d2] - TBgamma[0, Global`a$3810, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3810])*
        (TBgamma[0, Global`d3, Global`a$3813]*TBgamma[2, Global`a$3813, 
           Global`d4] - TBgamma[0, Global`a$3816, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3816]) - 
       (TBgamma[1, Global`d1, Global`a$3843]*TBgamma[2, Global`a$3843, 
           Global`d2] - TBgamma[1, Global`a$3846, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3846])*
        (TBgamma[1, Global`d3, Global`a$3849]*TBgamma[2, Global`a$3849, 
           Global`d4] - TBgamma[1, Global`a$3852, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3852]) - 
       (TBgamma[1, Global`d1, Global`a$3870]*TBgamma[2, Global`a$3870, 
           Global`d2] - TBgamma[1, Global`a$3867, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3867])*
        (TBgamma[1, Global`d3, Global`a$3876]*TBgamma[2, Global`a$3876, 
           Global`d4] - TBgamma[1, Global`a$3873, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3873]) - 
       (TBgamma[2, Global`a$3879, Global`d2]*TBgamma[2, Global`d1, 
           Global`a$3879] - TBgamma[2, Global`a$3882, Global`d2]*
          TBgamma[2, Global`d1, Global`a$3882])*
        (TBgamma[2, Global`a$3885, Global`d4]*TBgamma[2, Global`d3, 
           Global`a$3885] - TBgamma[2, Global`a$3888, Global`d4]*
          TBgamma[2, Global`d3, Global`a$3888]) + 
       2*(TBgamma[0, Global`d1, Global`a$3819]*TBgamma[3, Global`a$3819, 
           Global`d2] - TBgamma[0, Global`a$3822, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3822])*
        (TBgamma[0, Global`d3, Global`a$3825]*TBgamma[3, Global`a$3825, 
           Global`d4] - TBgamma[0, Global`a$3828, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3828]) - 
       (TBgamma[1, Global`d1, Global`a$3855]*TBgamma[3, Global`a$3855, 
           Global`d2] - TBgamma[1, Global`a$3858, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3858])*
        (TBgamma[1, Global`d3, Global`a$3861]*TBgamma[3, Global`a$3861, 
           Global`d4] - TBgamma[1, Global`a$3864, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3864]) - 
       (TBgamma[2, Global`d1, Global`a$3891]*TBgamma[3, Global`a$3891, 
           Global`d2] - TBgamma[2, Global`a$3894, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3894])*
        (TBgamma[2, Global`d3, Global`a$3897]*TBgamma[3, Global`a$3897, 
           Global`d4] - TBgamma[2, Global`a$3900, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3900]) - 
       (TBgamma[1, Global`d1, Global`a$3906]*TBgamma[3, Global`a$3906, 
           Global`d2] - TBgamma[1, Global`a$3903, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3903])*
        (TBgamma[1, Global`d3, Global`a$3912]*TBgamma[3, Global`a$3912, 
           Global`d4] - TBgamma[1, Global`a$3909, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3909]) - 
       (TBgamma[2, Global`d1, Global`a$3918]*TBgamma[3, Global`a$3918, 
           Global`d2] - TBgamma[2, Global`a$3915, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3915])*
        (TBgamma[2, Global`d3, Global`a$3924]*TBgamma[3, Global`a$3924, 
           Global`d4] - TBgamma[2, Global`a$3921, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3921]) - 
       (TBgamma[3, Global`a$3927, Global`d2]*TBgamma[3, Global`d1, 
           Global`a$3927] - TBgamma[3, Global`a$3930, Global`d2]*
          TBgamma[3, Global`d1, Global`a$3930])*
        (TBgamma[3, Global`a$3933, Global`d4]*TBgamma[3, Global`d3, 
           Global`a$3933] - TBgamma[3, Global`a$3936, Global`d4]*
          TBgamma[3, Global`d3, Global`a$3936]))*TBT[Global`flavor, 
       Global`af$3942, Global`F1, Global`F2]*TBT[Global`flavor, 
       Global`af$3942, Global`F3, Global`F4]) + 216*(-1 + Global`Nc^2)*
    (-1 + Global`Nf)*Global`Nf^2*TBdeltaFund[Global`color, Global`A1, 
     Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     9*TBT[Global`flavor, Global`f$3309, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3309, Global`F3, Global`F4]) - 
   432*Global`Nc*(-1 + Global`Nf)*Global`Nf^2*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    TBT[Global`color, Global`a$3325, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$3325, Global`A3, Global`A4]*
    (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     9*TBT[Global`flavor, Global`f$3328, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$3328, Global`F3, Global`F4]))/
  (128*Global`Nc^2*(-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*(-1 + Global`Nf)*
   (-2 + Global`Nf^2)), 
 (3*((TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
      TBdeltaFund[Global`flavor, Global`F4, 3]*
      (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$1912]*TBgamma[0, Global`d3, 
         Global`dc$1915]*TBgamma5[Global`dc$1912, Global`d2]*
        TBgamma5[Global`dc$1915, Global`d4]))/((-2 + Global`Nc)*Global`Nc) - 
    ((TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
        TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$1846]*TBgamma[0, Global`d3, 
         Global`dc$1849]*TBgamma5[Global`dc$1846, Global`d2]*
        TBgamma5[Global`dc$1849, Global`d4])*TBT[Global`color, Global`a$1852, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$1852, Global`A3, 
       Global`A4])/(-1 + Global`Nc^2) - 
    (Global`Nc*TBdeltaFund[Global`flavor, Global`F1, 3]*
      TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
       Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
      ((-(TBdeltaLorentz[Global`i$1956, 0]*TBgamma[0, Global`d1, 
            Global`d2]) + TBgamma[Global`i$1956, Global`d1, Global`d2])*
        (-(TBdeltaLorentz[Global`i$1956, 0]*TBgamma[0, Global`d3, 
            Global`d4]) + TBgamma[Global`i$1956, Global`d3, Global`d4]) + 
       (-(TBdeltaLorentz[Global`i$1956, 0]*TBgamma[0, Global`d1, 
            Global`dc$1959]) + TBgamma[Global`i$1956, Global`d1, 
          Global`dc$1959])*(-(TBdeltaLorentz[Global`i$1956, 0]*
           TBgamma[0, Global`d3, Global`dc$1962]) + TBgamma[Global`i$1956, 
          Global`d3, Global`dc$1962])*TBgamma5[Global`dc$1959, Global`d2]*
        TBgamma5[Global`dc$1962, Global`d4])*TBT[Global`color, Global`a$1965, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$1965, Global`A3, 
       Global`A4])/((-2 + Global`Nc)*(-1 + Global`Nc^2)) + 
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$2139]*TBgamma[0, Global`d3, 
         Global`dc$2142]*TBgamma5[Global`dc$2139, Global`d2]*
        TBgamma5[Global`dc$2142, Global`d4])*TBT[Global`color, Global`a$2145, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$2145, Global`A3, 
       Global`A4])/(-1 + Global`Nc^2)))/(16*(-1 + Global`Nf)), 
 -1/16*((TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$2991, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2991, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2991, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2991, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$2991, 0]*TBgamma[0, Global`d1, 
           Global`dc$2994]) + TBgamma[Global`i$2991, Global`d1, 
         Global`dc$2994])*(-(TBdeltaLorentz[Global`i$2991, 0]*
          TBgamma[0, Global`d3, Global`dc$2997]) + TBgamma[Global`i$2991, 
         Global`d3, Global`dc$2997])*TBgamma5[Global`dc$2994, Global`d2]*
       TBgamma5[Global`dc$2997, Global`d4])*TBT[Global`color, Global`a$3000, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3000, Global`A3, 
      Global`A4] + TBdeltaFund[Global`flavor, Global`F1, 3]*
     TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
      Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
     ((-(TBdeltaLorentz[Global`i$3079, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$3079, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$3079, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$3079, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$3079, 0]*TBgamma[0, Global`d1, 
           Global`dc$3082]) + TBgamma[Global`i$3079, Global`d1, 
         Global`dc$3082])*(-(TBdeltaLorentz[Global`i$3079, 0]*
          TBgamma[0, Global`d3, Global`dc$3085]) + TBgamma[Global`i$3079, 
         Global`d3, Global`dc$3085])*TBgamma5[Global`dc$3082, Global`d2]*
       TBgamma5[Global`dc$3085, Global`d4])*TBT[Global`color, Global`a$3088, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3088, Global`A3, 
      Global`A4] - TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$3284, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$3284, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$3284, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$3284, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$3284, 0]*TBgamma[0, Global`d1, 
           Global`dc$3287]) + TBgamma[Global`i$3284, Global`d1, 
         Global`dc$3287])*(-(TBdeltaLorentz[Global`i$3284, 0]*
          TBgamma[0, Global`d3, Global`dc$3290]) + TBgamma[Global`i$3284, 
         Global`d3, Global`dc$3290])*TBgamma5[Global`dc$3287, Global`d2]*
       TBgamma5[Global`dc$3290, Global`d4])*TBT[Global`color, Global`a$3293, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$3293, Global`A3, 
      Global`A4])/((-1 + Global`Nc^2)*(-1 + Global`Nf)), 
 (-3*Global`Nf*(2*Global`Nc*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
    (9 - 8*Global`Nf)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1711]*TBgamma[0, Global`d3, 
        Global`dc$1714]*TBgamma5[Global`dc$1711, Global`d2]*
       TBgamma5[Global`dc$1714, Global`d4]) + (9 - 8*Global`Nf)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$1730, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1730, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1730, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1730, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1730, 0]*TBgamma[0, Global`d1, 
           Global`dc$1733]) + TBgamma[Global`i$1730, Global`d1, 
         Global`dc$1733])*(-(TBdeltaLorentz[Global`i$1730, 0]*
          TBgamma[0, Global`d3, Global`dc$1736]) + TBgamma[Global`i$1730, 
         Global`d3, Global`dc$1736])*TBgamma5[Global`dc$1733, Global`d2]*
       TBgamma5[Global`dc$1736, Global`d4]) - 9*(-1 + Global`Nf)*Global`Nf*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2004]*TBgamma[0, Global`d3, 
        Global`dc$2007]*TBgamma5[Global`dc$2004, Global`d2]*
       TBgamma5[Global`dc$2007, Global`d4]) + 9*(1 - Global`Nf)*Global`Nf*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$2023, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2023, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2023, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2023, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$2023, 0]*TBgamma[0, Global`d1, 
           Global`dc$2026]) + TBgamma[Global`i$2023, Global`d1, 
         Global`dc$2026])*(-(TBdeltaLorentz[Global`i$2023, 0]*
          TBgamma[0, Global`d3, Global`dc$2029]) + TBgamma[Global`i$2023, 
         Global`d3, Global`dc$2029])*TBgamma5[Global`dc$2026, Global`d2]*
       TBgamma5[Global`dc$2029, Global`d4]) + 2*Global`Nc*(9 - 8*Global`Nf)*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1793]*TBgamma[0, Global`d3, 
        Global`dc$1796]*TBgamma5[Global`dc$1793, Global`d2]*
       TBgamma5[Global`dc$1796, Global`d4])*TBT[Global`color, Global`a$1799, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1799, Global`A3, 
      Global`A4] + 2*Global`Nc*(9 - 8*Global`Nf)*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$1815, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1815, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1815, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1815, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1815, 0]*TBgamma[0, Global`d1, 
           Global`dc$1818]) + TBgamma[Global`i$1815, Global`d1, 
         Global`dc$1818])*(-(TBdeltaLorentz[Global`i$1815, 0]*
          TBgamma[0, Global`d3, Global`dc$1821]) + TBgamma[Global`i$1815, 
         Global`d3, Global`dc$1821])*TBgamma5[Global`dc$1818, Global`d2]*
       TBgamma5[Global`dc$1821, Global`d4])*TBT[Global`color, Global`a$1824, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1824, Global`A3, 
      Global`A4] - 18*Global`Nc*(-1 + Global`Nf)*Global`Nf*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2086]*TBgamma[0, Global`d3, 
        Global`dc$2089]*TBgamma5[Global`dc$2086, Global`d2]*
       TBgamma5[Global`dc$2089, Global`d4])*TBT[Global`color, Global`a$2092, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2092, Global`A3, 
      Global`A4] + 18*Global`Nc*(1 - Global`Nf)*Global`Nf*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$2108, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2108, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2108, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2108, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$2108, 0]*TBgamma[0, Global`d1, 
           Global`dc$2111]) + TBgamma[Global`i$2108, Global`d1, 
         Global`dc$2111])*(-(TBdeltaLorentz[Global`i$2108, 0]*
          TBgamma[0, Global`d3, Global`dc$2114]) + TBgamma[Global`i$2108, 
         Global`d3, Global`dc$2114])*TBgamma5[Global`dc$2111, Global`d2]*
       TBgamma5[Global`dc$2114, Global`d4])*TBT[Global`color, Global`a$2117, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2117, Global`A3, 
      Global`A4] - 4*Global`Nc*(-1 + Global`Nf)*Global`Nf*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$2180, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$2180, Global`F3, Global`F4])))/
  (8*Global`Nc^3*(9 - 8*Global`Nf)^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
 (3*Global`Nf*((-1 + Global`Nc^2)*(-9 + 8*Global`Nf)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1711]*TBgamma[0, Global`d3, 
        Global`dc$1714]*TBgamma5[Global`dc$1711, Global`d2]*
       TBgamma5[Global`dc$1714, Global`d4]) + (1 - Global`Nc^2)*
     (9 - 8*Global`Nf)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$1730, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1730, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1730, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1730, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1730, 0]*TBgamma[0, Global`d1, 
           Global`dc$1733]) + TBgamma[Global`i$1730, Global`d1, 
         Global`dc$1733])*(-(TBdeltaLorentz[Global`i$1730, 0]*
          TBgamma[0, Global`d3, Global`dc$1736]) + TBgamma[Global`i$1730, 
         Global`d3, Global`dc$1736])*TBgamma5[Global`dc$1733, Global`d2]*
       TBgamma5[Global`dc$1736, Global`d4]) + 9*(-1 + Global`Nc^2)*
     (-1 + Global`Nf)*Global`Nf*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2004]*TBgamma[0, Global`d3, 
        Global`dc$2007]*TBgamma5[Global`dc$2004, Global`d2]*
       TBgamma5[Global`dc$2007, Global`d4]) + 9*(1 - Global`Nc^2)*
     (1 - Global`Nf)*Global`Nf*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$2023, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2023, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2023, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2023, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$2023, 0]*TBgamma[0, Global`d1, 
           Global`dc$2026]) + TBgamma[Global`i$2023, Global`d1, 
         Global`dc$2026])*(-(TBdeltaLorentz[Global`i$2023, 0]*
          TBgamma[0, Global`d3, Global`dc$2029]) + TBgamma[Global`i$2023, 
         Global`d3, Global`dc$2029])*TBgamma5[Global`dc$2026, Global`d2]*
       TBgamma5[Global`dc$2029, Global`d4]) + 2*Global`Nc*(9 - 8*Global`Nf)*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1793]*TBgamma[0, Global`d3, 
        Global`dc$1796]*TBgamma5[Global`dc$1793, Global`d2]*
       TBgamma5[Global`dc$1796, Global`d4])*TBT[Global`color, Global`a$1799, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1799, Global`A3, 
      Global`A4] + 2*Global`Nc*(9 - 8*Global`Nf)*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$1815, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1815, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1815, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1815, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1815, 0]*TBgamma[0, Global`d1, 
           Global`dc$1818]) + TBgamma[Global`i$1815, Global`d1, 
         Global`dc$1818])*(-(TBdeltaLorentz[Global`i$1815, 0]*
          TBgamma[0, Global`d3, Global`dc$1821]) + TBgamma[Global`i$1815, 
         Global`d3, Global`dc$1821])*TBgamma5[Global`dc$1818, Global`d2]*
       TBgamma5[Global`dc$1821, Global`d4])*TBT[Global`color, Global`a$1824, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1824, Global`A3, 
      Global`A4] - 4*Global`Nc^2*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$1988, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$1988, Global`A3, Global`A4] - 
    18*Global`Nc*(-1 + Global`Nf)*Global`Nf*TBdeltaFund[Global`flavor, 
      Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2086]*TBgamma[0, Global`d3, 
        Global`dc$2089]*TBgamma5[Global`dc$2086, Global`d2]*
       TBgamma5[Global`dc$2089, Global`d4])*TBT[Global`color, Global`a$2092, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2092, Global`A3, 
      Global`A4] + 18*Global`Nc*(1 - Global`Nf)*Global`Nf*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$2108, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2108, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2108, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2108, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$2108, 0]*TBgamma[0, Global`d1, 
           Global`dc$2111]) + TBgamma[Global`i$2108, Global`d1, 
         Global`dc$2111])*(-(TBdeltaLorentz[Global`i$2108, 0]*
          TBgamma[0, Global`d3, Global`dc$2114]) + TBgamma[Global`i$2108, 
         Global`d3, Global`dc$2114])*TBgamma5[Global`dc$2111, Global`d2]*
       TBgamma5[Global`dc$2114, Global`d4])*TBT[Global`color, Global`a$2117, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2117, Global`A3, 
      Global`A4] + 8*Global`Nc^2*(-1 + Global`Nf)*Global`Nf*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$2196, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$2196, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
      9*TBT[Global`flavor, Global`f$2199, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$2199, Global`F3, Global`F4])))/
  (4*Global`Nc^2*(-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*(-1 + Global`Nf)*
   (-2 + Global`Nf^2)), 
 -1/32*(Global`Nf*(4*(-4 + 3*Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
      TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
      TBdeltaFund[Global`flavor, Global`F4, 3]*
      (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
         Global`d4] - TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
         Global`d4]) + 6*Global`Nc*(9 - 8*Global`Nf)*
      TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
        TBgamma[0, Global`d3, Global`d4] - 
       TBgamma[0, Global`d1, Global`dc$1711]*TBgamma[0, Global`d3, 
         Global`dc$1714]*TBgamma5[Global`dc$1711, Global`d2]*
        TBgamma5[Global`dc$1714, Global`d4]) - 2*Global`Nc*(9 - 8*Global`Nf)*
      TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*((-(TBdeltaLorentz[Global`i$1730, 0]*
           TBgamma[0, Global`d1, Global`d2]) + TBgamma[Global`i$1730, 
          Global`d1, Global`d2])*(-(TBdeltaLorentz[Global`i$1730, 0]*
           TBgamma[0, Global`d3, Global`d4]) + TBgamma[Global`i$1730, 
          Global`d3, Global`d4]) - 
       (-(TBdeltaLorentz[Global`i$1730, 0]*TBgamma[0, Global`d1, 
            Global`dc$1733]) + TBgamma[Global`i$1730, Global`d1, 
          Global`dc$1733])*(-(TBdeltaLorentz[Global`i$1730, 0]*
           TBgamma[0, Global`d3, Global`dc$1736]) + TBgamma[Global`i$1730, 
          Global`d3, Global`dc$1736])*TBgamma5[Global`dc$1733, Global`d2]*
        TBgamma5[Global`dc$1736, Global`d4]) - 8*Global`Nc*(-1 + Global`Nf)*
      (-9 + 8*Global`Nf)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
      TBdeltaFund[Global`flavor, Global`F4, 3]*
      (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
       TBgamma[0, Global`d1, Global`dc$1887]*TBgamma[0, Global`d3, 
         Global`dc$1890]*TBgamma5[Global`dc$1887, Global`d2]*
        TBgamma5[Global`dc$1890, Global`d4]) - 54*Global`Nc*(-1 + Global`Nf)*
      Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
       TBgamma[0, Global`d1, Global`dc$2004]*TBgamma[0, Global`d3, 
         Global`dc$2007]*TBgamma5[Global`dc$2004, Global`d2]*
        TBgamma5[Global`dc$2007, Global`d4]) - 18*Global`Nc*(1 - Global`Nf)*
      Global`Nf*TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      ((-(TBdeltaLorentz[Global`i$2023, 0]*TBgamma[0, Global`d1, 
            Global`d2]) + TBgamma[Global`i$2023, Global`d1, Global`d2])*
        (-(TBdeltaLorentz[Global`i$2023, 0]*TBgamma[0, Global`d3, 
            Global`d4]) + TBgamma[Global`i$2023, Global`d3, Global`d4]) - 
       (-(TBdeltaLorentz[Global`i$2023, 0]*TBgamma[0, Global`d1, 
            Global`dc$2026]) + TBgamma[Global`i$2023, Global`d1, 
          Global`dc$2026])*(-(TBdeltaLorentz[Global`i$2023, 0]*
           TBgamma[0, Global`d3, Global`dc$2029]) + TBgamma[Global`i$2023, 
          Global`d3, Global`dc$2029])*TBgamma5[Global`dc$2026, Global`d2]*
        TBgamma5[Global`dc$2029, Global`d4]) + 12*Global`Nc^2*
      (9 - 8*Global`Nf)*(TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
        TBgamma[0, Global`d3, Global`d4] - 
       TBgamma[0, Global`d1, Global`dc$1793]*TBgamma[0, Global`d3, 
         Global`dc$1796]*TBgamma5[Global`dc$1793, Global`d2]*
        TBgamma5[Global`dc$1796, Global`d4])*TBT[Global`color, Global`a$1799, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$1799, Global`A3, 
       Global`A4] - 4*Global`Nc^2*(9 - 8*Global`Nf)*
      (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
       TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
         Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
       TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
         Global`F4, 3])*((-(TBdeltaLorentz[Global`i$1815, 0]*
           TBgamma[0, Global`d1, Global`d2]) + TBgamma[Global`i$1815, 
          Global`d1, Global`d2])*(-(TBdeltaLorentz[Global`i$1815, 0]*
           TBgamma[0, Global`d3, Global`d4]) + TBgamma[Global`i$1815, 
          Global`d3, Global`d4]) - 
       (-(TBdeltaLorentz[Global`i$1815, 0]*TBgamma[0, Global`d1, 
            Global`dc$1818]) + TBgamma[Global`i$1815, Global`d1, 
          Global`dc$1818])*(-(TBdeltaLorentz[Global`i$1815, 0]*
           TBgamma[0, Global`d3, Global`dc$1821]) + TBgamma[Global`i$1815, 
          Global`d3, Global`dc$1821])*TBgamma5[Global`dc$1818, Global`d2]*
        TBgamma5[Global`dc$1821, Global`d4])*TBT[Global`color, Global`a$1824, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$1824, Global`A3, 
       Global`A4] + 16*Global`Nc^2*(9 - 8*Global`Nf)*(1 - Global`Nf)*
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
      TBdeltaFund[Global`flavor, Global`F4, 3]*
      ((-(TBdeltaLorentz[Global`i$1925, 0]*TBgamma[0, Global`d1, 
            Global`d2]) + TBgamma[Global`i$1925, Global`d1, Global`d2])*
        (-(TBdeltaLorentz[Global`i$1925, 0]*TBgamma[0, Global`d3, 
            Global`d4]) + TBgamma[Global`i$1925, Global`d3, Global`d4]) - 
       (-(TBdeltaLorentz[Global`i$1925, 0]*TBgamma[0, Global`d1, 
            Global`dc$1928]) + TBgamma[Global`i$1925, Global`d1, 
          Global`dc$1928])*(-(TBdeltaLorentz[Global`i$1925, 0]*
           TBgamma[0, Global`d3, Global`dc$1931]) + TBgamma[Global`i$1925, 
          Global`d3, Global`dc$1931])*TBgamma5[Global`dc$1928, Global`d2]*
        TBgamma5[Global`dc$1931, Global`d4])*TBT[Global`color, Global`a$1934, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$1934, Global`A3, 
       Global`A4] - 32*Global`Nc*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
       Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
      TBdeltaFund[Global`flavor, Global`F4, 3]*
      (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
         Global`d4] - TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
         Global`d4])*TBT[Global`color, Global`a$1988, Global`A1, Global`A2]*
      TBT[Global`color, Global`a$1988, Global`A3, Global`A4] - 
     108*Global`Nc^2*(-1 + Global`Nf)*Global`Nf*TBdeltaFund[Global`flavor, 
       Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
       TBgamma[0, Global`d1, Global`dc$2086]*TBgamma[0, Global`d3, 
         Global`dc$2089]*TBgamma5[Global`dc$2086, Global`d2]*
        TBgamma5[Global`dc$2089, Global`d4])*TBT[Global`color, Global`a$2092, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$2092, Global`A3, 
       Global`A4] - 36*Global`Nc^2*(1 - Global`Nf)*Global`Nf*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      ((-(TBdeltaLorentz[Global`i$2108, 0]*TBgamma[0, Global`d1, 
            Global`d2]) + TBgamma[Global`i$2108, Global`d1, Global`d2])*
        (-(TBdeltaLorentz[Global`i$2108, 0]*TBgamma[0, Global`d3, 
            Global`d4]) + TBgamma[Global`i$2108, Global`d3, Global`d4]) - 
       (-(TBdeltaLorentz[Global`i$2108, 0]*TBgamma[0, Global`d1, 
            Global`dc$2111]) + TBgamma[Global`i$2108, Global`d1, 
          Global`dc$2111])*(-(TBdeltaLorentz[Global`i$2108, 0]*
           TBgamma[0, Global`d3, Global`dc$2114]) + TBgamma[Global`i$2108, 
          Global`d3, Global`dc$2114])*TBgamma5[Global`dc$2111, Global`d2]*
        TBgamma5[Global`dc$2114, Global`d4])*TBT[Global`color, Global`a$2117, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$2117, Global`A3, 
       Global`A4] + Global`Nc^2*(1 - Global`Nf)*Global`Nf*
      TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
        (2*(TBgamma[0, Global`d1, Global`a$2215]*TBgamma[1, Global`a$2215, 
             Global`d2] - TBgamma[0, Global`a$2218, Global`d2]*
            TBgamma[1, Global`d1, Global`a$2218])*
          (TBgamma[0, Global`d3, Global`a$2221]*TBgamma[1, Global`a$2221, 
             Global`d4] - TBgamma[0, Global`a$2224, Global`d4]*
            TBgamma[1, Global`d3, Global`a$2224]) - 
         (TBgamma[1, Global`a$2252, Global`d2]*TBgamma[1, Global`d1, 
             Global`a$2252] - TBgamma[1, Global`a$2255, Global`d2]*
            TBgamma[1, Global`d1, Global`a$2255])*
          (TBgamma[1, Global`a$2258, Global`d4]*TBgamma[1, Global`d3, 
             Global`a$2258] - TBgamma[1, Global`a$2261, Global`d4]*
            TBgamma[1, Global`d3, Global`a$2261]) + 
         2*(TBgamma[0, Global`d1, Global`a$2227]*TBgamma[2, Global`a$2227, 
             Global`d2] - TBgamma[0, Global`a$2230, Global`d2]*
            TBgamma[2, Global`d1, Global`a$2230])*
          (TBgamma[0, Global`d3, Global`a$2233]*TBgamma[2, Global`a$2233, 
             Global`d4] - TBgamma[0, Global`a$2236, Global`d4]*
            TBgamma[2, Global`d3, Global`a$2236]) - 
         (TBgamma[1, Global`d1, Global`a$2264]*TBgamma[2, Global`a$2264, 
             Global`d2] - TBgamma[1, Global`a$2267, Global`d2]*
            TBgamma[2, Global`d1, Global`a$2267])*
          (TBgamma[1, Global`d3, Global`a$2270]*TBgamma[2, Global`a$2270, 
             Global`d4] - TBgamma[1, Global`a$2273, Global`d4]*
            TBgamma[2, Global`d3, Global`a$2273]) - 
         (TBgamma[1, Global`d1, Global`a$2291]*TBgamma[2, Global`a$2291, 
             Global`d2] - TBgamma[1, Global`a$2288, Global`d2]*
            TBgamma[2, Global`d1, Global`a$2288])*
          (TBgamma[1, Global`d3, Global`a$2297]*TBgamma[2, Global`a$2297, 
             Global`d4] - TBgamma[1, Global`a$2294, Global`d4]*
            TBgamma[2, Global`d3, Global`a$2294]) - 
         (TBgamma[2, Global`a$2300, Global`d2]*TBgamma[2, Global`d1, 
             Global`a$2300] - TBgamma[2, Global`a$2303, Global`d2]*
            TBgamma[2, Global`d1, Global`a$2303])*
          (TBgamma[2, Global`a$2306, Global`d4]*TBgamma[2, Global`d3, 
             Global`a$2306] - TBgamma[2, Global`a$2309, Global`d4]*
            TBgamma[2, Global`d3, Global`a$2309]) + 
         2*(TBgamma[0, Global`d1, Global`a$2239]*TBgamma[3, Global`a$2239, 
             Global`d2] - TBgamma[0, Global`a$2242, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2242])*
          (TBgamma[0, Global`d3, Global`a$2246]*TBgamma[3, Global`a$2246, 
             Global`d4] - TBgamma[0, Global`a$2249, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2249]) - 
         (TBgamma[1, Global`d1, Global`a$2276]*TBgamma[3, Global`a$2276, 
             Global`d2] - TBgamma[1, Global`a$2279, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2279])*
          (TBgamma[1, Global`d3, Global`a$2282]*TBgamma[3, Global`a$2282, 
             Global`d4] - TBgamma[1, Global`a$2285, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2285]) - 
         (TBgamma[2, Global`d1, Global`a$2312]*TBgamma[3, Global`a$2312, 
             Global`d2] - TBgamma[2, Global`a$2315, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2315])*
          (TBgamma[2, Global`d3, Global`a$2318]*TBgamma[3, Global`a$2318, 
             Global`d4] - TBgamma[2, Global`a$2321, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2321]) - 
         (TBgamma[1, Global`d1, Global`a$2327]*TBgamma[3, Global`a$2327, 
             Global`d2] - TBgamma[1, Global`a$2324, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2324])*
          (TBgamma[1, Global`d3, Global`a$2333]*TBgamma[3, Global`a$2333, 
             Global`d4] - TBgamma[1, Global`a$2330, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2330]) - 
         (TBgamma[2, Global`d1, Global`a$2339]*TBgamma[3, Global`a$2339, 
             Global`d2] - TBgamma[2, Global`a$2336, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2336])*
          (TBgamma[2, Global`d3, Global`a$2345]*TBgamma[3, Global`a$2345, 
             Global`d4] - TBgamma[2, Global`a$2342, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2342]) - 
         (TBgamma[3, Global`a$2348, Global`d2]*TBgamma[3, Global`d1, 
             Global`a$2348] - TBgamma[3, Global`a$2351, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2351])*
          (TBgamma[3, Global`a$2354, Global`d4]*TBgamma[3, Global`d3, 
             Global`a$2354] - TBgamma[3, Global`a$2357, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2357])) + 
       9*(2*(TBgamma[0, Global`d1, Global`a$2360]*TBgamma[1, Global`a$2360, 
             Global`d2] - TBgamma[0, Global`a$2363, Global`d2]*
            TBgamma[1, Global`d1, Global`a$2363])*
          (TBgamma[0, Global`d3, Global`a$2366]*TBgamma[1, Global`a$2366, 
             Global`d4] - TBgamma[0, Global`a$2369, Global`d4]*
            TBgamma[1, Global`d3, Global`a$2369]) - 
         (TBgamma[1, Global`a$2396, Global`d2]*TBgamma[1, Global`d1, 
             Global`a$2396] - TBgamma[1, Global`a$2399, Global`d2]*
            TBgamma[1, Global`d1, Global`a$2399])*
          (TBgamma[1, Global`a$2402, Global`d4]*TBgamma[1, Global`d3, 
             Global`a$2402] - TBgamma[1, Global`a$2405, Global`d4]*
            TBgamma[1, Global`d3, Global`a$2405]) + 
         2*(TBgamma[0, Global`d1, Global`a$2372]*TBgamma[2, Global`a$2372, 
             Global`d2] - TBgamma[0, Global`a$2375, Global`d2]*
            TBgamma[2, Global`d1, Global`a$2375])*
          (TBgamma[0, Global`d3, Global`a$2378]*TBgamma[2, Global`a$2378, 
             Global`d4] - TBgamma[0, Global`a$2381, Global`d4]*
            TBgamma[2, Global`d3, Global`a$2381]) - 
         (TBgamma[1, Global`d1, Global`a$2408]*TBgamma[2, Global`a$2408, 
             Global`d2] - TBgamma[1, Global`a$2411, Global`d2]*
            TBgamma[2, Global`d1, Global`a$2411])*
          (TBgamma[1, Global`d3, Global`a$2414]*TBgamma[2, Global`a$2414, 
             Global`d4] - TBgamma[1, Global`a$2417, Global`d4]*
            TBgamma[2, Global`d3, Global`a$2417]) - 
         (TBgamma[1, Global`d1, Global`a$2435]*TBgamma[2, Global`a$2435, 
             Global`d2] - TBgamma[1, Global`a$2432, Global`d2]*
            TBgamma[2, Global`d1, Global`a$2432])*
          (TBgamma[1, Global`d3, Global`a$2441]*TBgamma[2, Global`a$2441, 
             Global`d4] - TBgamma[1, Global`a$2438, Global`d4]*
            TBgamma[2, Global`d3, Global`a$2438]) - 
         (TBgamma[2, Global`a$2444, Global`d2]*TBgamma[2, Global`d1, 
             Global`a$2444] - TBgamma[2, Global`a$2447, Global`d2]*
            TBgamma[2, Global`d1, Global`a$2447])*
          (TBgamma[2, Global`a$2450, Global`d4]*TBgamma[2, Global`d3, 
             Global`a$2450] - TBgamma[2, Global`a$2453, Global`d4]*
            TBgamma[2, Global`d3, Global`a$2453]) + 
         2*(TBgamma[0, Global`d1, Global`a$2384]*TBgamma[3, Global`a$2384, 
             Global`d2] - TBgamma[0, Global`a$2387, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2387])*
          (TBgamma[0, Global`d3, Global`a$2390]*TBgamma[3, Global`a$2390, 
             Global`d4] - TBgamma[0, Global`a$2393, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2393]) - 
         (TBgamma[1, Global`d1, Global`a$2420]*TBgamma[3, Global`a$2420, 
             Global`d2] - TBgamma[1, Global`a$2423, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2423])*
          (TBgamma[1, Global`d3, Global`a$2426]*TBgamma[3, Global`a$2426, 
             Global`d4] - TBgamma[1, Global`a$2429, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2429]) - 
         (TBgamma[2, Global`d1, Global`a$2456]*TBgamma[3, Global`a$2456, 
             Global`d2] - TBgamma[2, Global`a$2459, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2459])*
          (TBgamma[2, Global`d3, Global`a$2462]*TBgamma[3, Global`a$2462, 
             Global`d4] - TBgamma[2, Global`a$2465, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2465]) - 
         (TBgamma[1, Global`d1, Global`a$2471]*TBgamma[3, Global`a$2471, 
             Global`d2] - TBgamma[1, Global`a$2468, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2468])*
          (TBgamma[1, Global`d3, Global`a$2477]*TBgamma[3, Global`a$2477, 
             Global`d4] - TBgamma[1, Global`a$2474, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2474]) - 
         (TBgamma[2, Global`d1, Global`a$2483]*TBgamma[3, Global`a$2483, 
             Global`d2] - TBgamma[2, Global`a$2480, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2480])*
          (TBgamma[2, Global`d3, Global`a$2489]*TBgamma[3, Global`a$2489, 
             Global`d4] - TBgamma[2, Global`a$2486, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2486]) - 
         (TBgamma[3, Global`a$2492, Global`d2]*TBgamma[3, Global`d1, 
             Global`a$2492] - TBgamma[3, Global`a$2495, Global`d2]*
            TBgamma[3, Global`d1, Global`a$2495])*
          (TBgamma[3, Global`a$2498, Global`d4]*TBgamma[3, Global`d3, 
             Global`a$2498] - TBgamma[3, Global`a$2501, Global`d4]*
            TBgamma[3, Global`d3, Global`a$2501]))*TBT[Global`flavor, 
         Global`af$2504, Global`F1, Global`F2]*TBT[Global`flavor, 
         Global`af$2504, Global`F3, Global`F4])))/
   (Global`Nc^4*(9 - 8*Global`Nf)^2*(-1 + Global`Nf)*(-2 + Global`Nf^2)), 
 (Global`Nf*(8*(-1 + Global`Nc^2)*(-1 + Global`Nf)*(-9 + 8*Global`Nf)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
    3*Global`Nc*(-1 + Global`Nc^2)*(-9 + 8*Global`Nf)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1717]*TBgamma[0, Global`d3, 
        Global`dc$1720]*TBgamma5[Global`dc$1717, Global`d2]*
       TBgamma5[Global`dc$1720, Global`d4]) - Global`Nc*(1 - Global`Nc^2)*
     (9 - 8*Global`Nf)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$1736, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1736, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1736, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1736, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1736, 0]*TBgamma[0, Global`d1, 
           Global`dc$1739]) + TBgamma[Global`i$1736, Global`d1, 
         Global`dc$1739])*(-(TBdeltaLorentz[Global`i$1736, 0]*
          TBgamma[0, Global`d3, Global`dc$1742]) + TBgamma[Global`i$1736, 
         Global`d3, Global`dc$1742])*TBgamma5[Global`dc$1739, Global`d2]*
       TBgamma5[Global`dc$1742, Global`d4]) + 4*Global`Nc*(-1 + Global`Nc^2)*
     (-1 + Global`Nf)*(-9 + 8*Global`Nf)*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1893]*TBgamma[0, Global`d3, 
        Global`dc$1896]*TBgamma5[Global`dc$1893, Global`d2]*
       TBgamma5[Global`dc$1896, Global`d4]) + 27*Global`Nc*(-1 + Global`Nc^2)*
     (-1 + Global`Nf)*Global`Nf*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2010]*TBgamma[0, Global`d3, 
        Global`dc$2013]*TBgamma5[Global`dc$2010, Global`d2]*
       TBgamma5[Global`dc$2013, Global`d4]) - 9*Global`Nc*(1 - Global`Nc^2)*
     (1 - Global`Nf)*Global`Nf*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$2029, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2029, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2029, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2029, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$2029, 0]*TBgamma[0, Global`d1, 
           Global`dc$2032]) + TBgamma[Global`i$2029, Global`d1, 
         Global`dc$2032])*(-(TBdeltaLorentz[Global`i$2029, 0]*
          TBgamma[0, Global`d3, Global`dc$2035]) + TBgamma[Global`i$2029, 
         Global`d3, Global`dc$2035])*TBgamma5[Global`dc$2032, Global`d2]*
       TBgamma5[Global`dc$2035, Global`d4]) + 6*Global`Nc^2*(9 - 8*Global`Nf)*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*(TBgamma[0, Global`d1, Global`d2]*
       TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$1799]*TBgamma[0, Global`d3, 
        Global`dc$1802]*TBgamma5[Global`dc$1799, Global`d2]*
       TBgamma5[Global`dc$1802, Global`d4])*TBT[Global`color, Global`a$1805, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1805, Global`A3, 
      Global`A4] - 2*Global`Nc^2*(9 - 8*Global`Nf)*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2] - 
      TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
        Global`F2, 3])*(TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      TBdeltaFund[Global`flavor, Global`F3, 3]*TBdeltaFund[Global`flavor, 
        Global`F4, 3])*
     ((-(TBdeltaLorentz[Global`i$1821, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1821, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1821, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1821, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1821, 0]*TBgamma[0, Global`d1, 
           Global`dc$1824]) + TBgamma[Global`i$1821, Global`d1, 
         Global`dc$1824])*(-(TBdeltaLorentz[Global`i$1821, 0]*
          TBgamma[0, Global`d3, Global`dc$1827]) + TBgamma[Global`i$1821, 
         Global`d3, Global`dc$1827])*TBgamma5[Global`dc$1824, Global`d2]*
       TBgamma5[Global`dc$1827, Global`d4])*TBT[Global`color, Global`a$1830, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1830, Global`A3, 
      Global`A4] + 8*Global`Nc^2*(9 - 8*Global`Nf)*(1 - Global`Nf)*
     TBdeltaFund[Global`flavor, Global`F1, 3]*TBdeltaFund[Global`flavor, 
      Global`F2, 3]*TBdeltaFund[Global`flavor, Global`F3, 3]*
     TBdeltaFund[Global`flavor, Global`F4, 3]*
     ((-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$1931, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$1931, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$1931, 0]*TBgamma[0, Global`d1, 
           Global`dc$1934]) + TBgamma[Global`i$1931, Global`d1, 
         Global`dc$1934])*(-(TBdeltaLorentz[Global`i$1931, 0]*
          TBgamma[0, Global`d3, Global`dc$1937]) + TBgamma[Global`i$1931, 
         Global`d3, Global`dc$1937])*TBgamma5[Global`dc$1934, Global`d2]*
       TBgamma5[Global`dc$1937, Global`d4])*TBT[Global`color, Global`a$1940, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$1940, Global`A3, 
      Global`A4] + 4*Global`Nc*(-4 + Global`Nc^2)*(-1 + Global`Nf)*
     (-9 + 8*Global`Nf)*TBdeltaFund[Global`flavor, Global`F1, 3]*
     TBdeltaFund[Global`flavor, Global`F2, 3]*TBdeltaFund[Global`flavor, 
      Global`F3, 3]*TBdeltaFund[Global`flavor, Global`F4, 3]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$1994, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$1994, Global`A3, Global`A4] - 
    54*Global`Nc^2*(-1 + Global`Nf)*Global`Nf*TBdeltaFund[Global`flavor, 
      Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$2092]*TBgamma[0, Global`d3, 
        Global`dc$2095]*TBgamma5[Global`dc$2092, Global`d2]*
       TBgamma5[Global`dc$2095, Global`d4])*TBT[Global`color, Global`a$2098, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2098, Global`A3, 
      Global`A4] - 18*Global`Nc^2*(1 - Global`Nf)*Global`Nf*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$2114, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$2114, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$2114, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$2114, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$2114, 0]*TBgamma[0, Global`d1, 
           Global`dc$2117]) + TBgamma[Global`i$2114, Global`d1, 
         Global`dc$2117])*(-(TBdeltaLorentz[Global`i$2114, 0]*
          TBgamma[0, Global`d3, Global`dc$2120]) + TBgamma[Global`i$2114, 
         Global`d3, Global`dc$2120])*TBgamma5[Global`dc$2117, Global`d2]*
       TBgamma5[Global`dc$2120, Global`d4])*TBT[Global`color, Global`a$2123, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$2123, Global`A3, 
      Global`A4] - Global`Nc^3*(1 - Global`Nf)*Global`Nf*
     TBT[Global`color, Global`ac$2816, Global`A1, Global`A2]*
     TBT[Global`color, Global`ac$2816, Global`A3, Global`A4]*
     (4*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (2*(TBgamma[0, Global`d1, Global`a$2526]*TBgamma[1, Global`a$2526, 
            Global`d2] - TBgamma[0, Global`a$2529, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2529])*
         (TBgamma[0, Global`d3, Global`a$2532]*TBgamma[1, Global`a$2532, 
            Global`d4] - TBgamma[0, Global`a$2535, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2535]) - 
        (TBgamma[1, Global`a$2562, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2562] - TBgamma[1, Global`a$2565, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2565])*
         (TBgamma[1, Global`a$2568, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2568] - TBgamma[1, Global`a$2571, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2571]) + 
        2*(TBgamma[0, Global`d1, Global`a$2538]*TBgamma[2, Global`a$2538, 
            Global`d2] - TBgamma[0, Global`a$2541, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2541])*
         (TBgamma[0, Global`d3, Global`a$2544]*TBgamma[2, Global`a$2544, 
            Global`d4] - TBgamma[0, Global`a$2547, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2547]) - 
        (TBgamma[1, Global`d1, Global`a$2574]*TBgamma[2, Global`a$2574, 
            Global`d2] - TBgamma[1, Global`a$2577, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2577])*
         (TBgamma[1, Global`d3, Global`a$2580]*TBgamma[2, Global`a$2580, 
            Global`d4] - TBgamma[1, Global`a$2583, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2583]) - 
        (TBgamma[1, Global`d1, Global`a$2601]*TBgamma[2, Global`a$2601, 
            Global`d2] - TBgamma[1, Global`a$2598, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2598])*
         (TBgamma[1, Global`d3, Global`a$2607]*TBgamma[2, Global`a$2607, 
            Global`d4] - TBgamma[1, Global`a$2604, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2604]) - 
        (TBgamma[2, Global`a$2610, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2610] - TBgamma[2, Global`a$2613, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2613])*
         (TBgamma[2, Global`a$2616, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2616] - TBgamma[2, Global`a$2619, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2619]) + 
        2*(TBgamma[0, Global`d1, Global`a$2550]*TBgamma[3, Global`a$2550, 
            Global`d2] - TBgamma[0, Global`a$2553, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2553])*
         (TBgamma[0, Global`d3, Global`a$2556]*TBgamma[3, Global`a$2556, 
            Global`d4] - TBgamma[0, Global`a$2559, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2559]) - 
        (TBgamma[1, Global`d1, Global`a$2586]*TBgamma[3, Global`a$2586, 
            Global`d2] - TBgamma[1, Global`a$2589, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2589])*
         (TBgamma[1, Global`d3, Global`a$2592]*TBgamma[3, Global`a$2592, 
            Global`d4] - TBgamma[1, Global`a$2595, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2595]) - 
        (TBgamma[2, Global`d1, Global`a$2622]*TBgamma[3, Global`a$2622, 
            Global`d2] - TBgamma[2, Global`a$2625, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2625])*
         (TBgamma[2, Global`d3, Global`a$2628]*TBgamma[3, Global`a$2628, 
            Global`d4] - TBgamma[2, Global`a$2631, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2631]) - 
        (TBgamma[1, Global`d1, Global`a$2637]*TBgamma[3, Global`a$2637, 
            Global`d2] - TBgamma[1, Global`a$2634, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2634])*
         (TBgamma[1, Global`d3, Global`a$2644]*TBgamma[3, Global`a$2644, 
            Global`d4] - TBgamma[1, Global`a$2640, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2640]) - 
        (TBgamma[2, Global`d1, Global`a$2650]*TBgamma[3, Global`a$2650, 
            Global`d2] - TBgamma[2, Global`a$2647, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2647])*
         (TBgamma[2, Global`d3, Global`a$2656]*TBgamma[3, Global`a$2656, 
            Global`d4] - TBgamma[2, Global`a$2653, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2653]) - 
        (TBgamma[3, Global`a$2659, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2659] - TBgamma[3, Global`a$2662, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2662])*
         (TBgamma[3, Global`a$2665, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2665] - TBgamma[3, Global`a$2668, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2668])) + 
      9*(2*(TBgamma[0, Global`d1, Global`a$2671]*TBgamma[1, Global`a$2671, 
            Global`d2] - TBgamma[0, Global`a$2674, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2674])*
         (TBgamma[0, Global`d3, Global`a$2677]*TBgamma[1, Global`a$2677, 
            Global`d4] - TBgamma[0, Global`a$2680, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2680]) - 
        (TBgamma[1, Global`a$2707, Global`d2]*TBgamma[1, Global`d1, 
            Global`a$2707] - TBgamma[1, Global`a$2710, Global`d2]*
           TBgamma[1, Global`d1, Global`a$2710])*
         (TBgamma[1, Global`a$2713, Global`d4]*TBgamma[1, Global`d3, 
            Global`a$2713] - TBgamma[1, Global`a$2716, Global`d4]*
           TBgamma[1, Global`d3, Global`a$2716]) + 
        2*(TBgamma[0, Global`d1, Global`a$2683]*TBgamma[2, Global`a$2683, 
            Global`d2] - TBgamma[0, Global`a$2686, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2686])*
         (TBgamma[0, Global`d3, Global`a$2689]*TBgamma[2, Global`a$2689, 
            Global`d4] - TBgamma[0, Global`a$2692, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2692]) - 
        (TBgamma[1, Global`d1, Global`a$2719]*TBgamma[2, Global`a$2719, 
            Global`d2] - TBgamma[1, Global`a$2722, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2722])*
         (TBgamma[1, Global`d3, Global`a$2725]*TBgamma[2, Global`a$2725, 
            Global`d4] - TBgamma[1, Global`a$2728, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2728]) - 
        (TBgamma[1, Global`d1, Global`a$2746]*TBgamma[2, Global`a$2746, 
            Global`d2] - TBgamma[1, Global`a$2743, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2743])*
         (TBgamma[1, Global`d3, Global`a$2752]*TBgamma[2, Global`a$2752, 
            Global`d4] - TBgamma[1, Global`a$2749, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2749]) - 
        (TBgamma[2, Global`a$2755, Global`d2]*TBgamma[2, Global`d1, 
            Global`a$2755] - TBgamma[2, Global`a$2758, Global`d2]*
           TBgamma[2, Global`d1, Global`a$2758])*
         (TBgamma[2, Global`a$2761, Global`d4]*TBgamma[2, Global`d3, 
            Global`a$2761] - TBgamma[2, Global`a$2764, Global`d4]*
           TBgamma[2, Global`d3, Global`a$2764]) + 
        2*(TBgamma[0, Global`d1, Global`a$2695]*TBgamma[3, Global`a$2695, 
            Global`d2] - TBgamma[0, Global`a$2698, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2698])*
         (TBgamma[0, Global`d3, Global`a$2701]*TBgamma[3, Global`a$2701, 
            Global`d4] - TBgamma[0, Global`a$2704, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2704]) - 
        (TBgamma[1, Global`d1, Global`a$2731]*TBgamma[3, Global`a$2731, 
            Global`d2] - TBgamma[1, Global`a$2734, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2734])*
         (TBgamma[1, Global`d3, Global`a$2737]*TBgamma[3, Global`a$2737, 
            Global`d4] - TBgamma[1, Global`a$2740, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2740]) - 
        (TBgamma[2, Global`d1, Global`a$2767]*TBgamma[3, Global`a$2767, 
            Global`d2] - TBgamma[2, Global`a$2770, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2770])*
         (TBgamma[2, Global`d3, Global`a$2773]*TBgamma[3, Global`a$2773, 
            Global`d4] - TBgamma[2, Global`a$2776, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2776]) - 
        (TBgamma[1, Global`d1, Global`a$2782]*TBgamma[3, Global`a$2782, 
            Global`d2] - TBgamma[1, Global`a$2779, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2779])*
         (TBgamma[1, Global`d3, Global`a$2788]*TBgamma[3, Global`a$2788, 
            Global`d4] - TBgamma[1, Global`a$2785, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2785]) - 
        (TBgamma[2, Global`d1, Global`a$2794]*TBgamma[3, Global`a$2794, 
            Global`d2] - TBgamma[2, Global`a$2791, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2791])*
         (TBgamma[2, Global`d3, Global`a$2800]*TBgamma[3, Global`a$2800, 
            Global`d4] - TBgamma[2, Global`a$2797, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2797]) - 
        (TBgamma[3, Global`a$2803, Global`d2]*TBgamma[3, Global`d1, 
            Global`a$2803] - TBgamma[3, Global`a$2806, Global`d2]*
           TBgamma[3, Global`d1, Global`a$2806])*
         (TBgamma[3, Global`a$2809, Global`d4]*TBgamma[3, Global`d3, 
            Global`a$2809] - TBgamma[3, Global`a$2813, Global`d4]*
           TBgamma[3, Global`d3, Global`a$2813]))*TBT[Global`flavor, 
        Global`af$2819, Global`F1, Global`F2]*TBT[Global`flavor, 
        Global`af$2819, Global`F3, Global`F4])))/
  (8*Global`Nc^3*(-1 + Global`Nc^2)*(9 - 8*Global`Nf)^2*(-1 + Global`Nf)*
   (-2 + Global`Nf^2))}
