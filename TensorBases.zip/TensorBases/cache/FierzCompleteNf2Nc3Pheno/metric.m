(* Created with the Wolfram Language : www.wolfram.com *)
{{(-8*Global`Nc)/Global`Nf + 2*Global`Nc*Global`Nf*
    (3 + 4*Global`Nc*Global`Nf), Global`Nc*(8/Global`Nf - 6*Global`Nf), 
  -8*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*
   (-2 + Global`Nf + Global`Nf^2), -2*Global`Nc*Global`Nf, 
  -6*Global`Nc*Global`Nf, -12*Global`Nc*Global`Nf, 0, 
  -2*(-1 + Global`Nc^2)*Global`Nf, 0, 0}, 
 {Global`Nc*(8/Global`Nf - 6*Global`Nf), (-8*Global`Nc)/Global`Nf + 
   2*Global`Nc*Global`Nf*(3 + 4*Global`Nc*Global`Nf), 
  8*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*
   (-2 + Global`Nf + Global`Nf^2), -2*Global`Nc*Global`Nf, 
  -6*Global`Nc*Global`Nf, -12*Global`Nc*Global`Nf, 0, 
  -2*(-1 + Global`Nc^2)*Global`Nf, 0, 0}, 
 {-8*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*
   (-2 + Global`Nf + Global`Nf^2), 8*(-2 + Global`Nc)*(-1 + Global`Nc)*
   Global`Nc*(-2 + Global`Nf + Global`Nf^2), 32*(-2 + Global`Nc)^2*Global`Nc*
   (-1 + Global`Nc^2)*(-1 + Global`Nf)^2*Global`Nf^2, 
  -8*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf), 
  -24*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf), 0, 
  -16*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf), 0, 
  24*(-2 + Global`Nc)*(-1 + Global`Nc)*(1 + Global`Nc)*(-1 + Global`Nf), 0}, 
 {-2*Global`Nc*Global`Nf, -2*Global`Nc*Global`Nf, 
  -8*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf), 
  (2*Global`Nc*(-1 + 4*Global`Nc*Global`Nf))/Global`Nf, 
  (6*Global`Nc)/Global`Nf, 0, (4*Global`Nc*(-1 + 2*Global`Nc*Global`Nf))/
   Global`Nf, 0, (6*(-1 + Global`Nc^2))/Global`Nf, 
  (2*(-1 + Global`Nc^2)*(-2 + Global`Nf^2))/Global`Nf}, 
 {-6*Global`Nc*Global`Nf, -6*Global`Nc*Global`Nf, 
  -24*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf), 
  (6*Global`Nc)/Global`Nf, (6*Global`Nc*(1 + 4*Global`Nc*Global`Nf))/
   Global`Nf, 24*Global`Nc^2, (12*Global`Nc)/Global`Nf, 0, 
  (6*(-1 + Global`Nc^2))/Global`Nf, (6*(-1 + Global`Nc^2)*(-2 + Global`Nf^2))/
   Global`Nf}, {-12*Global`Nc*Global`Nf, -12*Global`Nc*Global`Nf, 0, 0, 
  24*Global`Nc^2, 48*Global`Nc^2, 0, 0, 0, 
  (12*(-1 + Global`Nc^2)*(-2 + Global`Nf^2))/Global`Nf}, 
 {0, 0, -16*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf), 
  (4*Global`Nc*(-1 + 2*Global`Nc*Global`Nf))/Global`Nf, 
  (12*Global`Nc)/Global`Nf, 0, (8*Global`Nc*(-1 + 2*Global`Nc*Global`Nf))/
   Global`Nf, 0, (12*(-1 + Global`Nc^2))/Global`Nf, 0}, 
 {-2*(-1 + Global`Nc^2)*Global`Nf, -2*(-1 + Global`Nc^2)*Global`Nf, 0, 0, 0, 
  0, 0, 4*(-1 + Global`Nc^2), 0, (-2*(-1 + Global`Nc^2)*(-2 + Global`Nf^2))/
   (Global`Nc*Global`Nf)}, {0, 0, 24*(-2 + Global`Nc)*(-1 + Global`Nc)*
   (1 + Global`Nc)*(-1 + Global`Nf), (6*(-1 + Global`Nc^2))/Global`Nf, 
  (6*(-1 + Global`Nc^2))/Global`Nf, 0, (12*(-1 + Global`Nc^2))/Global`Nf, 0, 
  (6*(-1 + Global`Nc^2)*(-1 + 2*Global`Nc*Global`Nf))/(Global`Nc*Global`Nf), 
  0}, {0, 0, 0, (2*(-1 + Global`Nc^2)*(-2 + Global`Nf^2))/Global`Nf, 
  (6*(-1 + Global`Nc^2)*(-2 + Global`Nf^2))/Global`Nf, 
  (12*(-1 + Global`Nc^2)*(-2 + Global`Nf^2))/Global`Nf, 0, 
  (-2*(-1 + Global`Nc^2)*(-2 + Global`Nf^2))/(Global`Nc*Global`Nf), 0, 
  4*(-1 + Global`Nc^2)*Global`Nf^2}}
