(* Created with the Wolfram Language : www.wolfram.com *)
{{(112*Global`Nc^5*(-1 + Global`Nf)^2*Global`Nf^5*(1 + Global`Nf) - 
    3*(-2 + Global`Nf^2)^2*(16 + 8*Global`Nf - 16*Global`Nf^2 - 
      5*Global`Nf^3 + 3*Global`Nf^4) + 8*Global`Nc^4*Global`Nf*
     (-16 - 16*Global`Nf + 37*Global`Nf^2 + 74*Global`Nf^3 - 12*Global`Nf^4 - 
      72*Global`Nf^5 - 9*Global`Nf^6 + 14*Global`Nf^7) + 
    3*Global`Nc*(-32 + 64*Global`Nf + 104*Global`Nf^2 - 60*Global`Nf^3 - 
      76*Global`Nf^4 + 20*Global`Nf^5 + 14*Global`Nf^6 - 17*Global`Nf^7 - 
      3*Global`Nf^8 + 4*Global`Nf^9) + 4*Global`Nc^2*
     (64 + 56*Global`Nf - 104*Global`Nf^2 - 106*Global`Nf^3 - 
      44*Global`Nf^4 + 38*Global`Nf^5 + 114*Global`Nf^6 + 9*Global`Nf^7 - 
      39*Global`Nf^8 + 3*Global`Nf^10) + 4*Global`Nc^3*
     (32 - 64*Global`Nf - 104*Global`Nf^2 + 70*Global`Nf^3 + 72*Global`Nf^4 - 
      40*Global`Nf^5 + 24*Global`Nf^6 + 34*Global`Nf^7 - 24*Global`Nf^8 - 
      3*Global`Nf^9 + 3*Global`Nf^10))/(192*(-1 + Global`Nc)*Global`Nc^2*
    (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf^2*(1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  (16*Global`Nc^5*(-1 + Global`Nf)^2*Global`Nf^5*(1 + Global`Nf) - 
    3*(-2 + Global`Nf^2)^2*(16 + 8*Global`Nf - 16*Global`Nf^2 - 
      5*Global`Nf^3 + 3*Global`Nf^4) + 8*Global`Nc^4*Global`Nf*
     (-16 - 16*Global`Nf + 43*Global`Nf^2 + 38*Global`Nf^3 - 36*Global`Nf^4 - 
      24*Global`Nf^5 + 9*Global`Nf^6 + 2*Global`Nf^7) + 
    3*Global`Nc*(-32 + 64*Global`Nf + 104*Global`Nf^2 - 140*Global`Nf^3 - 
      108*Global`Nf^4 + 116*Global`Nf^5 + 46*Global`Nf^6 - 33*Global`Nf^7 - 
      3*Global`Nf^8 + 4*Global`Nf^9) + 4*Global`Nc^2*
     (64 + 56*Global`Nf - 104*Global`Nf^2 - 118*Global`Nf^3 + 
      28*Global`Nf^4 + 86*Global`Nf^5 + 18*Global`Nf^6 - 27*Global`Nf^7 - 
      15*Global`Nf^8 + 3*Global`Nf^10) + 4*Global`Nc^3*
     (32 - 64*Global`Nf - 104*Global`Nf^2 + 130*Global`Nf^3 + 
      96*Global`Nf^4 - 88*Global`Nf^5 - 24*Global`Nf^6 + 22*Global`Nf^7 - 
      3*Global`Nf^9 + 3*Global`Nf^10))/(192*(-1 + Global`Nc)*Global`Nc^2*
    (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf^2*(1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  ((2 + Global`Nf)*(-1 + 2*Global`Nc*Global`Nf))/
   (16*(-2 + Global`Nc)*Global`Nc*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 
     5*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*
      Global`Nf^5 + 4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 
       3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), (-4 + 4*Global`Nf^2 + 3*Global`Nf^4)/
   (192*(-1 + Global`Nc)*Global`Nc*(1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf*
    (1 + Global`Nf)), ((-1 + Global`Nc)*Global`Nf*(2 + Global`Nf)*
    (-2 + Global`Nc*(-1 + 2*Global`Nf)))/(8*Global`Nc^2*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  (48*Global`Nf^2*(-2 - Global`Nf + 2*Global`Nf^2 + Global`Nf^3) + 
    Global`Nc*(64 + 32*Global`Nf - 80*Global`Nf^2 + 68*Global`Nf^3 + 
      28*Global`Nf^4 - 124*Global`Nf^5 - 12*Global`Nf^6 + 15*Global`Nf^7 - 
      9*Global`Nf^8) + 4*Global`Nc^4*Global`Nf^2*(-12 + 18*Global`Nf + 
      24*Global`Nf^2 - 14*Global`Nf^3 - 16*Global`Nf^4 - 4*Global`Nf^5 + 
      4*Global`Nf^6 - 3*Global`Nf^7 + 3*Global`Nf^8) + 
    4*Global`Nc^3*Global`Nf*(-8 - 20*Global`Nf - 10*Global`Nf^2 + 
      28*Global`Nf^3 + 24*Global`Nf^4 - 6*Global`Nf^5 - 9*Global`Nf^6 - 
      11*Global`Nf^7 + 3*Global`Nf^9) + Global`Nc^2*
     (32 - 64*Global`Nf + 40*Global`Nf^2 + 76*Global`Nf^3 - 132*Global`Nf^4 + 
      20*Global`Nf^5 + 90*Global`Nf^6 - 11*Global`Nf^7 - 9*Global`Nf^8 + 
      12*Global`Nf^9))/(384*(-1 + Global`Nc)*Global`Nc^2*(1 + Global`Nc)*
    (-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*(-16 - 8*Global`Nf + 
     16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  (-64 - 32*Global`Nf + 80*Global`Nf^2 - 68*Global`Nf^3 - 28*Global`Nf^4 + 
    124*Global`Nf^5 + 12*Global`Nf^6 - 15*Global`Nf^7 + 9*Global`Nf^8 - 
    4*Global`Nc^3*Global`Nf^2*(12 + 30*Global`Nf - 26*Global`Nf^3 - 
      16*Global`Nf^4 - 4*Global`Nf^5 + 4*Global`Nf^6 - 3*Global`Nf^7 + 
      3*Global`Nf^8) + Global`Nc*(-32 + 64*Global`Nf + 152*Global`Nf^2 + 
      20*Global`Nf^3 - 60*Global`Nf^4 - 116*Global`Nf^5 - 90*Global`Nf^6 + 
      11*Global`Nf^7 + 9*Global`Nf^8 - 12*Global`Nf^9) - 
    4*Global`Nc^2*Global`Nf*(-8 - 20*Global`Nf - 10*Global`Nf^2 + 
      28*Global`Nf^3 + 24*Global`Nf^4 - 6*Global`Nf^5 - 9*Global`Nf^6 - 
      11*Global`Nf^7 + 3*Global`Nf^9))/(384*(-1 + Global`Nc)*Global`Nc*
    (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 1/(12*(-1 + Global`Nc^2)*Global`Nf), 
  -1/4*(Global`Nf*(2 + Global`Nf)*(-1 + Global`Nc*Global`Nf))/
    (Global`Nc*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 
      3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 
      4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 3*Global`Nf^2 - 
        5*Global`Nf^3 + Global`Nf^5) + Global`Nc*(-8 + 16*Global`Nf + 
        18*Global`Nf^2 - 9*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/32*(-2 + Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*
     (-1 + Global`Nf^2))}, 
 {(16*Global`Nc^5*(-1 + Global`Nf)^2*Global`Nf^5*(1 + Global`Nf) - 
    3*(-2 + Global`Nf^2)^2*(16 + 8*Global`Nf - 16*Global`Nf^2 - 
      5*Global`Nf^3 + 3*Global`Nf^4) + 8*Global`Nc^4*Global`Nf*
     (-16 - 16*Global`Nf + 43*Global`Nf^2 + 38*Global`Nf^3 - 36*Global`Nf^4 - 
      24*Global`Nf^5 + 9*Global`Nf^6 + 2*Global`Nf^7) + 
    3*Global`Nc*(-32 + 64*Global`Nf + 104*Global`Nf^2 - 140*Global`Nf^3 - 
      108*Global`Nf^4 + 116*Global`Nf^5 + 46*Global`Nf^6 - 33*Global`Nf^7 - 
      3*Global`Nf^8 + 4*Global`Nf^9) + 4*Global`Nc^2*
     (64 + 56*Global`Nf - 104*Global`Nf^2 - 118*Global`Nf^3 + 
      28*Global`Nf^4 + 86*Global`Nf^5 + 18*Global`Nf^6 - 27*Global`Nf^7 - 
      15*Global`Nf^8 + 3*Global`Nf^10) + 4*Global`Nc^3*
     (32 - 64*Global`Nf - 104*Global`Nf^2 + 130*Global`Nf^3 + 
      96*Global`Nf^4 - 88*Global`Nf^5 - 24*Global`Nf^6 + 22*Global`Nf^7 - 
      3*Global`Nf^9 + 3*Global`Nf^10))/(192*(-1 + Global`Nc)*Global`Nc^2*
    (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf^2*(1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  (112*Global`Nc^5*(-1 + Global`Nf)^2*Global`Nf^5*(1 + Global`Nf) - 
    3*(-2 + Global`Nf^2)^2*(16 + 8*Global`Nf - 16*Global`Nf^2 - 
      5*Global`Nf^3 + 3*Global`Nf^4) + 8*Global`Nc^4*Global`Nf*
     (-16 - 16*Global`Nf + 37*Global`Nf^2 + 74*Global`Nf^3 - 12*Global`Nf^4 - 
      72*Global`Nf^5 - 9*Global`Nf^6 + 14*Global`Nf^7) + 
    3*Global`Nc*(-32 + 64*Global`Nf + 104*Global`Nf^2 - 60*Global`Nf^3 - 
      76*Global`Nf^4 + 20*Global`Nf^5 + 14*Global`Nf^6 - 17*Global`Nf^7 - 
      3*Global`Nf^8 + 4*Global`Nf^9) + 4*Global`Nc^2*
     (64 + 56*Global`Nf - 104*Global`Nf^2 - 106*Global`Nf^3 - 
      44*Global`Nf^4 + 38*Global`Nf^5 + 114*Global`Nf^6 + 9*Global`Nf^7 - 
      39*Global`Nf^8 + 3*Global`Nf^10) + 4*Global`Nc^3*
     (32 - 64*Global`Nf - 104*Global`Nf^2 + 70*Global`Nf^3 + 72*Global`Nf^4 - 
      40*Global`Nf^5 + 24*Global`Nf^6 + 34*Global`Nf^7 - 24*Global`Nf^8 - 
      3*Global`Nf^9 + 3*Global`Nf^10))/(192*(-1 + Global`Nc)*Global`Nc^2*
    (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf^2*(1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/16*((2 + Global`Nf)*(-1 + 2*Global`Nc*Global`Nf))/
    ((-2 + Global`Nc)*Global`Nc*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 
      5*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*
       Global`Nf^5 + 4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 
        3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 
  (-4 + 4*Global`Nf^2 + 3*Global`Nf^4)/(192*(-1 + Global`Nc)*Global`Nc*
    (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)), 
  -1/8*((-1 + Global`Nc)*Global`Nf*(2 + Global`Nf)*
     (-2 + Global`Nc*(-1 + 2*Global`Nf)))/(Global`Nc^2*
     (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
      4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
       (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 
  (-48*Global`Nf^2*(-2 - Global`Nf + 2*Global`Nf^2 + Global`Nf^3) + 
    Global`Nc*(64 + 32*Global`Nf - 176*Global`Nf^2 - 172*Global`Nf^3 + 
      28*Global`Nf^4 + 116*Global`Nf^5 + 84*Global`Nf^6 + 15*Global`Nf^7 - 
      9*Global`Nf^8) + 4*Global`Nc^4*Global`Nf^2*(12 - 18*Global`Nf - 
      24*Global`Nf^2 + 22*Global`Nf^3 + 8*Global`Nf^4 - 4*Global`Nf^5 + 
      4*Global`Nf^6 - 3*Global`Nf^7 + 3*Global`Nf^8) + 
    4*Global`Nc^3*Global`Nf*(-8 + 4*Global`Nf + 50*Global`Nf^2 + 
      28*Global`Nf^3 - 36*Global`Nf^4 - 30*Global`Nf^5 - 9*Global`Nf^6 - 
      11*Global`Nf^7 + 3*Global`Nf^9) + Global`Nc^2*
     (32 - 64*Global`Nf - 248*Global`Nf^2 + 124*Global`Nf^3 + 
      252*Global`Nf^4 - 28*Global`Nf^5 - 6*Global`Nf^6 - 11*Global`Nf^7 - 
      9*Global`Nf^8 + 12*Global`Nf^9))/(384*(-1 + Global`Nc)*Global`Nc^2*
    (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/384*(64 + 32*Global`Nf - 176*Global`Nf^2 - 172*Global`Nf^3 + 
     28*Global`Nf^4 + 116*Global`Nf^5 + 84*Global`Nf^6 + 15*Global`Nf^7 - 
     9*Global`Nf^8 + 4*Global`Nc^3*Global`Nf^2*(-12 - 30*Global`Nf + 
       34*Global`Nf^3 + 8*Global`Nf^4 - 4*Global`Nf^5 + 4*Global`Nf^6 - 
       3*Global`Nf^7 + 3*Global`Nf^8) + 4*Global`Nc^2*Global`Nf*
      (-8 + 4*Global`Nf + 50*Global`Nf^2 + 28*Global`Nf^3 - 36*Global`Nf^4 - 
       30*Global`Nf^5 - 9*Global`Nf^6 - 11*Global`Nf^7 + 3*Global`Nf^9) + 
     Global`Nc*(32 - 64*Global`Nf - 56*Global`Nf^2 + 220*Global`Nf^3 + 
       60*Global`Nf^4 - 124*Global`Nf^5 - 6*Global`Nf^6 - 11*Global`Nf^7 - 
       9*Global`Nf^8 + 12*Global`Nf^9))/((-1 + Global`Nc)*Global`Nc*
     (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*
     (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
      4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
       (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 
  1/(12*(-1 + Global`Nc^2)*Global`Nf), 
  (Global`Nf*(2 + Global`Nf)*(-1 + Global`Nc*Global`Nf))/
   (4*Global`Nc*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 
     3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 
     4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 3*Global`Nf^2 - 
       5*Global`Nf^3 + Global`Nf^5) + Global`Nc*(-8 + 16*Global`Nf + 
       18*Global`Nf^2 - 9*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/32*(-2 + Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*
     (-1 + Global`Nf^2))}, {((2 + Global`Nf)*(-1 + 2*Global`Nc*Global`Nf))/
   (16*(-2 + Global`Nc)*Global`Nc*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 
     5*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*
      Global`Nf^5 + 4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 
       3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/16*((2 + Global`Nf)*(-1 + 2*Global`Nc*Global`Nf))/
    ((-2 + Global`Nc)*Global`Nc*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 
      5*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*
       Global`Nf^5 + 4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 
        3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 
  (4 - 3*Global`Nf^2 + 4*Global`Nc^2*Global`Nf^4 + 
    4*Global`Nc*Global`Nf*(-2 + Global`Nf^2))/(32*(-2 + Global`Nc)^2*
    (-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf)*Global`Nf*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 0, 
  (8 - 6*Global`Nf^2 + 2*Global`Nc^2*Global`Nf^3*(-1 + 2*Global`Nf) + 
    Global`Nc*(4 - 8*Global`Nf - 3*Global`Nf^2 + 2*Global`Nf^3))/
   (16*(-2 + Global`Nc)*Global`Nc^2*(-1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  (-8 + 6*Global`Nf^2 + 2*Global`Nc^2*(1 - 2*Global`Nf)*Global`Nf^3 + 
    Global`Nc*(-4 + 8*Global`Nf + 3*Global`Nf^2 - 2*Global`Nf^3))/
   (32*(-2 + Global`Nc)*Global`Nc^2*(-1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  ((1 + 2*Global`Nf)*(-4 + 3*Global`Nf^2 + 2*Global`Nc*Global`Nf^3))/
   (32*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 0, 
  -1/8*(4 - 3*Global`Nf^2 + 2*Global`Nc^2*Global`Nf^4 + 
     Global`Nc*Global`Nf*(-4 + Global`Nf^2))/((-2 + Global`Nc)*
     (-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf)*(-16 - 8*Global`Nf + 
      16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
      4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
       (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 0}, 
 {(-4 + 4*Global`Nf^2 + 3*Global`Nf^4)/(192*(-1 + Global`Nc)*Global`Nc*
    (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)), 
  (-4 + 4*Global`Nf^2 + 3*Global`Nf^4)/(192*(-1 + Global`Nc)*Global`Nc*
    (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)), 0, 
  (-32*(-1 + Global`Nf^2) + 3*Global`Nc^2*(-12 + 12*Global`Nf^2 + 
      Global`Nf^4))/(192*(-1 + Global`Nc)*Global`Nc^2*(1 + Global`Nc)*
    (-1 + Global`Nf)*(1 + Global`Nf)), 0, 
  (3*Global`Nc^2*(-2 + Global`Nf^2)^2 + 16*(-1 + Global`Nf^2))/
   (384*(-1 + Global`Nc)*Global`Nc^2*(1 + Global`Nc)*(-1 + Global`Nf)*
    (1 + Global`Nf)), (32*(-1 + Global`Nf^2) - 
    3*Global`Nc^2*(-12 + 12*Global`Nf^2 + Global`Nf^4))/
   (384*(-1 + Global`Nc)*Global`Nc^2*(1 + Global`Nc)*(-1 + Global`Nf)*
    (1 + Global`Nf)), -(12*Global`Nc - 12*Global`Nc^3)^(-1), 0, 
  -1/32*(Global`Nf*(-2 + Global`Nf^2))/((-1 + Global`Nc)*(1 + Global`Nc)*
     (-1 + Global`Nf)*(1 + Global`Nf))}, 
 {((-1 + Global`Nc)*Global`Nf*(2 + Global`Nf)*
    (-2 + Global`Nc*(-1 + 2*Global`Nf)))/(8*Global`Nc^2*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/8*((-1 + Global`Nc)*Global`Nf*(2 + Global`Nf)*
     (-2 + Global`Nc*(-1 + 2*Global`Nf)))/(Global`Nc^2*
     (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
      4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
       (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 
  (8 - 6*Global`Nf^2 + 2*Global`Nc^2*Global`Nf^3*(-1 + 2*Global`Nf) + 
    Global`Nc*(4 - 8*Global`Nf - 3*Global`Nf^2 + 2*Global`Nf^3))/
   (16*(-2 + Global`Nc)*Global`Nc^2*(-1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 0, 
  (Global`Nf*(4*(-4 + 7*Global`Nf^2 + 3*Global`Nf^3) - 
     4*Global`Nc*(8 + 8*Global`Nf - 2*Global`Nf^2 - 3*Global`Nf^3 + 
       Global`Nf^4) + Global`Nc^2*(12 + 48*Global`Nf + 27*Global`Nf^2 - 
       21*Global`Nf^3 - 8*Global`Nf^4 + 4*Global`Nf^5) + 
     Global`Nc^4*(-6*Global`Nf^4 + 8*Global`Nf^6) + 
     Global`Nc^3*(12 + 24*Global`Nf - 13*Global`Nf^2 - 53*Global`Nf^3 - 
       26*Global`Nf^4 + 4*Global`Nf^5 + 8*Global`Nf^6)))/
   (24*Global`Nc^3*(1 + Global`Nf)*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 
     5*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*
      Global`Nf^5 + 4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 
       3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/48*(Global`Nf*(4*(-4 + 7*Global`Nf^2 + 3*Global`Nf^3) - 
      4*Global`Nc*(8 + 8*Global`Nf - 2*Global`Nf^2 - 3*Global`Nf^3 + 
        Global`Nf^4) + Global`Nc^2*(12 + 48*Global`Nf + 27*Global`Nf^2 - 
        21*Global`Nf^3 - 8*Global`Nf^4 + 4*Global`Nf^5) + 
      Global`Nc^4*(-6*Global`Nf^4 + 8*Global`Nf^6) + 
      Global`Nc^3*(12 + 24*Global`Nf - 13*Global`Nf^2 - 53*Global`Nf^3 - 
        26*Global`Nf^4 + 4*Global`Nf^5 + 8*Global`Nf^6)))/
    (Global`Nc^3*(1 + Global`Nf)*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 
      5*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*
       Global`Nf^5 + 4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 
        3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/16*(Global`Nf*(8 - 6*Global`Nf^2 + 8*Global`Nf^3 + 6*Global`Nf^4 - 
      2*Global`Nc^3*Global`Nf^4 + Global`Nc^2*(4 + 8*Global`Nf + 
        Global`Nf^2 - 11*Global`Nf^3 - 6*Global`Nf^4 + 4*Global`Nf^5) + 
      Global`Nc*(12 - 29*Global`Nf^2 - 15*Global`Nf^3 + 10*Global`Nf^4 + 
        4*Global`Nf^5)))/(Global`Nc^2*(1 + Global`Nf)*
     (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
      4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
       (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 0, 
  -1/12*(Global`Nf*(8 - 14*Global`Nf^2 - 6*Global`Nf^3 + 
      2*Global`Nc^3*Global`Nf^5 + Global`Nc*(4 + 8*Global`Nf + 
        5*Global`Nf^2 - 4*Global`Nf^3 - Global`Nf^4) + 
      Global`Nc^2*Global`Nf*(-4 - 8*Global`Nf + Global`Nf^2 + 5*Global`Nf^3 + 
        2*Global`Nf^4)))/(Global`Nc^2*(1 + Global`Nf)*
     (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
      4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
       (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 0}, 
 {(48*Global`Nf^2*(-2 - Global`Nf + 2*Global`Nf^2 + Global`Nf^3) + 
    Global`Nc*(64 + 32*Global`Nf - 80*Global`Nf^2 + 68*Global`Nf^3 + 
      28*Global`Nf^4 - 124*Global`Nf^5 - 12*Global`Nf^6 + 15*Global`Nf^7 - 
      9*Global`Nf^8) + 4*Global`Nc^4*Global`Nf^2*(-12 + 18*Global`Nf + 
      24*Global`Nf^2 - 14*Global`Nf^3 - 16*Global`Nf^4 - 4*Global`Nf^5 + 
      4*Global`Nf^6 - 3*Global`Nf^7 + 3*Global`Nf^8) + 
    4*Global`Nc^3*Global`Nf*(-8 - 20*Global`Nf - 10*Global`Nf^2 + 
      28*Global`Nf^3 + 24*Global`Nf^4 - 6*Global`Nf^5 - 9*Global`Nf^6 - 
      11*Global`Nf^7 + 3*Global`Nf^9) + Global`Nc^2*
     (32 - 64*Global`Nf + 40*Global`Nf^2 + 76*Global`Nf^3 - 132*Global`Nf^4 + 
      20*Global`Nf^5 + 90*Global`Nf^6 - 11*Global`Nf^7 - 9*Global`Nf^8 + 
      12*Global`Nf^9))/(384*(-1 + Global`Nc)*Global`Nc^2*(1 + Global`Nc)*
    (-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*(-16 - 8*Global`Nf + 
     16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  (-48*Global`Nf^2*(-2 - Global`Nf + 2*Global`Nf^2 + Global`Nf^3) + 
    Global`Nc*(64 + 32*Global`Nf - 176*Global`Nf^2 - 172*Global`Nf^3 + 
      28*Global`Nf^4 + 116*Global`Nf^5 + 84*Global`Nf^6 + 15*Global`Nf^7 - 
      9*Global`Nf^8) + 4*Global`Nc^4*Global`Nf^2*(12 - 18*Global`Nf - 
      24*Global`Nf^2 + 22*Global`Nf^3 + 8*Global`Nf^4 - 4*Global`Nf^5 + 
      4*Global`Nf^6 - 3*Global`Nf^7 + 3*Global`Nf^8) + 
    4*Global`Nc^3*Global`Nf*(-8 + 4*Global`Nf + 50*Global`Nf^2 + 
      28*Global`Nf^3 - 36*Global`Nf^4 - 30*Global`Nf^5 - 9*Global`Nf^6 - 
      11*Global`Nf^7 + 3*Global`Nf^9) + Global`Nc^2*
     (32 - 64*Global`Nf - 248*Global`Nf^2 + 124*Global`Nf^3 + 
      252*Global`Nf^4 - 28*Global`Nf^5 - 6*Global`Nf^6 - 11*Global`Nf^7 - 
      9*Global`Nf^8 + 12*Global`Nf^9))/(384*(-1 + Global`Nc)*Global`Nc^2*
    (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  (-8 + 6*Global`Nf^2 + 2*Global`Nc^2*(1 - 2*Global`Nf)*Global`Nf^3 + 
    Global`Nc*(-4 + 8*Global`Nf + 3*Global`Nf^2 - 2*Global`Nf^3))/
   (32*(-2 + Global`Nc)*Global`Nc^2*(-1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  (3*Global`Nc^2*(-2 + Global`Nf^2)^2 + 16*(-1 + Global`Nf^2))/
   (384*(-1 + Global`Nc)*Global`Nc^2*(1 + Global`Nc)*(-1 + Global`Nf)*
    (1 + Global`Nf)), 
  -1/48*(Global`Nf*(4*(-4 + 7*Global`Nf^2 + 3*Global`Nf^3) - 
      4*Global`Nc*(8 + 8*Global`Nf - 2*Global`Nf^2 - 3*Global`Nf^3 + 
        Global`Nf^4) + Global`Nc^2*(12 + 48*Global`Nf + 27*Global`Nf^2 - 
        21*Global`Nf^3 - 8*Global`Nf^4 + 4*Global`Nf^5) + 
      Global`Nc^4*(-6*Global`Nf^4 + 8*Global`Nf^6) + 
      Global`Nc^3*(12 + 24*Global`Nf - 13*Global`Nf^2 - 53*Global`Nf^3 - 
        26*Global`Nf^4 + 4*Global`Nf^5 + 8*Global`Nf^6)))/
    (Global`Nc^3*(1 + Global`Nf)*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 
      5*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*
       Global`Nf^5 + 4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 
        3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 
  (-32*Global`Nf*(4 - 4*Global`Nf - 7*Global`Nf^2 + 4*Global`Nf^3 + 
      3*Global`Nf^4) + 32*Global`Nc*Global`Nf*(-8 + 10*Global`Nf^2 + 
      Global`Nf^3 - 4*Global`Nf^4 + Global`Nf^5) + 
    4*Global`Nc^6*Global`Nf^5*(16 - 16*Global`Nf - 20*Global`Nf^2 + 
      20*Global`Nf^3 - 3*Global`Nf^4 + 3*Global`Nf^5) - 
    8*Global`Nc^2*Global`Nf*(-28 - 20*Global`Nf + 49*Global`Nf^2 + 
      32*Global`Nf^3 - 25*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6) + 
    Global`Nc^3*(64 + 384*Global`Nf - 32*Global`Nf^2 - 668*Global`Nf^3 - 
      324*Global`Nf^4 + 340*Global`Nf^5 + 244*Global`Nf^6 + 47*Global`Nf^7 - 
      73*Global`Nf^8) + 4*Global`Nc^5*Global`Nf*(-32 - 32*Global`Nf + 
      94*Global`Nf^2 + 108*Global`Nf^3 - 60*Global`Nf^4 - 78*Global`Nf^5 - 
      17*Global`Nf^6 + 5*Global`Nf^7 + 3*Global`Nf^9) + 
    Global`Nc^4*(32 - 160*Global`Nf - 392*Global`Nf^2 + 268*Global`Nf^3 + 
      444*Global`Nf^4 - 156*Global`Nf^5 - 6*Global`Nf^6 + 85*Global`Nf^7 - 
      73*Global`Nf^8 + 12*Global`Nf^9))/(768*(-1 + Global`Nc)*Global`Nc^3*
    (1 + Global`Nc)*(-1 + Global`Nf)*(1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/768*(12*Global`Nc^5*Global`Nf^5*(-8 + 8*Global`Nf + 4*Global`Nf^2 - 
       4*Global`Nf^3 - Global`Nf^4 + Global`Nf^5) + 
     32*(8 - 2*Global`Nf - 10*Global`Nf^2 - 2*Global`Nf^3 - Global`Nf^4 + 
       4*Global`Nf^5 + 3*Global`Nf^6) + 8*Global`Nc*(16 - 68*Global`Nf - 
       16*Global`Nf^2 + 137*Global`Nf^3 - 101*Global`Nf^5 + 12*Global`Nf^6 + 
       20*Global`Nf^7) + Global`Nc^2*(-192 - 128*Global`Nf - 32*Global`Nf^2 + 
       500*Global`Nf^3 + 796*Global`Nf^4 - 444*Global`Nf^5 - 
       684*Global`Nf^6 + 111*Global`Nf^7 + 55*Global`Nf^8) + 
     12*Global`Nc^4*Global`Nf*(16 + 16*Global`Nf - 34*Global`Nf^2 - 
       52*Global`Nf^3 + 24*Global`Nf^4 + 46*Global`Nf^5 - 11*Global`Nf^6 - 
       9*Global`Nf^7 + Global`Nf^9) + Global`Nc^3*(-96 + 480*Global`Nf + 
       24*Global`Nf^2 - 996*Global`Nf^3 + 60*Global`Nf^4 + 916*Global`Nf^5 - 
       166*Global`Nf^6 - 235*Global`Nf^7 + 55*Global`Nf^8 + 12*Global`Nf^9))/
    ((-1 + Global`Nc)*Global`Nc^2*(1 + Global`Nc)*(-1 + Global`Nf)*
     (1 + Global`Nf)*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 
      3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 
      4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 3*Global`Nf^2 - 
        5*Global`Nf^3 + Global`Nf^5) + Global`Nc*(-8 + 16*Global`Nf + 
        18*Global`Nf^2 - 9*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nf^5))), 
  -(24*Global`Nc - 24*Global`Nc^3)^(-1), 
  (Global`Nf*(8 - 14*Global`Nf^2 - 6*Global`Nf^3 + 
     2*Global`Nc^3*Global`Nf^5 + Global`Nc*(4 + 8*Global`Nf + 5*Global`Nf^2 - 
       4*Global`Nf^3 - Global`Nf^4) + Global`Nc^2*Global`Nf*
      (-4 - 8*Global`Nf + Global`Nf^2 + 5*Global`Nf^3 + 2*Global`Nf^4)))/
   (24*Global`Nc^2*(1 + Global`Nf)*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 
     5*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*
      Global`Nf^5 + 4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 
       3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/64*(Global`Nf*(-2 + Global`Nf^2))/((-1 + Global`Nc)*(1 + Global`Nc)*
     (-1 + Global`Nf)*(1 + Global`Nf))}, 
 {(-64 - 32*Global`Nf + 80*Global`Nf^2 - 68*Global`Nf^3 - 28*Global`Nf^4 + 
    124*Global`Nf^5 + 12*Global`Nf^6 - 15*Global`Nf^7 + 9*Global`Nf^8 - 
    4*Global`Nc^3*Global`Nf^2*(12 + 30*Global`Nf - 26*Global`Nf^3 - 
      16*Global`Nf^4 - 4*Global`Nf^5 + 4*Global`Nf^6 - 3*Global`Nf^7 + 
      3*Global`Nf^8) + Global`Nc*(-32 + 64*Global`Nf + 152*Global`Nf^2 + 
      20*Global`Nf^3 - 60*Global`Nf^4 - 116*Global`Nf^5 - 90*Global`Nf^6 + 
      11*Global`Nf^7 + 9*Global`Nf^8 - 12*Global`Nf^9) - 
    4*Global`Nc^2*Global`Nf*(-8 - 20*Global`Nf - 10*Global`Nf^2 + 
      28*Global`Nf^3 + 24*Global`Nf^4 - 6*Global`Nf^5 - 9*Global`Nf^6 - 
      11*Global`Nf^7 + 3*Global`Nf^9))/(384*(-1 + Global`Nc)*Global`Nc*
    (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/384*(64 + 32*Global`Nf - 176*Global`Nf^2 - 172*Global`Nf^3 + 
     28*Global`Nf^4 + 116*Global`Nf^5 + 84*Global`Nf^6 + 15*Global`Nf^7 - 
     9*Global`Nf^8 + 4*Global`Nc^3*Global`Nf^2*(-12 - 30*Global`Nf + 
       34*Global`Nf^3 + 8*Global`Nf^4 - 4*Global`Nf^5 + 4*Global`Nf^6 - 
       3*Global`Nf^7 + 3*Global`Nf^8) + 4*Global`Nc^2*Global`Nf*
      (-8 + 4*Global`Nf + 50*Global`Nf^2 + 28*Global`Nf^3 - 36*Global`Nf^4 - 
       30*Global`Nf^5 - 9*Global`Nf^6 - 11*Global`Nf^7 + 3*Global`Nf^9) + 
     Global`Nc*(32 - 64*Global`Nf - 56*Global`Nf^2 + 220*Global`Nf^3 + 
       60*Global`Nf^4 - 124*Global`Nf^5 - 6*Global`Nf^6 - 11*Global`Nf^7 - 
       9*Global`Nf^8 + 12*Global`Nf^9))/((-1 + Global`Nc)*Global`Nc*
     (1 + Global`Nc)*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*
     (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
      4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
       (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 
  ((1 + 2*Global`Nf)*(-4 + 3*Global`Nf^2 + 2*Global`Nc*Global`Nf^3))/
   (32*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  (32*(-1 + Global`Nf^2) - 3*Global`Nc^2*(-12 + 12*Global`Nf^2 + 
      Global`Nf^4))/(384*(-1 + Global`Nc)*Global`Nc^2*(1 + Global`Nc)*
    (-1 + Global`Nf)*(1 + Global`Nf)), 
  -1/16*(Global`Nf*(8 - 6*Global`Nf^2 + 8*Global`Nf^3 + 6*Global`Nf^4 - 
      2*Global`Nc^3*Global`Nf^4 + Global`Nc^2*(4 + 8*Global`Nf + 
        Global`Nf^2 - 11*Global`Nf^3 - 6*Global`Nf^4 + 4*Global`Nf^5) + 
      Global`Nc*(12 - 29*Global`Nf^2 - 15*Global`Nf^3 + 10*Global`Nf^4 + 
        4*Global`Nf^5)))/(Global`Nc^2*(1 + Global`Nf)*
     (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
      4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
       (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/768*(12*Global`Nc^5*Global`Nf^5*(-8 + 8*Global`Nf + 4*Global`Nf^2 - 
       4*Global`Nf^3 - Global`Nf^4 + Global`Nf^5) + 
     32*(8 - 2*Global`Nf - 10*Global`Nf^2 - 2*Global`Nf^3 - Global`Nf^4 + 
       4*Global`Nf^5 + 3*Global`Nf^6) + 8*Global`Nc*(16 - 68*Global`Nf - 
       16*Global`Nf^2 + 137*Global`Nf^3 - 101*Global`Nf^5 + 12*Global`Nf^6 + 
       20*Global`Nf^7) + Global`Nc^2*(-192 - 128*Global`Nf - 32*Global`Nf^2 + 
       500*Global`Nf^3 + 796*Global`Nf^4 - 444*Global`Nf^5 - 
       684*Global`Nf^6 + 111*Global`Nf^7 + 55*Global`Nf^8) + 
     12*Global`Nc^4*Global`Nf*(16 + 16*Global`Nf - 34*Global`Nf^2 - 
       52*Global`Nf^3 + 24*Global`Nf^4 + 46*Global`Nf^5 - 11*Global`Nf^6 - 
       9*Global`Nf^7 + Global`Nf^9) + Global`Nc^3*(-96 + 480*Global`Nf + 
       24*Global`Nf^2 - 996*Global`Nf^3 + 60*Global`Nf^4 + 916*Global`Nf^5 - 
       166*Global`Nf^6 - 235*Global`Nf^7 + 55*Global`Nf^8 + 12*Global`Nf^9))/
    ((-1 + Global`Nc)*Global`Nc^2*(1 + Global`Nc)*(-1 + Global`Nf)*
     (1 + Global`Nf)*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 
      3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 
      4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 3*Global`Nf^2 - 
        5*Global`Nf^3 + Global`Nf^5) + Global`Nc*(-8 + 16*Global`Nf + 
        18*Global`Nf^2 - 9*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nf^5))), 
  (32*(1 + Global`Nf)^2*(-16 + 24*Global`Nf - 11*Global`Nf^3 + 
      3*Global`Nf^4) + 12*Global`Nc^5*Global`Nf^5*(16 - 16*Global`Nf - 
      28*Global`Nf^2 + 28*Global`Nf^3 - Global`Nf^4 + Global`Nf^5) - 
    8*Global`Nc*(32 - 124*Global`Nf - 188*Global`Nf^2 + 253*Global`Nf^3 + 
      192*Global`Nf^4 - 181*Global`Nf^5 - 36*Global`Nf^6 + 52*Global`Nf^7) + 
    Global`Nc^2*(576 + 640*Global`Nf - 800*Global`Nf^2 - 1660*Global`Nf^3 - 
      1028*Global`Nf^4 + 948*Global`Nf^5 + 1716*Global`Nf^6 - 
      81*Global`Nf^7 - 329*Global`Nf^8) + 12*Global`Nc^4*Global`Nf*
     (-32 - 32*Global`Nf + 106*Global`Nf^2 + 148*Global`Nf^3 - 
      68*Global`Nf^4 - 154*Global`Nf^5 + 5*Global`Nf^6 + 23*Global`Nf^7 + 
      Global`Nf^9) + Global`Nc^3*(288 - 1056*Global`Nf - 1608*Global`Nf^2 + 
      2124*Global`Nf^3 + 1596*Global`Nf^4 - 1628*Global`Nf^5 - 
      70*Global`Nf^6 + 725*Global`Nf^7 - 329*Global`Nf^8 + 12*Global`Nf^9))/
   (768*(-1 + Global`Nc)*Global`Nc^2*(1 + Global`Nc)*(-1 + Global`Nf)*
    (1 + Global`Nf)*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 
     3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 
     4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 3*Global`Nf^2 - 
       5*Global`Nf^3 + Global`Nf^5) + Global`Nc*(-8 + 16*Global`Nf + 
       18*Global`Nf^2 - 9*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nf^5))), 
  (24*Global`Nc - 24*Global`Nc^3)^(-1), 
  -1/8*(Global`Nf*(4 - 3*Global`Nf^2 + 4*Global`Nf^3 + 3*Global`Nf^4 + 
      2*Global`Nc^2*Global`Nf^5 + Global`Nc*Global`Nf*
       (-4 - 8*Global`Nf - 3*Global`Nf^2 + 5*Global`Nf^3 + 2*Global`Nf^4)))/
    (Global`Nc*(1 + Global`Nf)*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 
      5*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*
       Global`Nf^5 + 4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 
        3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), (Global`Nf*(-2 + Global`Nf^2))/
   (64*(-1 + Global`Nc)*(1 + Global`Nc)*(-1 + Global`Nf)*(1 + Global`Nf))}, 
 {1/(12*(-1 + Global`Nc^2)*Global`Nf), 1/(12*(-1 + Global`Nc^2)*Global`Nf), 
  0, -(12*Global`Nc - 12*Global`Nc^3)^(-1), 0, 
  -(24*Global`Nc - 24*Global`Nc^3)^(-1), (24*Global`Nc - 24*Global`Nc^3)^
   (-1), 1/(3*(-1 + Global`Nc^2)), 0, 0}, 
 {-1/4*(Global`Nf*(2 + Global`Nf)*(-1 + Global`Nc*Global`Nf))/
    (Global`Nc*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 
      3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 
      4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 3*Global`Nf^2 - 
        5*Global`Nf^3 + Global`Nf^5) + Global`Nc*(-8 + 16*Global`Nf + 
        18*Global`Nf^2 - 9*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nf^5))), 
  (Global`Nf*(2 + Global`Nf)*(-1 + Global`Nc*Global`Nf))/
   (4*Global`Nc*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 
     3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 
     4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 3*Global`Nf^2 - 
       5*Global`Nf^3 + Global`Nf^5) + Global`Nc*(-8 + 16*Global`Nf + 
       18*Global`Nf^2 - 9*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/8*(4 - 3*Global`Nf^2 + 2*Global`Nc^2*Global`Nf^4 + 
     Global`Nc*Global`Nf*(-4 + Global`Nf^2))/((-2 + Global`Nc)*
     (-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf)*(-16 - 8*Global`Nf + 
      16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
      4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
       (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 0, 
  -1/12*(Global`Nf*(8 - 14*Global`Nf^2 - 6*Global`Nf^3 + 
      2*Global`Nc^3*Global`Nf^5 + Global`Nc*(4 + 8*Global`Nf + 
        5*Global`Nf^2 - 4*Global`Nf^3 - Global`Nf^4) + 
      Global`Nc^2*Global`Nf*(-4 - 8*Global`Nf + Global`Nf^2 + 5*Global`Nf^3 + 
        2*Global`Nf^4)))/(Global`Nc^2*(1 + Global`Nf)*
     (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
      4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
       (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 
  (Global`Nf*(8 - 14*Global`Nf^2 - 6*Global`Nf^3 + 
     2*Global`Nc^3*Global`Nf^5 + Global`Nc*(4 + 8*Global`Nf + 5*Global`Nf^2 - 
       4*Global`Nf^3 - Global`Nf^4) + Global`Nc^2*Global`Nf*
      (-4 - 8*Global`Nf + Global`Nf^2 + 5*Global`Nf^3 + 2*Global`Nf^4)))/
   (24*Global`Nc^2*(1 + Global`Nf)*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 
     5*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*
      Global`Nf^5 + 4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 
       3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 
  -1/8*(Global`Nf*(4 - 3*Global`Nf^2 + 4*Global`Nf^3 + 3*Global`Nf^4 + 
      2*Global`Nc^2*Global`Nf^5 + Global`Nc*Global`Nf*
       (-4 - 8*Global`Nf - 3*Global`Nf^2 + 5*Global`Nf^3 + 2*Global`Nf^4)))/
    (Global`Nc*(1 + Global`Nf)*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 
      5*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*
       Global`Nf^5 + 4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 
        3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
      Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
        3*Global`Nf^4 + 4*Global`Nf^5))), 0, 
  (Global`Nf*(4 - 7*Global`Nf^2 - 3*Global`Nf^3 + 2*Global`Nc^4*Global`Nf^6 - 
     Global`Nc*(4 - 7*Global`Nf^2 + Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc^3*Global`Nf^2*(-4 - 8*Global`Nf - 5*Global`Nf^2 + 
       3*Global`Nf^3 + 2*Global`Nf^4) + Global`Nc^2*Global`Nf*
      (8 + 4*Global`Nf - 2*Global`Nf^2 + 3*Global`Nf^3 + 3*Global`Nf^4)))/
   (6*(-1 + Global`Nc)*Global`Nc*(1 + Global`Nc)*(1 + Global`Nf)*
    (-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 3*Global`Nf^4 + 
     4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 4*Global`Nc^2*Global`Nf*
      (2 + 2*Global`Nf - 3*Global`Nf^2 - 5*Global`Nf^3 + Global`Nf^5) + 
     Global`Nc*(-8 + 16*Global`Nf + 18*Global`Nf^2 - 9*Global`Nf^3 - 
       3*Global`Nf^4 + 4*Global`Nf^5))), 0}, 
 {-1/32*(-2 + Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 
  -1/32*(-2 + Global`Nf^2)/(Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 
  0, -1/32*(Global`Nf*(-2 + Global`Nf^2))/((-1 + Global`Nc)*(1 + Global`Nc)*
     (-1 + Global`Nf)*(1 + Global`Nf)), 0, 
  -1/64*(Global`Nf*(-2 + Global`Nf^2))/((-1 + Global`Nc)*(1 + Global`Nc)*
     (-1 + Global`Nf)*(1 + Global`Nf)), (Global`Nf*(-2 + Global`Nf^2))/
   (64*(-1 + Global`Nc)*(1 + Global`Nc)*(-1 + Global`Nf)*(1 + Global`Nf)), 0, 
  0, Global`Nf^2/(16*(-1 + Global`Nc^2)*(-1 + Global`Nf^2))}}
