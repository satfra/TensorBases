(* Created with the Wolfram Language : www.wolfram.com *)
{(-4*(2 - Global`Nc)*Global`Nc*(1 - Global`Nc^2)*Global`Nf*(1 - Global`Nf^2)*
    (4 - 4*Global`Nf^2 - 3*Global`Nf^4)*(8*Global`Nc - 
     8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
     2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
     (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
     (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
     4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
     4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
   96*(-2 + Global`Nc)*(-1 + Global`Nc)^2*(1 + Global`Nc)*(-1 + Global`Nc^2)*
    (-1 + Global`Nf)*Global`Nf^3*(1 + Global`Nf)*(2 + Global`Nf)*
    (-1 + Global`Nf^2)*(-2 + Global`Nc*(-1 + 2*Global`Nf))*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBdeltaLorentz[Global`i$19077, 0]*TBgamma[0, Global`d1, Global`d2] - 
     TBgamma[Global`i$19077, Global`d1, Global`d2])*
    (TBdeltaLorentz[Global`i$19077, 0]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[Global`i$19077, Global`d3, Global`d4]) - 
   2*(2 - Global`Nc)*(1 - Global`Nc^2)*Global`Nf*(1 - Global`Nf^2)*
    (48*(-1 + Global`Nf)*Global`Nf^2*(1 + Global`Nf)*(2 + Global`Nf) + 
     4*Global`Nc^4*(-1 + Global`Nf)*Global`Nf^2*
      (12 + Global`Nf*(-6 + Global`Nf*(-30 - 16*Global`Nf + 4*Global`Nf^3 + 
           3*Global`Nf^5))) - Global`Nc*(1 + Global`Nf)*
      (-64 + Global`Nf*(32 + Global`Nf*(48 + Global`Nf*
            (-116 + Global`Nf*(88 + 3*Global`Nf*(12 + Global`Nf*
                  (-8 + 3*Global`Nf))))))) + 4*Global`Nc^3*Global`Nf*
      (-8 + Global`Nf*(-20 + Global`Nf*(-10 + Global`Nf*
            (28 + Global`Nf*(24 + Global`Nf*(-6 + Global`Nf*(-9 - 
                   11*Global`Nf + 3*Global`Nf^3))))))) + 
     Global`Nc^2*(32 + Global`Nf*(-64 + Global`Nf*
          (40 + Global`Nf*(76 + Global`Nf*(-132 + Global`Nf*(20 + 
                 Global`Nf*(90 + Global`Nf*(-11 + 3*Global`Nf*(-3 + 
                       4*Global`Nf))))))))))*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$19093, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$19093, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$19093, 0]*TBgamma[0, Global`d3, 
          Global`d4]) + TBgamma[Global`i$19093, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$19093, 0]*TBgamma[0, Global`d1, 
          Global`dc$19096]) + TBgamma[Global`i$19093, Global`d1, 
        Global`dc$19096])*(-(TBdeltaLorentz[Global`i$19093, 0]*
         TBgamma[0, Global`d3, Global`dc$19099]) + TBgamma[Global`i$19093, 
        Global`d3, Global`dc$19099])*TBgamma5[Global`dc$19096, Global`d2]*
      TBgamma5[Global`dc$19099, Global`d4]) + 2*(2 - Global`Nc)*Global`Nc*
    (1 - Global`Nc^2)*Global`Nf*(1 - Global`Nf^2)*
    (32*(2 + Global`Nf) + 4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^2*
      (-12 + Global`Nf*(-42 + Global`Nf*(-42 - 16*Global`Nf + 4*Global`Nf^3 + 
           3*Global`Nf^5))) + Global`Nf^2*
      (-80 + Global`Nf*(68 + Global`Nf*(28 - Global`Nf*
            (124 + 3*Global`Nf*(4 + Global`Nf*(-5 + 3*Global`Nf)))))) + 
     4*Global`Nc^2*Global`Nf*(-8 + Global`Nf*
        (-20 + Global`Nf*(-10 + Global`Nf*(28 + Global`Nf*(24 + Global`Nf*
                (-6 + Global`Nf*(-9 - 11*Global`Nf + 3*Global`Nf^3))))))) + 
     Global`Nc*(32 + Global`Nf*(-64 + Global`Nf*
          (-152 + Global`Nf*(-20 + Global`Nf*(60 + Global`Nf*(116 + 
                 Global`Nf*(90 + Global`Nf*(-11 + 3*Global`Nf*(-3 + 
                       4*Global`Nf))))))))))*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$19115]*TBgamma[0, Global`d3, 
       Global`dc$19118]*TBgamma5[Global`dc$19115, Global`d2]*
      TBgamma5[Global`dc$19118, Global`d4]) + 3*(1 - Global`Nc)*Global`Nc*
    (1 + Global`Nc)*(1 - Global`Nc^2)*(1 - Global`Nf)*Global`Nf^3*
    (1 + Global`Nf)*(2 + Global`Nf)*(1 - 2*Global`Nc*Global`Nf)*
    (1 - Global`Nf^2)*TBepsFund[Global`flavor, Global`F1, Global`F3]*
    TBepsFund[Global`flavor, Global`F2, Global`F4]*
    TBepsFund[Global`color, Global`a$127218, Global`A1, Global`A3]*
    TBepsFund[Global`color, Global`a$127218, Global`A2, Global`A4]*
    (8*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4] + 8*TBgamma[Global`vi1$19021, Global`d1, Global`d2]*
      TBgamma[Global`vi1$19021, Global`d3, Global`d4] + 
     (TBgamma[Global`vi2$19024, Global`dint2$19045, Global`d2]*
        TBgamma[Global`vi3$19027, Global`d1, Global`dint2$19045] - 
       TBgamma[Global`vi2$19024, Global`d1, Global`dint1$19039]*
        TBgamma[Global`vi3$19027, Global`dint1$19039, Global`d2])*
      (TBgamma[Global`vi2$19024, Global`dint2$19048, Global`d4]*
        TBgamma[Global`vi3$19027, Global`d3, Global`dint2$19048] - 
       TBgamma[Global`vi2$19024, Global`d3, Global`dint1$19042]*
        TBgamma[Global`vi3$19027, Global`dint1$19042, Global`d4]) + 
     8*(TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] + 
       TBgamma[Global`vi4$19030, Global`d1, Global`di1$19033]*
        TBgamma[Global`vi4$19030, Global`d3, Global`di2$19036]*
        TBgamma5[Global`di1$19033, Global`d2]*TBgamma5[Global`di2$19036, 
         Global`d4])) - 64*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc^2*
    (1 + Global`Nc)*(1 - Global`Nf)*Global`Nf*(1 + Global`Nf)*
    (1 - Global`Nf^2)*(8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
     2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
     (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
     (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
     4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
     4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$19134]*TBgamma[0, Global`d3, 
       Global`dc$19137]*TBgamma5[Global`dc$19134, Global`d2]*
      TBgamma5[Global`dc$19137, Global`d4])*TBT[Global`color, Global`a$19140, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$19140, Global`A3, 
     Global`A4] - 192*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc*
    (1 + Global`Nc)*(1 - Global`Nc^2)*(1 - Global`Nf)*Global`Nf^3*
    (1 + Global`Nf)*(2 + Global`Nf)*(1 - Global`Nc*Global`Nf)*
    (1 - Global`Nf^2)*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$19156, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$19156, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$19156, 0]*TBgamma[0, Global`d3, 
          Global`d4]) + TBgamma[Global`i$19156, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$19156, 0]*TBgamma[0, Global`d1, 
          Global`dc$19159]) + TBgamma[Global`i$19156, Global`d1, 
        Global`dc$19159])*(-(TBdeltaLorentz[Global`i$19156, 0]*
         TBgamma[0, Global`d3, Global`dc$19162]) + TBgamma[Global`i$19156, 
        Global`d3, Global`dc$19162])*TBgamma5[Global`dc$19159, Global`d2]*
      TBgamma5[Global`dc$19162, Global`d4])*TBT[Global`color, Global`a$19165, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$19165, Global`A3, 
     Global`A4] - 4*(2 - Global`Nc)*(1 - Global`Nc^2)*(1 - Global`Nf^2)*
    (112*Global`Nc^5*(-1 + Global`Nf)^2*Global`Nf^5*(1 + Global`Nf) - 
     3*(1 + Global`Nf)*(-2 + Global`Nf^2)^2*
      (16 + Global`Nf*(-8 + Global`Nf*(-8 + 3*Global`Nf))) + 
     8*Global`Nc^4*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*
      (16 + Global`Nf*(16 + Global`Nf*(-21 + Global`Nf*
            (-58 + Global`Nf*(-9 + 14*Global`Nf))))) + 
     3*Global`Nc*(-32 + Global`Nf*(64 + Global`Nf*
          (104 + Global`Nf*(-60 + Global`Nf*(-76 + Global`Nf*
                (20 + (-2 + Global`Nf)*Global`Nf*(-7 + Global`Nf*
                    (5 + 4*Global`Nf)))))))) + 4*Global`Nc^3*(-1 + Global`Nf)*
      (-32 + Global`Nf*(32 + Global`Nf*(136 + Global`Nf*
            (66 + Global`Nf*(-6 + Global`Nf*(34 + Global`Nf*(10 + 3*Global`Nf*
                    (-8 + Global`Nf^2)))))))) + 
     4*Global`Nc^2*(64 + Global`Nf*(56 + Global`Nf*
          (-104 + Global`Nf*(-106 + Global`Nf*(-44 + Global`Nf*
                (38 + 3*Global`Nf*(38 + Global`Nf*(3 - 13*Global`Nf + 
                     Global`Nf^3)))))))))*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$18989, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$18989, Global`F3, Global`F4]) + 
   4*(2 - Global`Nc)*(1 - Global`Nc^2)*(1 - Global`Nf^2)*
    (16*Global`Nc^5*(-1 + Global`Nf)^2*Global`Nf^5*(1 + Global`Nf) - 
     3*(1 + Global`Nf)*(-2 + Global`Nf^2)^2*
      (16 + Global`Nf*(-8 + Global`Nf*(-8 + 3*Global`Nf))) + 
     8*Global`Nc^4*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*
      (16 + Global`Nf*(16 + Global`Nf*(-27 + Global`Nf*
            (-22 + Global`Nf*(9 + 2*Global`Nf))))) + 
     4*Global`Nc^3*(-1 + Global`Nf)*
      (-32 + Global`Nf*(32 + Global`Nf*(136 + Global`Nf*
            (6 + Global`Nf*(-90 + Global`Nf*(-2 + 22*Global`Nf + 
                 3*Global`Nf^4)))))) + 3*Global`Nc*
      (-32 + Global`Nf*(64 + Global`Nf*(104 + Global`Nf*
            (-140 + Global`Nf*(-108 + Global`Nf*(116 + (-2 + Global`Nf)*
                  Global`Nf*(-23 + Global`Nf*(5 + 4*Global`Nf)))))))) + 
     4*Global`Nc^2*(64 + Global`Nf*(56 + Global`Nf*
          (-104 + Global`Nf*(-118 + Global`Nf*(28 + Global`Nf*
                (86 + 3*Global`Nf*(6 + Global`Nf*(-9 - 5*Global`Nf + 
                     Global`Nf^3)))))))))*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] - 
     2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$19005, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$19005, Global`F3, Global`F4]) + 
   24*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc*(1 + Global`Nc)*
    (1 - Global`Nf)*Global`Nf^2*(1 + Global`Nf)*(2 - Global`Nf^2)*
    (8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
     2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
     (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
     (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
     4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
     4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    TBT[Global`color, Global`a$19181, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$19181, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$19184, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$19184, Global`F3, Global`F4]))/
  (1536*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc^2*(1 + Global`Nc)*
   (1 - Global`Nc^2)*(1 - Global`Nf)*Global`Nf^3*(1 + Global`Nf)*
   (1 - Global`Nf^2)*(8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
    2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
    (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
    (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
    4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
    4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))), 
 (-4*(2 - Global`Nc)*Global`Nc*(1 - Global`Nc^2)*Global`Nf*(1 - Global`Nf^2)*
    (4 - 4*Global`Nf^2 - 3*Global`Nf^4)*(8*Global`Nc - 
     8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
     2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
     (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
     (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
     4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
     4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
   96*(-2 + Global`Nc)*(-1 + Global`Nc)^2*(1 + Global`Nc)*(-1 + Global`Nc^2)*
    (-1 + Global`Nf)*Global`Nf^3*(1 + Global`Nf)*(2 + Global`Nf)*
    (-1 + Global`Nf^2)*(-2 + Global`Nc*(-1 + 2*Global`Nf))*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBdeltaLorentz[Global`i$11759, 0]*TBgamma[0, Global`d1, Global`d2] - 
     TBgamma[Global`i$11759, Global`d1, Global`d2])*
    (TBdeltaLorentz[Global`i$11759, 0]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[Global`i$11759, Global`d3, Global`d4]) + 
   2*(2 - Global`Nc)*(1 - Global`Nc^2)*Global`Nf*(1 - Global`Nf^2)*
    (48*(-1 + Global`Nf)*Global`Nf^2*(1 + Global`Nf)*(2 + Global`Nf) - 
     4*Global`Nc^4*(-1 + Global`Nf)*Global`Nf^2*
      (-12 + Global`Nf*(6 + Global`Nf*(30 + 8*Global`Nf + 4*Global`Nf^3 + 
           3*Global`Nf^5))) + Global`Nc*(1 + Global`Nf)*
      (-64 + Global`Nf*(32 + Global`Nf*(144 + Global`Nf*
            (28 + Global`Nf*(-56 + 3*Global`Nf*(-20 + Global`Nf*
                  (-8 + 3*Global`Nf))))))) - 4*Global`Nc^3*Global`Nf*
      (-8 + Global`Nf*(4 + Global`Nf*(50 + Global`Nf*
            (28 + Global`Nf*(-36 + Global`Nf*(-30 + Global`Nf*(-9 - 
                   11*Global`Nf + 3*Global`Nf^3))))))) + 
     Global`Nc^2*(-32 + Global`Nf*(64 + Global`Nf*
          (248 + Global`Nf*(-124 + Global`Nf*(-252 + Global`Nf*
                (28 + Global`Nf*(6 + Global`Nf*(11 + 3*(3 - 4*Global`Nf)*
                      Global`Nf)))))))))*TBdeltaFund[Global`color, Global`A1, 
     Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$11775, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$11775, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$11775, 0]*TBgamma[0, Global`d3, 
          Global`d4]) + TBgamma[Global`i$11775, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$11775, 0]*TBgamma[0, Global`d1, 
          Global`dc$11778]) + TBgamma[Global`i$11775, Global`d1, 
        Global`dc$11778])*(-(TBdeltaLorentz[Global`i$11775, 0]*
         TBgamma[0, Global`d3, Global`dc$11781]) + TBgamma[Global`i$11775, 
        Global`d3, Global`dc$11781])*TBgamma5[Global`dc$11778, Global`d2]*
      TBgamma5[Global`dc$11781, Global`d4]) + 2*(2 - Global`Nc)*Global`Nc*
    (1 - Global`Nc^2)*Global`Nf*(1 - Global`Nf^2)*
    (32*(2 + Global`Nf) + 4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^2*
      (12 + Global`Nf*(42 + Global`Nf*(42 + 8*Global`Nf + 4*Global`Nf^3 + 
           3*Global`Nf^5))) + Global`Nf^2*
      (-176 + Global`Nf*(-172 + Global`Nf*(28 + Global`Nf*
            (116 - 3*(-4 + Global`Nf)*Global`Nf*(7 + 3*Global`Nf))))) + 
     4*Global`Nc^2*Global`Nf*(-8 + Global`Nf*
        (4 + Global`Nf*(50 + Global`Nf*(28 + Global`Nf*(-36 + Global`Nf*
                (-30 + Global`Nf*(-9 - 11*Global`Nf + 3*Global`Nf^3))))))) + 
     Global`Nc*(32 + Global`Nf*(-64 + Global`Nf*
          (-56 + Global`Nf*(220 + Global`Nf*(60 + Global`Nf*(-124 + 
                 Global`Nf*(-6 + Global`Nf*(-11 + 3*Global`Nf*(-3 + 
                       4*Global`Nf))))))))))*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$11797]*TBgamma[0, Global`d3, 
       Global`dc$11800]*TBgamma5[Global`dc$11797, Global`d2]*
      TBgamma5[Global`dc$11800, Global`d4]) - 3*(1 - Global`Nc)*Global`Nc*
    (1 + Global`Nc)*(1 - Global`Nc^2)*(1 - Global`Nf)*Global`Nf^3*
    (1 + Global`Nf)*(2 + Global`Nf)*(1 - 2*Global`Nc*Global`Nf)*
    (1 - Global`Nf^2)*TBepsFund[Global`flavor, Global`F1, Global`F3]*
    TBepsFund[Global`flavor, Global`F2, Global`F4]*
    TBepsFund[Global`color, Global`a$127218, Global`A1, Global`A3]*
    TBepsFund[Global`color, Global`a$127218, Global`A2, Global`A4]*
    (8*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4] + 8*TBgamma[Global`vi1$11703, Global`d1, Global`d2]*
      TBgamma[Global`vi1$11703, Global`d3, Global`d4] + 
     (TBgamma[Global`vi2$11706, Global`dint2$11727, Global`d2]*
        TBgamma[Global`vi3$11709, Global`d1, Global`dint2$11727] - 
       TBgamma[Global`vi2$11706, Global`d1, Global`dint1$11721]*
        TBgamma[Global`vi3$11709, Global`dint1$11721, Global`d2])*
      (TBgamma[Global`vi2$11706, Global`dint2$11730, Global`d4]*
        TBgamma[Global`vi3$11709, Global`d3, Global`dint2$11730] - 
       TBgamma[Global`vi2$11706, Global`d3, Global`dint1$11724]*
        TBgamma[Global`vi3$11709, Global`dint1$11724, Global`d4]) + 
     8*(TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] + 
       TBgamma[Global`vi4$11712, Global`d1, Global`di1$11715]*
        TBgamma[Global`vi4$11712, Global`d3, Global`di2$11718]*
        TBgamma5[Global`di1$11715, Global`d2]*TBgamma5[Global`di2$11718, 
         Global`d4])) - 64*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc^2*
    (1 + Global`Nc)*(1 - Global`Nf)*Global`Nf*(1 + Global`Nf)*
    (1 - Global`Nf^2)*(8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
     2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
     (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
     (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
     4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
     4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
    TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$11816]*TBgamma[0, Global`d3, 
       Global`dc$11819]*TBgamma5[Global`dc$11816, Global`d2]*
      TBgamma5[Global`dc$11819, Global`d4])*TBT[Global`color, Global`a$11822, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$11822, Global`A3, 
     Global`A4] + 192*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc*
    (1 + Global`Nc)*(1 - Global`Nc^2)*(1 - Global`Nf)*Global`Nf^3*
    (1 + Global`Nf)*(2 + Global`Nf)*(1 - Global`Nc*Global`Nf)*
    (1 - Global`Nf^2)*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$11838, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$11838, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$11838, 0]*TBgamma[0, Global`d3, 
          Global`d4]) + TBgamma[Global`i$11838, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$11838, 0]*TBgamma[0, Global`d1, 
          Global`dc$11841]) + TBgamma[Global`i$11838, Global`d1, 
        Global`dc$11841])*(-(TBdeltaLorentz[Global`i$11838, 0]*
         TBgamma[0, Global`d3, Global`dc$11844]) + TBgamma[Global`i$11838, 
        Global`d3, Global`dc$11844])*TBgamma5[Global`dc$11841, Global`d2]*
      TBgamma5[Global`dc$11844, Global`d4])*TBT[Global`color, Global`a$11847, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$11847, Global`A3, 
     Global`A4] - 4*(2 - Global`Nc)*(1 - Global`Nc^2)*(1 - Global`Nf^2)*
    (16*Global`Nc^5*(-1 + Global`Nf)^2*Global`Nf^5*(1 + Global`Nf) - 
     3*(1 + Global`Nf)*(-2 + Global`Nf^2)^2*
      (16 + Global`Nf*(-8 + Global`Nf*(-8 + 3*Global`Nf))) + 
     8*Global`Nc^4*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*
      (16 + Global`Nf*(16 + Global`Nf*(-27 + Global`Nf*
            (-22 + Global`Nf*(9 + 2*Global`Nf))))) + 
     4*Global`Nc^3*(-1 + Global`Nf)*
      (-32 + Global`Nf*(32 + Global`Nf*(136 + Global`Nf*
            (6 + Global`Nf*(-90 + Global`Nf*(-2 + 22*Global`Nf + 
                 3*Global`Nf^4)))))) + 3*Global`Nc*
      (-32 + Global`Nf*(64 + Global`Nf*(104 + Global`Nf*
            (-140 + Global`Nf*(-108 + Global`Nf*(116 + (-2 + Global`Nf)*
                  Global`Nf*(-23 + Global`Nf*(5 + 4*Global`Nf)))))))) + 
     4*Global`Nc^2*(64 + Global`Nf*(56 + Global`Nf*
          (-104 + Global`Nf*(-118 + Global`Nf*(28 + Global`Nf*
                (86 + 3*Global`Nf*(6 + Global`Nf*(-9 - 5*Global`Nf + 
                     Global`Nf^3)))))))))*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$11671, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$11671, Global`F3, Global`F4]) + 
   4*(2 - Global`Nc)*(1 - Global`Nc^2)*(1 - Global`Nf^2)*
    (112*Global`Nc^5*(-1 + Global`Nf)^2*Global`Nf^5*(1 + Global`Nf) - 
     3*(1 + Global`Nf)*(-2 + Global`Nf^2)^2*
      (16 + Global`Nf*(-8 + Global`Nf*(-8 + 3*Global`Nf))) + 
     8*Global`Nc^4*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*
      (16 + Global`Nf*(16 + Global`Nf*(-21 + Global`Nf*
            (-58 + Global`Nf*(-9 + 14*Global`Nf))))) + 
     3*Global`Nc*(-32 + Global`Nf*(64 + Global`Nf*
          (104 + Global`Nf*(-60 + Global`Nf*(-76 + Global`Nf*
                (20 + (-2 + Global`Nf)*Global`Nf*(-7 + Global`Nf*
                    (5 + 4*Global`Nf)))))))) + 4*Global`Nc^3*(-1 + Global`Nf)*
      (-32 + Global`Nf*(32 + Global`Nf*(136 + Global`Nf*
            (66 + Global`Nf*(-6 + Global`Nf*(34 + Global`Nf*(10 + 3*Global`Nf*
                    (-8 + Global`Nf^2)))))))) + 
     4*Global`Nc^2*(64 + Global`Nf*(56 + Global`Nf*
          (-104 + Global`Nf*(-106 + Global`Nf*(-44 + Global`Nf*
                (38 + 3*Global`Nf*(38 + Global`Nf*(3 - 13*Global`Nf + 
                     Global`Nf^3)))))))))*TBdeltaFund[Global`color, 
     Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] - 
     2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$11687, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$11687, Global`F3, Global`F4]) + 
   24*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc*(1 + Global`Nc)*
    (1 - Global`Nf)*Global`Nf^2*(1 + Global`Nf)*(2 - Global`Nf^2)*
    (8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
     2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
     (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
     (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
     4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
     4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
    (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
     TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
    TBT[Global`color, Global`a$11863, Global`A1, Global`A2]*
    TBT[Global`color, Global`a$11863, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
     2*Global`Nf*TBT[Global`flavor, Global`f$11866, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$11866, Global`F3, Global`F4]))/
  (1536*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc^2*(1 + Global`Nc)*
   (1 - Global`Nc^2)*(1 - Global`Nf)*Global`Nf^3*(1 + Global`Nf)*
   (1 - Global`Nf^2)*(8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
    2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
    (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
    (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
    4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
    4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))), 
 -1/1024*((-32*(-2 + Global`Nc)*(-2 + Global`Nc*(-1 + 2*Global`Nf))*
      (-4 + Global`Nf^2*(3 + 2*Global`Nc*Global`Nf))*
      TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (TBdeltaLorentz[Global`i$42273, 0]*TBgamma[0, Global`d1, Global`d2] - 
       TBgamma[Global`i$42273, Global`d1, Global`d2])*
      (TBdeltaLorentz[Global`i$42273, 0]*TBgamma[0, Global`d3, Global`d4] - 
       TBgamma[Global`i$42273, Global`d3, Global`d4]))/(-1 + Global`Nf) + 
    (16*(-2 + Global`Nc)*(-2 + Global`Nc*(-1 + 2*Global`Nf))*
      (-4 + Global`Nf^2*(3 + 2*Global`Nc*Global`Nf))*
      TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      ((TBdeltaLorentz[Global`i$42289, 0]*TBgamma[0, Global`d1, Global`d2] - 
         TBgamma[Global`i$42289, Global`d1, Global`d2])*
        (TBdeltaLorentz[Global`i$42289, 0]*TBgamma[0, Global`d3, Global`d4] - 
         TBgamma[Global`i$42289, Global`d3, Global`d4]) - 
       (TBdeltaLorentz[Global`i$42289, 0]*TBgamma[0, Global`d1, 
           Global`dc$42292] - TBgamma[Global`i$42289, Global`d1, 
          Global`dc$42292])*(TBdeltaLorentz[Global`i$42289, 0]*
          TBgamma[0, Global`d3, Global`dc$42295] - TBgamma[Global`i$42289, 
          Global`d3, Global`dc$42295])*TBgamma5[Global`dc$42292, Global`d2]*
        TBgamma5[Global`dc$42295, Global`d4]))/(-1 + Global`Nf) - 
    (16*(-2 + Global`Nc)*Global`Nc*(1 + 2*Global`Nf)*
      (-4 + Global`Nf^2*(3 + 2*Global`Nc*Global`Nf))*
      TBdeltaFund[Global`color, Global`A1, Global`A2]*
      TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$42311]*TBgamma[0, Global`d3, 
         Global`dc$42314]*TBgamma5[Global`dc$42311, Global`d2]*
        TBgamma5[Global`dc$42314, Global`d4]))/(-1 + Global`Nf) + 
    (Global`Nc*(-1 + 2*Global`Nc*Global`Nf)*
      (-4 + Global`Nf^2*(3 + 2*Global`Nc*Global`Nf))*TBepsFund[Global`flavor, 
       Global`F1, Global`F3]*TBepsFund[Global`flavor, Global`F2, Global`F4]*
      TBepsFund[Global`color, Global`a$127218, Global`A1, Global`A3]*
      TBepsFund[Global`color, Global`a$127218, Global`A2, Global`A4]*
      (8*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
         Global`d4] + 8*TBgamma[Global`vi1$42217, Global`d1, Global`d2]*
        TBgamma[Global`vi1$42217, Global`d3, Global`d4] + 
       (TBgamma[Global`vi2$42220, Global`dint2$42241, Global`d2]*
          TBgamma[Global`vi3$42223, Global`d1, Global`dint2$42241] - 
         TBgamma[Global`vi2$42220, Global`d1, Global`dint1$42235]*
          TBgamma[Global`vi3$42223, Global`dint1$42235, Global`d2])*
        (TBgamma[Global`vi2$42220, Global`dint2$42244, Global`d4]*
          TBgamma[Global`vi3$42223, Global`d3, Global`dint2$42244] - 
         TBgamma[Global`vi2$42220, Global`d3, Global`dint1$42238]*
          TBgamma[Global`vi3$42223, Global`dint1$42238, Global`d4]) + 
       8*(TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] + 
         TBgamma[Global`vi4$42226, Global`d1, Global`di1$42229]*
          TBgamma[Global`vi4$42226, Global`d3, Global`di2$42232]*
          TBgamma5[Global`di1$42229, Global`d2]*TBgamma5[Global`di2$42232, 
           Global`d4])))/((-1 + Global`Nc)*(-1 + Global`Nf)) + 
    (64*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nc*Global`Nf)*
      (-4 + Global`Nf^2*(3 + 2*Global`Nc*Global`Nf))*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      ((TBdeltaLorentz[Global`i$42352, 0]*TBgamma[0, Global`d1, Global`d2] - 
         TBgamma[Global`i$42352, Global`d1, Global`d2])*
        (TBdeltaLorentz[Global`i$42352, 0]*TBgamma[0, Global`d3, Global`d4] - 
         TBgamma[Global`i$42352, Global`d3, Global`d4]) + 
       (TBdeltaLorentz[Global`i$42352, 0]*TBgamma[0, Global`d1, 
           Global`dc$42355] - TBgamma[Global`i$42352, Global`d1, 
          Global`dc$42355])*(TBdeltaLorentz[Global`i$42352, 0]*
          TBgamma[0, Global`d3, Global`dc$42358] - TBgamma[Global`i$42352, 
          Global`d3, Global`dc$42358])*TBgamma5[Global`dc$42355, Global`d2]*
        TBgamma5[Global`dc$42358, Global`d4])*TBT[Global`color, 
       Global`a$42361, Global`A1, Global`A2]*TBT[Global`color, 
       Global`a$42361, Global`A3, Global`A4])/((-1 + Global`Nc)*
      (-1 + Global`Nf)) + 32*(-2 + Global`Nc)*Global`Nc*(2 + Global`Nf)*
     (-1 + 2*Global`Nc*Global`Nf)*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (-(TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
        TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]) + 
      2*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$42185, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$42185, Global`F3, Global`F4]) + 
    32*(-2 + Global`Nc)*Global`Nc*(2 + Global`Nf)*
     (-1 + 2*Global`Nc*Global`Nf)*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
        TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
      2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$42201, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$42201, Global`F3, Global`F4]))/
   ((-2 + Global`Nc)^2*Global`Nc^2*Global`Nf*
    (4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 - 8*(2 + Global`Nf) + 
     Global`Nf^2*(16 + (5 - 3*Global`Nf)*Global`Nf) + 
     4*Global`Nc^2*Global`Nf*(2 + Global`Nf*
        (2 + Global`Nf*(-3 - 5*Global`Nf + Global`Nf^3))) + 
     Global`Nc*(-8 + Global`Nf*(16 + Global`Nf*
          (18 + Global`Nf*(-9 + Global`Nf*(-3 + 4*Global`Nf))))))), 
 -1/768*(2*Global`Nf*(32*(-1 + Global`Nf^2) - 3*Global`Nc^2*
       (-12 + 12*Global`Nf^2 + Global`Nf^4))*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
    Global`Nf*(3*Global`Nc^2*(-2 + Global`Nf^2)^2 + 16*(-1 + Global`Nf^2))*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$50250, 0]*TBgamma[0, Global`d1, 
           Global`d2]) + TBgamma[Global`i$50250, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$50250, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$50250, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$50250, 0]*TBgamma[0, Global`d1, 
           Global`dc$50253]) + TBgamma[Global`i$50250, Global`d1, 
         Global`dc$50253])*(-(TBdeltaLorentz[Global`i$50250, 0]*
          TBgamma[0, Global`d3, Global`dc$50256]) + TBgamma[Global`i$50250, 
         Global`d3, Global`dc$50256])*TBgamma5[Global`dc$50253, Global`d2]*
       TBgamma5[Global`dc$50256, Global`d4]) - 
    Global`Nf*(32*(-1 + Global`Nf^2) - 3*Global`Nc^2*(-12 + 12*Global`Nf^2 + 
        Global`Nf^4))*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$50272]*TBgamma[0, Global`d3, 
        Global`dc$50275]*TBgamma5[Global`dc$50272, Global`d2]*
       TBgamma5[Global`dc$50275, Global`d4]) - 32*Global`Nc*Global`Nf*
     (-1 + Global`Nf^2)*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$50291]*TBgamma[0, Global`d3, 
        Global`dc$50294]*TBgamma5[Global`dc$50291, Global`d2]*
       TBgamma5[Global`dc$50294, Global`d4])*TBT[Global`color, 
      Global`a$50297, Global`A1, Global`A2]*TBT[Global`color, Global`a$50297, 
      Global`A3, Global`A4] + 2*Global`Nc*(-4 + 4*Global`Nf^2 + 
      3*Global`Nf^4)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (-(TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
        TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]) + 
      2*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$50146, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$50146, Global`F3, Global`F4]) + 
    2*Global`Nc*(-4 + 4*Global`Nf^2 + 3*Global`Nf^4)*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] - 
      2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$50162, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$50162, Global`F3, Global`F4]) - 
    12*Global`Nc^2*Global`Nf^2*(-2 + Global`Nf^2)*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$50338, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$50338, Global`A3, Global`A4]*
     (-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]) + 
      2*Global`Nf*TBT[Global`flavor, Global`f$50341, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$50341, Global`F3, Global`F4]))/
   (Global`Nc^2*(-1 + Global`Nc^2)*Global`Nf^2*(-1 + Global`Nf^2)), 
 -1/1536*((-32*(4*(2 + Global`Nc)*(-2 + 3*(-1 + Global`Nc)*Global`Nc) + 
       8*Global`Nc*(-4 + 3*Global`Nc*(2 + Global`Nc))*Global`Nf + 
       (28 + Global`Nc*(8 + (27 - 13*Global`Nc)*Global`Nc))*Global`Nf^2 + 
       (12 + Global`Nc*(12 - Global`Nc*(21 + 53*Global`Nc)))*Global`Nf^3 - 
       2*Global`Nc*(2 + Global`Nc*(4 + Global`Nc)*(1 + 3*Global`Nc))*
        Global`Nf^4 + 4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^5 + 
       8*Global`Nc^3*(1 + Global`Nc)*Global`Nf^6)*TBdeltaFund[Global`color, 
       Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (TBdeltaLorentz[Global`i$8528, 0]*TBgamma[0, Global`d1, Global`d2] - 
       TBgamma[Global`i$8528, Global`d1, Global`d2])*
      (TBdeltaLorentz[Global`i$8528, 0]*TBgamma[0, Global`d3, Global`d4] - 
       TBgamma[Global`i$8528, Global`d3, Global`d4]))/(1 + Global`Nf) + 
    (16*(4*(2 + Global`Nc)*(-2 + 3*(-1 + Global`Nc)*Global`Nc) + 
       8*Global`Nc*(-4 + 3*Global`Nc*(2 + Global`Nc))*Global`Nf + 
       (28 + Global`Nc*(8 + (27 - 13*Global`Nc)*Global`Nc))*Global`Nf^2 + 
       (12 + Global`Nc*(12 - Global`Nc*(21 + 53*Global`Nc)))*Global`Nf^3 - 
       2*Global`Nc*(2 + Global`Nc*(4 + Global`Nc)*(1 + 3*Global`Nc))*
        Global`Nf^4 + 4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^5 + 
       8*Global`Nc^3*(1 + Global`Nc)*Global`Nf^6)*TBdeltaFund[Global`color, 
       Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      ((TBdeltaLorentz[Global`i$8544, 0]*TBgamma[0, Global`d1, Global`d2] - 
         TBgamma[Global`i$8544, Global`d1, Global`d2])*
        (TBdeltaLorentz[Global`i$8544, 0]*TBgamma[0, Global`d3, Global`d4] - 
         TBgamma[Global`i$8544, Global`d3, Global`d4]) - 
       (TBdeltaLorentz[Global`i$8544, 0]*TBgamma[0, Global`d1, 
           Global`dc$8547] - TBgamma[Global`i$8544, Global`d1, 
          Global`dc$8547])*(TBdeltaLorentz[Global`i$8544, 0]*
          TBgamma[0, Global`d3, Global`dc$8550] - TBgamma[Global`i$8544, 
          Global`d3, Global`dc$8550])*TBgamma5[Global`dc$8547, Global`d2]*
        TBgamma5[Global`dc$8550, Global`d4]))/(1 + Global`Nf) - 
    (48*Global`Nc*(-4*(1 + Global`Nc)*(2 + Global`Nc) - 
       8*Global`Nc^2*Global`Nf + (6 - (-29 + Global`Nc)*Global`Nc)*
        Global`Nf^2 + (-8 + Global`Nc*(15 + 11*Global`Nc))*Global`Nf^3 + 
       2*(-3 + Global`Nc*(-5 + Global`Nc*(3 + Global`Nc)))*Global`Nf^4 - 
       4*Global`Nc*(1 + Global`Nc)*Global`Nf^5)*TBdeltaFund[Global`color, 
       Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
      TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
       TBgamma[0, Global`d1, Global`dc$8566]*TBgamma[0, Global`d3, 
         Global`dc$8569]*TBgamma5[Global`dc$8566, Global`d2]*
        TBgamma5[Global`dc$8569, Global`d4]))/(1 + Global`Nf) + 
    (3*Global`Nc*(-2 + Global`Nc*(-1 + 2*Global`Nf))*
      (-4 + Global`Nf^2*(3 + 2*Global`Nc*Global`Nf))*TBepsFund[Global`flavor, 
       Global`F1, Global`F3]*TBepsFund[Global`flavor, Global`F2, Global`F4]*
      TBepsFund[Global`color, Global`a$127218, Global`A1, Global`A3]*
      TBepsFund[Global`color, Global`a$127218, Global`A2, Global`A4]*
      (8*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
         Global`d4] + 8*TBgamma[Global`vi1$8472, Global`d1, Global`d2]*
        TBgamma[Global`vi1$8472, Global`d3, Global`d4] + 
       (TBgamma[Global`vi2$8475, Global`dint2$8496, Global`d2]*
          TBgamma[Global`vi3$8478, Global`d1, Global`dint2$8496] - 
         TBgamma[Global`vi2$8475, Global`d1, Global`dint1$8490]*
          TBgamma[Global`vi3$8478, Global`dint1$8490, Global`d2])*
        (TBgamma[Global`vi2$8475, Global`dint2$8499, Global`d4]*
          TBgamma[Global`vi3$8478, Global`d3, Global`dint2$8499] - 
         TBgamma[Global`vi2$8475, Global`d3, Global`dint1$8493]*
          TBgamma[Global`vi3$8478, Global`dint1$8493, Global`d4]) + 
       8*(TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] + 
         TBgamma[Global`vi4$8481, Global`d1, Global`di1$8484]*
          TBgamma[Global`vi4$8481, Global`d3, Global`di2$8487]*
          TBgamma5[Global`di1$8484, Global`d2]*TBgamma5[Global`di2$8487, 
           Global`d4])))/((-2 + Global`Nc)*(-1 + Global`Nf)) + 
    (64*Global`Nc*(8 + 2*Global`Nc^3*Global`Nf^5 - 
       2*Global`Nf^2*(7 + 3*Global`Nf) + Global`Nc^2*Global`Nf*
        (-4 + Global`Nf*(-8 + Global`Nf + 5*Global`Nf^2 + 2*Global`Nf^3)) + 
       Global`Nc*(4 - Global`Nf*(1 + Global`Nf)*
          (-8 + Global`Nf*(3 + Global`Nf))))*TBdeltaFund[Global`flavor, 
       Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      ((TBdeltaLorentz[Global`i$8607, 0]*TBgamma[0, Global`d1, Global`d2] - 
         TBgamma[Global`i$8607, Global`d1, Global`d2])*
        (TBdeltaLorentz[Global`i$8607, 0]*TBgamma[0, Global`d3, Global`d4] - 
         TBgamma[Global`i$8607, Global`d3, Global`d4]) + 
       (TBdeltaLorentz[Global`i$8607, 0]*TBgamma[0, Global`d1, 
           Global`dc$8610] - TBgamma[Global`i$8607, Global`d1, 
          Global`dc$8610])*(TBdeltaLorentz[Global`i$8607, 0]*
          TBgamma[0, Global`d3, Global`dc$8613] - TBgamma[Global`i$8607, 
          Global`d3, Global`dc$8613])*TBgamma5[Global`dc$8610, Global`d2]*
        TBgamma5[Global`dc$8613, Global`d4])*TBT[Global`color, Global`a$8616, 
       Global`A1, Global`A2]*TBT[Global`color, Global`a$8616, Global`A3, 
       Global`A4])/(1 + Global`Nf) + 96*(-1 + Global`Nc)*Global`Nc*
     (2 + Global`Nf)*(-2 + Global`Nc*(-1 + 2*Global`Nf))*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (-(TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
        TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]) + 
      2*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$8440, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$8440, Global`F3, Global`F4]) + 
    96*(-1 + Global`Nc)*Global`Nc*(2 + Global`Nf)*
     (-2 + Global`Nc*(-1 + 2*Global`Nf))*TBdeltaFund[Global`color, Global`A1, 
      Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
        TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
        TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
      2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$8456, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$8456, Global`F3, Global`F4]))/
   (Global`Nc^3*(4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 - 
     8*(2 + Global`Nf) + Global`Nf^2*(16 + (5 - 3*Global`Nf)*Global`Nf) + 
     4*Global`Nc^2*Global`Nf*(2 + Global`Nf*
        (2 + Global`Nf*(-3 - 5*Global`Nf + Global`Nf^3))) + 
     Global`Nc*(-8 + Global`Nf*(16 + Global`Nf*
          (18 + Global`Nf*(-9 + Global`Nf*(-3 + 4*Global`Nf))))))), 
 -1/3072*(-4*(2 - Global`Nc)*Global`Nc*(-1 + Global`Nc^2)*Global`Nf*
     (8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
      2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
      (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
      (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
      4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
      4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
     (3*Global`Nc^2*(-2 + Global`Nf^2)^2 + 16*(-1 + Global`Nf^2))*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
    32*(1 - Global`Nc)*(2 - Global`Nc)*(1 + Global`Nc)*(-1 + Global`Nc^2)*
     (1 - Global`Nf)*Global`Nf^2*(-16 + 4*Global`Nc*
       (-8 + 3*Global`Nc*(1 + Global`Nc)) + 8*Global`Nc*
       (-4 + 3*Global`Nc*(2 + Global`Nc))*Global`Nf + 
      (28 + Global`Nc*(8 + (27 - 13*Global`Nc)*Global`Nc))*Global`Nf^2 + 
      (12 + Global`Nc*(12 - Global`Nc*(21 + 53*Global`Nc)))*Global`Nf^3 - 
      2*Global`Nc*(2 + Global`Nc*(4 + Global`Nc)*(1 + 3*Global`Nc))*
       Global`Nf^4 + 4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^5 + 
      8*Global`Nc^3*(1 + Global`Nc)*Global`Nf^6)*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBdeltaLorentz[Global`i$45110, 0]*TBgamma[0, Global`d1, Global`d2] - 
      TBgamma[Global`i$45110, Global`d1, Global`d2])*
     (TBdeltaLorentz[Global`i$45110, 0]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[Global`i$45110, Global`d3, Global`d4]) - 
    2*(2 - Global`Nc)*(-1 + Global`Nc^2)*Global`Nf*
     (32*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*(2 + Global`Nf)*
       (-2 + 3*Global`Nf) - 4*Global`Nc^6*(-1 + Global`Nf)*Global`Nf^5*
       (-16 + 20*Global`Nf^2 + 3*Global`Nf^4) - 32*Global`Nc*Global`Nf*
       (-8 + Global`Nf^2*(10 + Global`Nf - 4*Global`Nf^2 + Global`Nf^3)) + 
      8*Global`Nc^2*(-1 + Global`Nf)*Global`Nf*(1 + Global`Nf)*
       (28 + (-4 + Global`Nf)*Global`Nf*(-5 + 4*Global`Nf*(1 + Global`Nf))) - 
      4*Global`Nc^5*Global`Nf*(-32 + Global`Nf*
         (-32 + Global`Nf*(94 + Global`Nf*(108 + Global`Nf*(-60 + 
                Global`Nf*(-78 + Global`Nf*(-17 + 5*Global`Nf + 
                    3*Global`Nf^3))))))) + Global`Nc^3*
       (-64 + Global`Nf*(-384 + Global`Nf*(32 + Global`Nf*
             (668 + Global`Nf*(324 + Global`Nf*(-340 + Global`Nf*(-244 + 
                    Global`Nf*(-47 + 73*Global`Nf)))))))) + 
      Global`Nc^4*(-32 + Global`Nf*(160 + Global`Nf*
           (392 + Global`Nf*(-268 + Global`Nf*(-444 + Global`Nf*
                 (156 + Global`Nf*(6 + Global`Nf*(-85 + (73 - 12*Global`Nf)*
                       Global`Nf)))))))))*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$45126, 0]*TBgamma[0, Global`d1, 
           Global`d2]) + TBgamma[Global`i$45126, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$45126, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$45126, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$45126, 0]*TBgamma[0, Global`d1, 
           Global`dc$45129]) + TBgamma[Global`i$45126, Global`d1, 
         Global`dc$45129])*(-(TBdeltaLorentz[Global`i$45126, 0]*
          TBgamma[0, Global`d3, Global`dc$45132]) + TBgamma[Global`i$45126, 
         Global`d3, Global`dc$45132])*TBgamma5[Global`dc$45129, Global`d2]*
       TBgamma5[Global`dc$45132, Global`d4]) - 2*(2 - Global`Nc)*Global`Nc*
     (-1 + Global`Nc^2)*Global`Nf*(12*Global`Nc^5*(-1 + Global`Nf)*
       Global`Nf^5*(8 - 4*Global`Nf^2 + Global`Nf^4) + 
      32*(-1 + Global`Nf)*(1 + Global`Nf)*
       (-8 + Global`Nf*(2 + Global`Nf*(2 + Global`Nf*(4 + 3*Global`Nf)))) + 
      8*Global`Nc*(16 + Global`Nf*(-68 + Global`Nf*(-16 + 137*Global`Nf + 
            Global`Nf^3*(-101 + 4*Global`Nf*(3 + 5*Global`Nf))))) + 
      Global`Nc^2*(-192 + Global`Nf*(-128 + Global`Nf*
           (-32 + Global`Nf*(1 + Global`Nf)*(500 + Global`Nf*(296 + 
                Global`Nf*(-740 + Global`Nf*(56 + 55*Global`Nf))))))) + 
      12*Global`Nc^4*Global`Nf*(16 + Global`Nf*
         (16 + Global`Nf*(-34 + Global`Nf*(-52 + Global`Nf*(24 + 
                Global`Nf*(46 + Global`Nf*(-11 - 9*Global`Nf + Global`Nf^
                     3))))))) + Global`Nc^3*
       (-96 + Global`Nf*(480 + Global`Nf*(24 + Global`Nf*
             (-996 + Global`Nf*(60 + Global`Nf*(916 + Global`Nf*(-166 + 
                    Global`Nf*(-235 + Global`Nf*(55 + 12*Global`Nf))))))))))*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$45148]*TBgamma[0, Global`d3, 
        Global`dc$45151]*TBgamma5[Global`dc$45148, Global`d2]*
       TBgamma5[Global`dc$45151, Global`d4]) + 3*(1 - Global`Nc)*Global`Nc*
     (1 + Global`Nc)*(-1 + Global`Nc^2)*Global`Nf^2*(1 + Global`Nf)*
     (-2 + Global`Nc*(-1 + 2*Global`Nf))*
     (-4 + Global`Nf^2*(3 + 2*Global`Nc*Global`Nf))*
     TBepsFund[Global`flavor, Global`F1, Global`F3]*
     TBepsFund[Global`flavor, Global`F2, Global`F4]*
     TBepsFund[Global`color, Global`a$127218, Global`A1, Global`A3]*
     TBepsFund[Global`color, Global`a$127218, Global`A2, Global`A4]*
     (8*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
        Global`d4] + 8*TBgamma[Global`vi1$45054, Global`d1, Global`d2]*
       TBgamma[Global`vi1$45054, Global`d3, Global`d4] + 
      (TBgamma[Global`vi2$45057, Global`dint2$45078, Global`d2]*
         TBgamma[Global`vi3$45060, Global`d1, Global`dint2$45078] - 
        TBgamma[Global`vi2$45057, Global`d1, Global`dint1$45072]*
         TBgamma[Global`vi3$45060, Global`dint1$45072, Global`d2])*
       (TBgamma[Global`vi2$45057, Global`dint2$45081, Global`d4]*
         TBgamma[Global`vi3$45060, Global`d3, Global`dint2$45081] - 
        TBgamma[Global`vi2$45057, Global`d3, Global`dint1$45075]*
         TBgamma[Global`vi3$45060, Global`dint1$45075, Global`d4]) + 
      8*(TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] + 
        TBgamma[Global`vi4$45063, Global`d1, Global`di1$45066]*
         TBgamma[Global`vi4$45063, Global`d3, Global`di2$45069]*
         TBgamma5[Global`di1$45066, Global`d2]*TBgamma5[Global`di2$45069, 
          Global`d4])) - 64*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc^2*
     (1 + Global`Nc)*(1 - Global`Nf)*Global`Nf*(1 + Global`Nf)*
     (8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
      2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
      (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
      (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
      4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
      4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$45167]*TBgamma[0, Global`d3, 
        Global`dc$45170]*TBgamma5[Global`dc$45167, Global`d2]*
       TBgamma5[Global`dc$45170, Global`d4])*TBT[Global`color, 
      Global`a$45173, Global`A1, Global`A2]*TBT[Global`color, Global`a$45173, 
      Global`A3, Global`A4] + 64*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc*
     (1 + Global`Nc)*(-1 + Global`Nc^2)*(1 - Global`Nf)*Global`Nf^2*
     (8 + 2*Global`Nc^3*Global`Nf^5 - 2*Global`Nf^2*(7 + 3*Global`Nf) + 
      Global`Nc^2*Global`Nf*(-4 + Global`Nf*(-8 + Global`Nf + 5*Global`Nf^2 + 
          2*Global`Nf^3)) + Global`Nc*(4 - Global`Nf*(1 + Global`Nf)*
         (-8 + Global`Nf*(3 + Global`Nf))))*TBdeltaFund[Global`flavor, 
      Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$45189, 0]*TBgamma[0, Global`d1, 
           Global`d2]) + TBgamma[Global`i$45189, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$45189, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$45189, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$45189, 0]*TBgamma[0, Global`d1, 
           Global`dc$45192]) + TBgamma[Global`i$45189, Global`d1, 
         Global`dc$45192])*(-(TBdeltaLorentz[Global`i$45189, 0]*
          TBgamma[0, Global`d3, Global`dc$45195]) + TBgamma[Global`i$45189, 
         Global`d3, Global`dc$45195])*TBgamma5[Global`dc$45192, Global`d2]*
       TBgamma5[Global`dc$45195, Global`d4])*TBT[Global`color, 
      Global`a$45198, Global`A1, Global`A2]*TBT[Global`color, Global`a$45198, 
      Global`A3, Global`A4] + 4*(2 - Global`Nc)*Global`Nc*(-1 + Global`Nc^2)*
     (48*(-1 + Global`Nf)*Global`Nf^2*(1 + Global`Nf)*(2 + Global`Nf) + 
      4*Global`Nc^4*(-1 + Global`Nf)*Global`Nf^2*
       (12 + Global`Nf*(-6 + Global`Nf*(-30 - 16*Global`Nf + 4*Global`Nf^3 + 
            3*Global`Nf^5))) - Global`Nc*(1 + Global`Nf)*
       (-64 + Global`Nf*(32 + Global`Nf*(48 + Global`Nf*
             (-116 + Global`Nf*(88 + 3*Global`Nf*(12 + Global`Nf*
                   (-8 + 3*Global`Nf))))))) + 4*Global`Nc^3*Global`Nf*
       (-8 + Global`Nf*(-20 + Global`Nf*(-10 + Global`Nf*
             (28 + Global`Nf*(24 + Global`Nf*(-6 + Global`Nf*(-9 - 
                    11*Global`Nf + 3*Global`Nf^3))))))) + 
      Global`Nc^2*(32 + Global`Nf*(-64 + Global`Nf*
           (40 + Global`Nf*(76 + Global`Nf*(-132 + Global`Nf*(20 + 
                  Global`Nf*(90 + Global`Nf*(-11 + 3*Global`Nf*(-3 + 
                        4*Global`Nf))))))))))*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
       TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      2*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$45022, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$45022, Global`F3, Global`F4]) + 
    4*(2 - Global`Nc)*Global`Nc*(-1 + Global`Nc^2)*
     (48*(-1 + Global`Nf)*Global`Nf^2*(1 + Global`Nf)*(2 + Global`Nf) - 
      4*Global`Nc^4*(-1 + Global`Nf)*Global`Nf^2*
       (-12 + Global`Nf*(6 + Global`Nf*(30 + 8*Global`Nf + 4*Global`Nf^3 + 
            3*Global`Nf^5))) + Global`Nc*(1 + Global`Nf)*
       (-64 + Global`Nf*(32 + Global`Nf*(144 + Global`Nf*
             (28 + Global`Nf*(-56 + 3*Global`Nf*(-20 + Global`Nf*
                   (-8 + 3*Global`Nf))))))) - 4*Global`Nc^3*Global`Nf*
       (-8 + Global`Nf*(4 + Global`Nf*(50 + Global`Nf*
             (28 + Global`Nf*(-36 + Global`Nf*(-30 + Global`Nf*(-9 - 
                    11*Global`Nf + 3*Global`Nf^3))))))) + 
      Global`Nc^2*(-32 + Global`Nf*(64 + Global`Nf*
           (248 + Global`Nf*(-124 + Global`Nf*(-252 + Global`Nf*
                 (28 + Global`Nf*(6 + Global`Nf*(11 + 3*(3 - 4*Global`Nf)*
                       Global`Nf)))))))))*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] - 
      2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$45038, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$45038, Global`F3, Global`F4]) - 
    24*(2 - Global`Nc)*Global`Nc^3*(-1 + Global`Nc^2)*Global`Nf^2*
     (2 - Global`Nf^2)*(8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
      2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
      (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
      (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
      4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
      4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$45214, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$45214, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      2*Global`Nf*TBT[Global`flavor, Global`f$45217, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$45217, Global`F3, Global`F4]))/
   ((1 - Global`Nc)*(2 - Global`Nc)*Global`Nc^3*(1 + Global`Nc)*
    (-1 + Global`Nc^2)*(1 - Global`Nf)*Global`Nf^2*(1 + Global`Nf)*
    (8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
     2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
     (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
     (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
     4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
     4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))), 
 -1/3072*(-4*(2 - Global`Nc)*(-1 + Global`Nc^2)*Global`Nf*
     (8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
      2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
      (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
      (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
      4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
      4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
     (32*(-1 + Global`Nf^2) - 3*Global`Nc^2*(-12 + 12*Global`Nf^2 + 
        Global`Nf^4))*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
    96*(1 - Global`Nc)*(2 - Global`Nc)*(1 + Global`Nc)*(-1 + Global`Nc^2)*
     (1 - Global`Nf)*Global`Nf^2*(8 + 4*Global`Nc*(3 + Global`Nc) + 
      8*Global`Nc^2*Global`Nf + (-6 + (-29 + Global`Nc)*Global`Nc)*
       Global`Nf^2 + (8 - Global`Nc*(15 + 11*Global`Nc))*Global`Nf^3 - 
      2*(-3 + Global`Nc*(-5 + Global`Nc*(3 + Global`Nc)))*Global`Nf^4 + 
      4*Global`Nc*(1 + Global`Nc)*Global`Nf^5)*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBdeltaLorentz[Global`i$8725, 0]*TBgamma[0, Global`d1, Global`d2] - 
      TBgamma[Global`i$8725, Global`d1, Global`d2])*
     (TBdeltaLorentz[Global`i$8725, 0]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[Global`i$8725, Global`d3, Global`d4]) - 
    2*(2 - Global`Nc)*(-1 + Global`Nc^2)*Global`Nf*
     (12*Global`Nc^5*(-1 + Global`Nf)*Global`Nf^5*(8 - 4*Global`Nf^2 + 
        Global`Nf^4) + 32*(-1 + Global`Nf)*(1 + Global`Nf)*
       (-8 + Global`Nf*(2 + Global`Nf*(2 + Global`Nf*(4 + 3*Global`Nf)))) + 
      8*Global`Nc*(16 + Global`Nf*(-68 + Global`Nf*(-16 + 137*Global`Nf + 
            Global`Nf^3*(-101 + 4*Global`Nf*(3 + 5*Global`Nf))))) + 
      Global`Nc^2*(-192 + Global`Nf*(-128 + Global`Nf*
           (-32 + Global`Nf*(1 + Global`Nf)*(500 + Global`Nf*(296 + 
                Global`Nf*(-740 + Global`Nf*(56 + 55*Global`Nf))))))) + 
      12*Global`Nc^4*Global`Nf*(16 + Global`Nf*
         (16 + Global`Nf*(-34 + Global`Nf*(-52 + Global`Nf*(24 + 
                Global`Nf*(46 + Global`Nf*(-11 - 9*Global`Nf + Global`Nf^
                     3))))))) + Global`Nc^3*
       (-96 + Global`Nf*(480 + Global`Nf*(24 + Global`Nf*
             (-996 + Global`Nf*(60 + Global`Nf*(916 + Global`Nf*(-166 + 
                    Global`Nf*(-235 + Global`Nf*(55 + 12*Global`Nf))))))))))*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$8741, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$8741, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$8741, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$8741, Global`d3, Global`d4]) - 
      (-(TBdeltaLorentz[Global`i$8741, 0]*TBgamma[0, Global`d1, 
           Global`dc$8744]) + TBgamma[Global`i$8741, Global`d1, 
         Global`dc$8744])*(-(TBdeltaLorentz[Global`i$8741, 0]*
          TBgamma[0, Global`d3, Global`dc$8747]) + TBgamma[Global`i$8741, 
         Global`d3, Global`dc$8747])*TBgamma5[Global`dc$8744, Global`d2]*
       TBgamma5[Global`dc$8747, Global`d4]) + 2*(2 - Global`Nc)*
     (-1 + Global`Nc^2)*Global`Nf*(12*Global`Nc^5*(-1 + Global`Nf)*
       Global`Nf^5*(-16 + 28*Global`Nf^2 + Global`Nf^4) + 
      32*(1 + Global`Nf)^2*(-16 + 24*Global`Nf - 11*Global`Nf^3 + 
        3*Global`Nf^4) - 8*Global`Nc*(-1 + Global`Nf)*(1 + Global`Nf)*
       (-32 + Global`Nf*(124 + Global`Nf*(156 + Global`Nf*
             (-129 + 4*Global`Nf*(-9 + 13*Global`Nf))))) + 
      12*Global`Nc^4*Global`Nf*(-32 + Global`Nf*
         (-32 + Global`Nf*(106 + Global`Nf*(148 + Global`Nf*(-68 + 
                Global`Nf*(-154 + Global`Nf*(5 + 23*Global`Nf + Global`Nf^
                     3))))))) + Global`Nc^3*
       (288 + Global`Nf*(-1056 + Global`Nf*(-1608 + Global`Nf*
             (2124 + Global`Nf*(1596 + Global`Nf*(-1628 + Global`Nf*
                   (-70 + (-25 + Global`Nf)*Global`Nf*(-29 + 12*
                       Global`Nf)))))))) + Global`Nc^2*
       (576 - Global`Nf*(-640 + Global`Nf*(800 + Global`Nf*
             (1660 + Global`Nf*(1028 + Global`Nf*(-948 + Global`Nf*
                   (-1716 + Global`Nf*(81 + 329*Global`Nf)))))))))*
     TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$8763]*TBgamma[0, Global`d3, 
        Global`dc$8766]*TBgamma5[Global`dc$8763, Global`d2]*
       TBgamma5[Global`dc$8766, Global`d4]) + 3*(1 - Global`Nc)*Global`Nc*
     (1 + Global`Nc)*(-1 + Global`Nc^2)*Global`Nf^2*(1 + Global`Nf)*
     (1 + 2*Global`Nf)*(4 - Global`Nf^2*(3 + 2*Global`Nc*Global`Nf))*
     TBepsFund[Global`flavor, Global`F1, Global`F3]*
     TBepsFund[Global`flavor, Global`F2, Global`F4]*
     TBepsFund[Global`color, Global`a$127218, Global`A1, Global`A3]*
     TBepsFund[Global`color, Global`a$127218, Global`A2, Global`A4]*
     (8*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
        Global`d4] + 8*TBgamma[Global`vi1$8669, Global`d1, Global`d2]*
       TBgamma[Global`vi1$8669, Global`d3, Global`d4] + 
      (TBgamma[Global`vi2$8672, Global`dint2$8693, Global`d2]*
         TBgamma[Global`vi3$8675, Global`d1, Global`dint2$8693] - 
        TBgamma[Global`vi2$8672, Global`d1, Global`dint1$8687]*
         TBgamma[Global`vi3$8675, Global`dint1$8687, Global`d2])*
       (TBgamma[Global`vi2$8672, Global`dint2$8696, Global`d4]*
         TBgamma[Global`vi3$8675, Global`d3, Global`dint2$8696] - 
        TBgamma[Global`vi2$8672, Global`d3, Global`dint1$8690]*
         TBgamma[Global`vi3$8675, Global`dint1$8690, Global`d4]) + 
      8*(TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] + 
        TBgamma[Global`vi4$8678, Global`d1, Global`di1$8681]*
         TBgamma[Global`vi4$8678, Global`d3, Global`di2$8684]*
         TBgamma5[Global`di1$8681, Global`d2]*TBgamma5[Global`di2$8684, 
          Global`d4])) + 64*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc*
     (1 + Global`Nc)*(1 - Global`Nf)*Global`Nf*(1 + Global`Nf)*
     (8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
      2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
      (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
      (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
      4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
      4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[0, Global`d1, Global`dc$8782]*TBgamma[0, Global`d3, 
        Global`dc$8785]*TBgamma5[Global`dc$8782, Global`d2]*
       TBgamma5[Global`dc$8785, Global`d4])*TBT[Global`color, Global`a$8788, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$8788, Global`A3, 
      Global`A4] - 192*(1 - Global`Nc)*(2 - Global`Nc)*Global`Nc*
     (1 + Global`Nc)*(-1 + Global`Nc^2)*(1 - Global`Nf)*Global`Nf^2*
     (4 - 4*Global`Nc*Global`Nf - (3 + 8*Global`Nc)*Global`Nf^2 + 
      (4 - 3*Global`Nc)*Global`Nf^3 + (3 + 5*Global`Nc)*Global`Nf^4 + 
      2*Global`Nc*(1 + Global`Nc)*Global`Nf^5)*TBdeltaFund[Global`flavor, 
      Global`F1, Global`F2]*TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((-(TBdeltaLorentz[Global`i$8804, 0]*TBgamma[0, Global`d1, Global`d2]) + 
        TBgamma[Global`i$8804, Global`d1, Global`d2])*
       (-(TBdeltaLorentz[Global`i$8804, 0]*TBgamma[0, Global`d3, 
           Global`d4]) + TBgamma[Global`i$8804, Global`d3, Global`d4]) + 
      (-(TBdeltaLorentz[Global`i$8804, 0]*TBgamma[0, Global`d1, 
           Global`dc$8807]) + TBgamma[Global`i$8804, Global`d1, 
         Global`dc$8807])*(-(TBdeltaLorentz[Global`i$8804, 0]*
          TBgamma[0, Global`d3, Global`dc$8810]) + TBgamma[Global`i$8804, 
         Global`d3, Global`dc$8810])*TBgamma5[Global`dc$8807, Global`d2]*
       TBgamma5[Global`dc$8810, Global`d4])*TBT[Global`color, Global`a$8813, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$8813, Global`A3, 
      Global`A4] - 4*(2 - Global`Nc)*Global`Nc*(-1 + Global`Nc^2)*
     (32*(2 + Global`Nf) + 4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^2*
       (-12 + Global`Nf*(-42 + Global`Nf*(-42 - 16*Global`Nf + 
            4*Global`Nf^3 + 3*Global`Nf^5))) + 
      Global`Nf^2*(-80 + Global`Nf*(68 + Global`Nf*
           (28 - Global`Nf*(124 + 3*Global`Nf*(4 + Global`Nf*(-5 + 
                  3*Global`Nf)))))) + 4*Global`Nc^2*Global`Nf*
       (-8 + Global`Nf*(-20 + Global`Nf*(-10 + Global`Nf*
             (28 + Global`Nf*(24 + Global`Nf*(-6 + Global`Nf*(-9 - 
                    11*Global`Nf + 3*Global`Nf^3))))))) + 
      Global`Nc*(32 + Global`Nf*(-64 + Global`Nf*(-152 + 
            Global`Nf*(-20 + Global`Nf*(60 + Global`Nf*(116 + Global`Nf*
                   (90 + Global`Nf*(-11 + 3*Global`Nf*(-3 + 
                        4*Global`Nf))))))))))*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
       TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      2*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$8637, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$8637, Global`F3, Global`F4]) + 
    4*(2 - Global`Nc)*Global`Nc*(-1 + Global`Nc^2)*(32*(2 + Global`Nf) + 
      4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^2*
       (12 + Global`Nf*(42 + Global`Nf*(42 + 8*Global`Nf + 4*Global`Nf^3 + 
            3*Global`Nf^5))) + Global`Nf^2*
       (-176 + Global`Nf*(-172 + Global`Nf*(28 + Global`Nf*
             (116 - 3*(-4 + Global`Nf)*Global`Nf*(7 + 3*Global`Nf))))) + 
      4*Global`Nc^2*Global`Nf*(-8 + Global`Nf*
         (4 + Global`Nf*(50 + Global`Nf*(28 + Global`Nf*(-36 + Global`Nf*
                 (-30 + Global`Nf*(-9 - 11*Global`Nf + 3*Global`Nf^3))))))) + 
      Global`Nc*(32 + Global`Nf*(-64 + Global`Nf*
           (-56 + Global`Nf*(220 + Global`Nf*(60 + Global`Nf*(-124 + 
                  Global`Nf*(-6 + Global`Nf*(-11 + 3*Global`Nf*(-3 + 
                        4*Global`Nf))))))))))*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] - 
      2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$8653, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$8653, Global`F3, Global`F4]) + 
    24*(2 - Global`Nc)*Global`Nc^2*(-1 + Global`Nc^2)*Global`Nf^2*
     (2 - Global`Nf^2)*(8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
      2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
      (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
      (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
      4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
      4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))*
     (TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4] - 
      TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4])*
     TBT[Global`color, Global`a$8829, Global`A1, Global`A2]*
     TBT[Global`color, Global`a$8829, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      2*Global`Nf*TBT[Global`flavor, Global`f$8832, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$8832, Global`F3, Global`F4]))/
   ((1 - Global`Nc)*(2 - Global`Nc)*Global`Nc^2*(1 + Global`Nc)*
    (-1 + Global`Nc^2)*(1 - Global`Nf)*Global`Nf^2*(1 + Global`Nf)*
    (8*Global`Nc - 8*Global`Nc*(2 + Global`Nc)*Global`Nf - 
     2*(8 + Global`Nc*(9 + 4*Global`Nc))*Global`Nf^2 + 
     (-5 + 3*Global`Nc*(3 + 4*Global`Nc))*Global`Nf^3 + 
     (3 + Global`Nc*(3 + 20*Global`Nc))*Global`Nf^4 + 
     4*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^5 - 
     4*Global`Nc^2*(1 + Global`Nc)*Global`Nf^6 + 8*(2 + Global`Nf))), 
 (8*Global`Nc*Global`Nf*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$265056]*TBgamma[0, Global`d3, 
       Global`dc$265059]*TBgamma5[Global`dc$265056, Global`d2]*
      TBgamma5[Global`dc$265059, Global`d4])*TBT[Global`color, 
     Global`a$265062, Global`A1, Global`A2]*TBT[Global`color, 
     Global`a$265062, Global`A3, Global`A4] + 
   TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
      (Global`Nf*TBgamma[0, Global`d1, Global`d2]*
        ((1 + TBdeltaLorentz[Global`i$265015, 0]^2)*TBgamma[0, Global`d3, 
           Global`d4] - TBdeltaLorentz[Global`i$265015, 0]*
          TBgamma[Global`i$265015, Global`d3, Global`d4]) - 
       2*Global`Nc*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
         Global`d4] - Global`Nf*(TBgamma[Global`i$265015, Global`d1, 
           Global`d2]*(TBdeltaLorentz[Global`i$265015, 0]*
            TBgamma[0, Global`d3, Global`d4] - TBgamma[Global`i$265015, 
            Global`d3, Global`d4]) + (TBdeltaLorentz[Global`i$265015, 0]*
            TBgamma[0, Global`d1, Global`dc$265018] - 
           TBgamma[Global`i$265015, Global`d1, Global`dc$265018])*
          (TBdeltaLorentz[Global`i$265015, 0]*TBgamma[0, Global`d3, 
             Global`dc$265021] - TBgamma[Global`i$265015, Global`d3, 
            Global`dc$265021])*TBgamma5[Global`dc$265018, Global`d2]*
          TBgamma5[Global`dc$265021, Global`d4] + 
         TBgamma[0, Global`d1, Global`dc$265037]*TBgamma[0, Global`d3, 
           Global`dc$265040]*TBgamma5[Global`dc$265037, Global`d2]*
          TBgamma5[Global`dc$265040, Global`d4])) - 
     4*Global`Nc*Global`Nf*TBgamma5[Global`d1, Global`d2]*
      TBgamma5[Global`d3, Global`d4]*TBT[Global`flavor, Global`f$264911, 
       Global`F1, Global`F2]*TBT[Global`flavor, Global`f$264911, Global`F3, 
       Global`F4]) + 2*Global`Nc*TBdeltaDirac[Global`d1, Global`d2]*
    TBdeltaDirac[Global`d3, Global`d4]*TBdeltaFund[Global`color, Global`A1, 
     Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
      TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
     2*Global`Nf*TBT[Global`flavor, Global`f$264927, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$264927, Global`F3, Global`F4]))/
  (48*Global`Nc*(-1 + Global`Nc^2)*Global`Nf^2), 
 ((-32*(8 + 2*Global`Nc^3*Global`Nf^5 - 2*Global`Nf^2*(7 + 3*Global`Nf) + 
      Global`Nc^2*Global`Nf*(-4 + Global`Nf*(-8 + Global`Nf + 5*Global`Nf^2 + 
          2*Global`Nf^3)) + Global`Nc*(4 - Global`Nf*(1 + Global`Nf)*
         (-8 + Global`Nf*(3 + Global`Nf))))*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBdeltaLorentz[Global`i$28741, 0]*TBgamma[0, Global`d1, Global`d2] - 
      TBgamma[Global`i$28741, Global`d1, Global`d2])*
     (TBdeltaLorentz[Global`i$28741, 0]*TBgamma[0, Global`d3, Global`d4] - 
      TBgamma[Global`i$28741, Global`d3, Global`d4]))/(1 + Global`Nf) + 
   (16*(8 + 2*Global`Nc^3*Global`Nf^5 - 2*Global`Nf^2*(7 + 3*Global`Nf) + 
      Global`Nc^2*Global`Nf*(-4 + Global`Nf*(-8 + Global`Nf + 5*Global`Nf^2 + 
          2*Global`Nf^3)) + Global`Nc*(4 - Global`Nf*(1 + Global`Nf)*
         (-8 + Global`Nf*(3 + Global`Nf))))*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((TBdeltaLorentz[Global`i$28757, 0]*TBgamma[0, Global`d1, Global`d2] - 
        TBgamma[Global`i$28757, Global`d1, Global`d2])*
       (TBdeltaLorentz[Global`i$28757, 0]*TBgamma[0, Global`d3, Global`d4] - 
        TBgamma[Global`i$28757, Global`d3, Global`d4]) - 
      (TBdeltaLorentz[Global`i$28757, 0]*TBgamma[0, Global`d1, 
          Global`dc$28760] - TBgamma[Global`i$28757, Global`d1, 
         Global`dc$28760])*(TBdeltaLorentz[Global`i$28757, 0]*
         TBgamma[0, Global`d3, Global`dc$28763] - TBgamma[Global`i$28757, 
         Global`d3, Global`dc$28763])*TBgamma5[Global`dc$28760, Global`d2]*
       TBgamma5[Global`dc$28763, Global`d4]))/(1 + Global`Nf) - 
   (48*Global`Nc*(4 - 4*Global`Nc*Global`Nf - (3 + 8*Global`Nc)*Global`Nf^2 + 
      (4 - 3*Global`Nc)*Global`Nf^3 + (3 + 5*Global`Nc)*Global`Nf^4 + 
      2*Global`Nc*(1 + Global`Nc)*Global`Nf^5)*TBdeltaFund[Global`color, 
      Global`A1, Global`A2]*TBdeltaFund[Global`color, Global`A3, Global`A4]*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
      TBgamma[0, Global`d1, Global`dc$28779]*TBgamma[0, Global`d3, 
        Global`dc$28782]*TBgamma5[Global`dc$28779, Global`d2]*
       TBgamma5[Global`dc$28782, Global`d4]))/(1 + Global`Nf) + 
   (3*Global`Nc*(-1 + Global`Nc*Global`Nf)*
     (-4 + Global`Nf^2*(3 + 2*Global`Nc*Global`Nf))*
     TBepsFund[Global`flavor, Global`F1, Global`F3]*
     TBepsFund[Global`flavor, Global`F2, Global`F4]*
     TBepsFund[Global`color, Global`a$127218, Global`A1, Global`A3]*
     TBepsFund[Global`color, Global`a$127218, Global`A2, Global`A4]*
     (8*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
        Global`d4] + 8*TBgamma[Global`vi1$28685, Global`d1, Global`d2]*
       TBgamma[Global`vi1$28685, Global`d3, Global`d4] + 
      (TBgamma[Global`vi2$28688, Global`dint2$28709, Global`d2]*
         TBgamma[Global`vi3$28691, Global`d1, Global`dint2$28709] - 
        TBgamma[Global`vi2$28688, Global`d1, Global`dint1$28703]*
         TBgamma[Global`vi3$28691, Global`dint1$28703, Global`d2])*
       (TBgamma[Global`vi2$28688, Global`dint2$28712, Global`d4]*
         TBgamma[Global`vi3$28691, Global`d3, Global`dint2$28712] - 
        TBgamma[Global`vi2$28688, Global`d3, Global`dint1$28706]*
         TBgamma[Global`vi3$28691, Global`dint1$28706, Global`d4]) + 
      8*(TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] + 
        TBgamma[Global`vi4$28694, Global`d1, Global`di1$28697]*
         TBgamma[Global`vi4$28694, Global`d3, Global`di2$28700]*
         TBgamma5[Global`di1$28697, Global`d2]*TBgamma5[Global`di2$28700, 
          Global`d4])))/((-2 + Global`Nc)*(-1 + Global`Nc)*
     (-1 + Global`Nf)) + (64*Global`Nc*(-1 + Global`Nc*Global`Nf)*
     (-4 + 2*Global`Nc^3*Global`Nf^5 + Global`Nf^2*(7 + 3*Global`Nf) + 
      Global`Nc*(2 + Global`Nf)*(2 + (-1 + Global`Nf)*Global`Nf*
         (3 + 5*Global`Nf)) + Global`Nc^2*Global`Nf*
       (-4 + Global`Nf*(1 + Global`Nf)*(-8 + Global`Nf*(3 + 2*Global`Nf))))*
     TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
     TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
     ((TBdeltaLorentz[Global`i$28820, 0]*TBgamma[0, Global`d1, Global`d2] - 
        TBgamma[Global`i$28820, Global`d1, Global`d2])*
       (TBdeltaLorentz[Global`i$28820, 0]*TBgamma[0, Global`d3, Global`d4] - 
        TBgamma[Global`i$28820, Global`d3, Global`d4]) + 
      (TBdeltaLorentz[Global`i$28820, 0]*TBgamma[0, Global`d1, 
          Global`dc$28823] - TBgamma[Global`i$28820, Global`d1, 
         Global`dc$28823])*(TBdeltaLorentz[Global`i$28820, 0]*
         TBgamma[0, Global`d3, Global`dc$28826] - TBgamma[Global`i$28820, 
         Global`d3, Global`dc$28826])*TBgamma5[Global`dc$28823, Global`d2]*
       TBgamma5[Global`dc$28826, Global`d4])*TBT[Global`color, 
      Global`a$28829, Global`A1, Global`A2]*TBT[Global`color, Global`a$28829, 
      Global`A3, Global`A4])/((-1 + Global`Nc^2)*(1 + Global`Nf)) + 
   96*Global`Nc*(2 + Global`Nf)*(-1 + Global`Nc*Global`Nf)*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (-(TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
       TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]) + 
     2*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$28653, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$28653, Global`F3, Global`F4]) + 
   96*Global`Nc*(2 + Global`Nf)*(-1 + Global`Nc*Global`Nf)*
    TBdeltaFund[Global`color, Global`A1, Global`A2]*
    TBdeltaFund[Global`color, Global`A3, Global`A4]*
    (-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4]) + 
     2*Global`Nf*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, 
       Global`d4]*TBT[Global`flavor, Global`f$28669, Global`F1, Global`F2]*
      TBT[Global`flavor, Global`f$28669, Global`F3, Global`F4]))/
  (768*Global`Nc^2*(4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 - 
    8*(2 + Global`Nf) + Global`Nf^2*(16 + (5 - 3*Global`Nf)*Global`Nf) + 
    4*Global`Nc^2*Global`Nf*
     (2 + Global`Nf*(2 + Global`Nf*(-3 - 5*Global`Nf + Global`Nf^3))) + 
    Global`Nc*(-8 + Global`Nf*(16 + Global`Nf*
         (18 + Global`Nf*(-9 + Global`Nf*(-3 + 4*Global`Nf))))))), 
 -1/128*((-2 + Global`Nf^2)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
     TBdeltaFund[Global`color, Global`A3, Global`A4]*
     (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
       (-2*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, Global`d4] + 
        Global`Nc*Global`Nf*(TBgamma[Global`i$75302, Global`d1, Global`d2]*
           (-(TBdeltaLorentz[Global`i$75302, 0]*TBgamma[0, Global`d3, 
               Global`d4]) + TBgamma[Global`i$75302, Global`d3, Global`d4]) + 
          TBgamma[0, Global`d1, Global`d2]*
           ((1 + TBdeltaLorentz[Global`i$75302, 0]^2)*TBgamma[0, Global`d3, 
              Global`d4] - TBdeltaLorentz[Global`i$75302, 0]*
             TBgamma[Global`i$75302, Global`d3, Global`d4]) - 
          (TBdeltaLorentz[Global`i$75302, 0]*TBgamma[0, Global`d1, 
              Global`dc$75305] - TBgamma[Global`i$75302, Global`d1, 
             Global`dc$75305])*(TBdeltaLorentz[Global`i$75302, 0]*
             TBgamma[0, Global`d3, Global`dc$75308] - TBgamma[Global`i$75302, 
             Global`d3, Global`dc$75308])*TBgamma5[Global`dc$75305, 
            Global`d2]*TBgamma5[Global`dc$75308, Global`d4] - 
          TBgamma[0, Global`d1, Global`dc$75324]*TBgamma[0, Global`d3, 
            Global`dc$75327]*TBgamma5[Global`dc$75324, Global`d2]*
           TBgamma5[Global`dc$75327, Global`d4])) - 
      4*Global`Nf*TBgamma5[Global`d1, Global`d2]*TBgamma5[Global`d3, 
        Global`d4]*TBT[Global`flavor, Global`f$75198, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$75198, Global`F3, Global`F4]) + 
    4*Global`Nc*Global`Nf^2*TBgamma5[Global`d1, Global`d2]*
     TBgamma5[Global`d3, Global`d4]*TBT[Global`color, Global`a$75390, 
      Global`A1, Global`A2]*TBT[Global`color, Global`a$75390, Global`A3, 
      Global`A4]*(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
       TBdeltaFund[Global`flavor, Global`F3, Global`F4] - 
      2*Global`Nf*TBT[Global`flavor, Global`f$75393, Global`F1, Global`F2]*
       TBT[Global`flavor, Global`f$75393, Global`F3, Global`F4]) + 
    2*TBdeltaDirac[Global`d1, Global`d2]*TBdeltaDirac[Global`d3, Global`d4]*
     ((-2 + Global`Nf^2)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
       TBdeltaFund[Global`color, Global`A3, Global`A4]*
       (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
         TBdeltaFund[Global`flavor, Global`F3, Global`F4] + 
        2*Global`Nf*TBT[Global`flavor, Global`f$75214, Global`F1, Global`F2]*
         TBT[Global`flavor, Global`f$75214, Global`F3, Global`F4]) + 
      2*Global`Nc*Global`Nf^2*TBT[Global`color, Global`a$75390, Global`A1, 
        Global`A2]*TBT[Global`color, Global`a$75390, Global`A3, Global`A4]*
       (-(TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
          TBdeltaFund[Global`flavor, Global`F3, Global`F4]) + 
        2*Global`Nf*TBT[Global`flavor, Global`f$75393, Global`F1, Global`F2]*
         TBT[Global`flavor, Global`f$75393, Global`F3, Global`F4])))/
   (Global`Nc*(-1 + Global`Nc^2)*Global`Nf*(-1 + Global`Nf^2))}
