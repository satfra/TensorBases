(* Created with the Wolfram Language : www.wolfram.com *)
{{1/(16*Global`Nc^2), 0, 0, 0, 0, 0, 0, 0}, {0, 1/(48*Global`Nc^2), 0, 0, 0, 
  0, 0, 0}, {0, 0, (Global`Nf*(1 + 2*Global`Nc*Global`Nf))/
   (32*Global`Nc^3*(-1 + Global`Nf^2)), 
  -1/32*Global`Nf/(Global`Nc^3*(-1 + Global`Nf^2)), 0, 0, 
  Global`Nf/(16*Global`Nc^2*(-1 + Global`Nf^2)), 
  -1/16*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2))}, 
 {0, 0, -1/32*Global`Nf/(Global`Nc^3*(-1 + Global`Nf^2)), 
  (Global`Nf*(-1 + 2*Global`Nc*Global`Nf))/(96*Global`Nc^3*
    (-1 + Global`Nf^2)), 0, 0, 
  -1/16*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2)), 
  -1/48*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2))}, 
 {0, 0, 0, 0, 1/(4*(-1 + Global`Nc^2)), 0, 0, 0}, 
 {0, 0, 0, 0, 0, 1/(12*(-1 + Global`Nc^2)), 0, 0}, 
 {0, 0, Global`Nf/(16*Global`Nc^2*(-1 + Global`Nf^2)), 
  -1/16*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2)), 0, 0, 
  (Global`Nf*(-1 + 2*Global`Nc*Global`Nf))/(8*Global`Nc*(-1 + Global`Nc^2)*
    (-1 + Global`Nf^2)), Global`Nf/(8*Global`Nc*(-1 + Global`Nc^2)*
    (-1 + Global`Nf^2))}, 
 {0, 0, -1/16*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2)), 
  -1/48*Global`Nf/(Global`Nc^2*(-1 + Global`Nf^2)), 0, 0, 
  Global`Nf/(8*Global`Nc*(-1 + Global`Nc^2)*(-1 + Global`Nf^2)), 
  (Global`Nf*(1 + 2*Global`Nc*Global`Nf))/(24*Global`Nc*(-1 + Global`Nc^2)*
    (-1 + Global`Nf^2))}}
