(* Created with the Wolfram Language : www.wolfram.com *)
{{16*Global`Nc^2, 0, 0, 0, 0, 0, 0, 0}, {0, 48*Global`Nc^2, 0, 0, 0, 0, 0, 
  0}, {0, 0, (8*Global`Nc*(-1 + 2*Global`Nc*Global`Nf))/Global`Nf, 
  (24*Global`Nc)/Global`Nf, 0, 0, (4 - 4*Global`Nc^2)/Global`Nf, 
  (12*(-1 + Global`Nc^2))/Global`Nf}, {0, 0, (24*Global`Nc)/Global`Nf, 
  (24*Global`Nc*(1 + 2*Global`Nc*Global`Nf))/Global`Nf, 0, 0, 
  (12*(-1 + Global`Nc^2))/Global`Nf, (12*(-1 + Global`Nc^2))/Global`Nf}, 
 {0, 0, 0, 0, 4*(-1 + Global`Nc^2), 0, 0, 0}, 
 {0, 0, 0, 0, 0, 12*(-1 + Global`Nc^2), 0, 0}, 
 {0, 0, (4 - 4*Global`Nc^2)/Global`Nf, (12*(-1 + Global`Nc^2))/Global`Nf, 0, 
  0, (2*(-1 + Global`Nc^2)*(1 + 2*Global`Nc*Global`Nf))/
   (Global`Nc*Global`Nf), (6 - 6*Global`Nc^2)/(Global`Nc*Global`Nf)}, 
 {0, 0, (12*(-1 + Global`Nc^2))/Global`Nf, (12*(-1 + Global`Nc^2))/Global`Nf, 
  0, 0, (6 - 6*Global`Nc^2)/(Global`Nc*Global`Nf), 
  (6*(-1 + Global`Nc^2)*(-1 + 2*Global`Nc*Global`Nf))/(Global`Nc*Global`Nf)}}
