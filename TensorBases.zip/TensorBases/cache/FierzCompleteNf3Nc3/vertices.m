(* Created with the Wolfram Language : www.wolfram.com *)
{(TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$1310]*TBgamma[0, Global`d3, 
       Global`dc$1313]*TBgamma5[Global`dc$1310, Global`d2]*
      TBgamma5[Global`dc$1313, Global`d4]) + 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (-(TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2]) + 
     TBgamma[0, Global`d1, Global`dc$1332]*TBgamma[0, Global`d3, 
       Global`dc$1329]*TBgamma5[Global`dc$1329, Global`d2]*
      TBgamma5[Global`dc$1332, Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$1310, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$1310, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d1, 
          Global`dc$1313]) + TBgamma[Global`i$1310, Global`d1, 
        Global`dc$1313])*(-(TBdeltaLorentz[Global`i$1310, 0]*
         TBgamma[0, Global`d3, Global`dc$1316]) + TBgamma[Global`i$1310, 
        Global`d3, Global`dc$1316])*TBgamma5[Global`dc$1313, Global`d2]*
      TBgamma5[Global`dc$1316, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$1332, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$1332, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$1332, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$1332, Global`d3, Global`d2]) - 
     (-(TBdeltaLorentz[Global`i$1332, 0]*TBgamma[0, Global`d1, 
          Global`dc$1338]) + TBgamma[Global`i$1332, Global`d1, 
        Global`dc$1338])*(-(TBdeltaLorentz[Global`i$1332, 0]*
         TBgamma[0, Global`d3, Global`dc$1335]) + TBgamma[Global`i$1332, 
        Global`d3, Global`dc$1335])*TBgamma5[Global`dc$1335, Global`d2]*
      TBgamma5[Global`dc$1338, Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$1310]*TBgamma[0, Global`d3, 
       Global`dc$1313]*TBgamma5[Global`dc$1310, Global`d2]*
      TBgamma5[Global`dc$1313, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2] + 
     TBgamma[0, Global`d1, Global`dc$1332]*TBgamma[0, Global`d3, 
       Global`dc$1329]*TBgamma5[Global`dc$1329, Global`d2]*
      TBgamma5[Global`dc$1332, Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`color, Global`A1, Global`A2]*TBdeltaFund[Global`color, 
     Global`A3, Global`A4]*TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$1310, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$1310, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d1, 
          Global`dc$1313]) + TBgamma[Global`i$1310, Global`d1, 
        Global`dc$1313])*(-(TBdeltaLorentz[Global`i$1310, 0]*
         TBgamma[0, Global`d3, Global`dc$1316]) + TBgamma[Global`i$1310, 
        Global`d3, Global`dc$1316])*TBgamma5[Global`dc$1313, Global`d2]*
      TBgamma5[Global`dc$1316, Global`d4]) - 
   TBdeltaFund[Global`color, Global`A1, Global`A4]*
    TBdeltaFund[Global`color, Global`A3, Global`A2]*
    TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$1332, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$1332, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$1332, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$1332, Global`d3, Global`d2]) + 
     (-(TBdeltaLorentz[Global`i$1332, 0]*TBgamma[0, Global`d1, 
          Global`dc$1338]) + TBgamma[Global`i$1332, Global`d1, 
        Global`dc$1338])*(-(TBdeltaLorentz[Global`i$1332, 0]*
         TBgamma[0, Global`d3, Global`dc$1335]) + TBgamma[Global`i$1332, 
        Global`d3, Global`dc$1335])*TBgamma5[Global`dc$1335, Global`d2]*
      TBgamma5[Global`dc$1338, Global`d4]))/Global`Nf, 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] - 
     TBgamma[0, Global`d1, Global`dc$1310]*TBgamma[0, Global`d3, 
       Global`dc$1313]*TBgamma5[Global`dc$1310, Global`d2]*
      TBgamma5[Global`dc$1313, Global`d4])*TBT[Global`color, Global`a$1316, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1316, Global`A3, 
     Global`A4] + TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (-(TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2]) + 
     TBgamma[0, Global`d1, Global`dc$1335]*TBgamma[0, Global`d3, 
       Global`dc$1332]*TBgamma5[Global`dc$1332, Global`d2]*
      TBgamma5[Global`dc$1335, Global`d4])*TBT[Global`color, Global`a$1338, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$1338, Global`A3, 
     Global`A2])/Global`Nf, 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$1310, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$1310, Global`d3, Global`d4]) - 
     (-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d1, 
          Global`dc$1313]) + TBgamma[Global`i$1310, Global`d1, 
        Global`dc$1313])*(-(TBdeltaLorentz[Global`i$1310, 0]*
         TBgamma[0, Global`d3, Global`dc$1316]) + TBgamma[Global`i$1310, 
        Global`d3, Global`dc$1316])*TBgamma5[Global`dc$1313, Global`d2]*
      TBgamma5[Global`dc$1316, Global`d4])*TBT[Global`color, Global`a$1319, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1319, Global`A3, 
     Global`A4] - TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$1335, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$1335, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$1335, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$1335, Global`d3, Global`d2]) - 
     (-(TBdeltaLorentz[Global`i$1335, 0]*TBgamma[0, Global`d1, 
          Global`dc$1341]) + TBgamma[Global`i$1335, Global`d1, 
        Global`dc$1341])*(-(TBdeltaLorentz[Global`i$1335, 0]*
         TBgamma[0, Global`d3, Global`dc$1338]) + TBgamma[Global`i$1335, 
        Global`d3, Global`dc$1338])*TBgamma5[Global`dc$1338, Global`d2]*
      TBgamma5[Global`dc$1341, Global`d4])*TBT[Global`color, Global`a$1344, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$1344, Global`A3, 
     Global`A2])/Global`Nf, 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    (TBgamma[0, Global`d1, Global`d2]*TBgamma[0, Global`d3, Global`d4] + 
     TBgamma[0, Global`d1, Global`dc$1310]*TBgamma[0, Global`d3, 
       Global`dc$1313]*TBgamma5[Global`dc$1310, Global`d2]*
      TBgamma5[Global`dc$1313, Global`d4])*TBT[Global`color, Global`a$1316, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1316, Global`A3, 
     Global`A4] - TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    (TBgamma[0, Global`d1, Global`d4]*TBgamma[0, Global`d3, Global`d2] + 
     TBgamma[0, Global`d1, Global`dc$1335]*TBgamma[0, Global`d3, 
       Global`dc$1332]*TBgamma5[Global`dc$1332, Global`d2]*
      TBgamma5[Global`dc$1335, Global`d4])*TBT[Global`color, Global`a$1338, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$1338, Global`A3, 
     Global`A2])/Global`Nf, 
 (TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F4]*
    ((-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d1, Global`d2]) + 
       TBgamma[Global`i$1310, Global`d1, Global`d2])*
      (-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d3, Global`d4]) + 
       TBgamma[Global`i$1310, Global`d3, Global`d4]) + 
     (-(TBdeltaLorentz[Global`i$1310, 0]*TBgamma[0, Global`d1, 
          Global`dc$1313]) + TBgamma[Global`i$1310, Global`d1, 
        Global`dc$1313])*(-(TBdeltaLorentz[Global`i$1310, 0]*
         TBgamma[0, Global`d3, Global`dc$1316]) + TBgamma[Global`i$1310, 
        Global`d3, Global`dc$1316])*TBgamma5[Global`dc$1313, Global`d2]*
      TBgamma5[Global`dc$1316, Global`d4])*TBT[Global`color, Global`a$1319, 
     Global`A1, Global`A2]*TBT[Global`color, Global`a$1319, Global`A3, 
     Global`A4] - TBdeltaFund[Global`flavor, Global`F1, Global`F4]*
    TBdeltaFund[Global`flavor, Global`F3, Global`F2]*
    ((-(TBdeltaLorentz[Global`i$1335, 0]*TBgamma[0, Global`d1, Global`d4]) + 
       TBgamma[Global`i$1335, Global`d1, Global`d4])*
      (-(TBdeltaLorentz[Global`i$1335, 0]*TBgamma[0, Global`d3, Global`d2]) + 
       TBgamma[Global`i$1335, Global`d3, Global`d2]) + 
     (-(TBdeltaLorentz[Global`i$1335, 0]*TBgamma[0, Global`d1, 
          Global`dc$1341]) + TBgamma[Global`i$1335, Global`d1, 
        Global`dc$1341])*(-(TBdeltaLorentz[Global`i$1335, 0]*
         TBgamma[0, Global`d3, Global`dc$1338]) + TBgamma[Global`i$1335, 
        Global`d3, Global`dc$1338])*TBgamma5[Global`dc$1338, Global`d2]*
      TBgamma5[Global`dc$1341, Global`d4])*TBT[Global`color, Global`a$1344, 
     Global`A1, Global`A4]*TBT[Global`color, Global`a$1344, Global`A3, 
     Global`A2])/Global`Nf}
