(* Created with the Wolfram Language : www.wolfram.com *)
{((I/18)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (TBdeltaLorentz[Global`nu, Global`rho]*(TBvec[Global`p1, Global`mu] + 
      2*TBvec[Global`p2, Global`mu]) - TBdeltaLorentz[Global`mu, Global`rho]*
     (2*TBvec[Global`p1, Global`nu] + TBvec[Global`p2, Global`nu]) + 
    TBdeltaLorentz[Global`mu, Global`nu]*(TBvec[Global`p1, Global`rho] - 
      TBvec[Global`p2, Global`rho])))/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p1] + TBsp[Global`p1, Global`p2] + 
    TBsp[Global`p2, Global`p2]))}
