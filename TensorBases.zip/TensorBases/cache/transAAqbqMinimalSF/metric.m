(* Created with the Wolfram Language : www.wolfram.com *)
{{8/Global`Nc - 60*Global`Nc + 52*Global`Nc^3, 0}, 
 {0, (96*(-1 + Global`Nc^2)*((-2 + Global`Nc^2)*TBsp[Global`p1, Global`p1] + 
     (-3 + 2*Global`Nc^2)*TBsp[Global`p1, Global`p3] - 
     TBsp[Global`p1, Global`p4] + (-1 + Global`Nc^2)*
      TBsp[Global`p3, Global`p3] - TBsp[Global`p3, Global`p4]))/Global`Nc}}
