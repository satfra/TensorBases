(* Created with the Wolfram Language : www.wolfram.com *)
{TBdeltaAdj[Global`color, Global`c1, Global`c2]/(-1 + Global`Nc^2)}
