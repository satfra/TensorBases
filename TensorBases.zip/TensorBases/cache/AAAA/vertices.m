(* Created with the Wolfram Language : www.wolfram.com *)
{((-(TBdeltaLorentz[Global`v1, Global`v4]*TBdeltaLorentz[Global`v2, 
        Global`v3]) + TBdeltaLorentz[Global`v1, Global`v3]*
      TBdeltaLorentz[Global`v2, Global`v4])*TBF[Global`color, Global`i$37680, 
     Global`a1, Global`a2]*TBF[Global`color, Global`i$37680, Global`a3, 
     Global`a4] + (-(TBdeltaLorentz[Global`v1, Global`v4]*
       TBdeltaLorentz[Global`v2, Global`v3]) + 
     TBdeltaLorentz[Global`v1, Global`v2]*TBdeltaLorentz[Global`v3, 
       Global`v4])*TBF[Global`color, Global`i$37681, Global`a1, Global`a3]*
    TBF[Global`color, Global`i$37681, Global`a2, Global`a4] + 
   (-(TBdeltaLorentz[Global`v1, Global`v3]*TBdeltaLorentz[Global`v2, 
        Global`v4]) + TBdeltaLorentz[Global`v1, Global`v2]*
      TBdeltaLorentz[Global`v3, Global`v4])*TBF[Global`color, Global`i$37682, 
     Global`a1, Global`a4]*TBF[Global`color, Global`i$37682, Global`a2, 
     Global`a3])*Global`transProj[Global`p1, Global`mu, Global`v1]*
  Global`transProj[Global`p2, Global`nu, Global`v2]*
  Global`transProj[-Global`p1 - Global`p2 - Global`p3, Global`sig, Global`v4]*
  Global`transProj[Global`p3, Global`rho, Global`v3], 
 Global`longProj[-Global`p1 - Global`p2 - Global`p3, Global`sig, Global`v4]*
  Global`longProj[Global`p3, Global`rho, Global`v3]*
  ((-(TBdeltaLorentz[Global`v1, Global`v4]*TBdeltaLorentz[Global`v2, 
        Global`v3]) + TBdeltaLorentz[Global`v1, Global`v3]*
      TBdeltaLorentz[Global`v2, Global`v4])*TBF[Global`color, Global`i$37683, 
     Global`a1, Global`a2]*TBF[Global`color, Global`i$37683, Global`a3, 
     Global`a4] + (-(TBdeltaLorentz[Global`v1, Global`v4]*
       TBdeltaLorentz[Global`v2, Global`v3]) + 
     TBdeltaLorentz[Global`v1, Global`v2]*TBdeltaLorentz[Global`v3, 
       Global`v4])*TBF[Global`color, Global`i$37684, Global`a1, Global`a3]*
    TBF[Global`color, Global`i$37684, Global`a2, Global`a4] + 
   (-(TBdeltaLorentz[Global`v1, Global`v3]*TBdeltaLorentz[Global`v2, 
        Global`v4]) + TBdeltaLorentz[Global`v1, Global`v2]*
      TBdeltaLorentz[Global`v3, Global`v4])*TBF[Global`color, Global`i$37685, 
     Global`a1, Global`a4]*TBF[Global`color, Global`i$37685, Global`a2, 
     Global`a3])*Global`transProj[Global`p1, Global`mu, Global`v1]*
  Global`transProj[Global`p2, Global`nu, Global`v2], 
 Global`longProj[-Global`p1 - Global`p2 - Global`p3, Global`sig, Global`v4]*
  ((-(TBdeltaLorentz[Global`v1, Global`v4]*TBdeltaLorentz[Global`v2, 
        Global`v3]) + TBdeltaLorentz[Global`v1, Global`v3]*
      TBdeltaLorentz[Global`v2, Global`v4])*TBF[Global`color, Global`i$37686, 
     Global`a1, Global`a2]*TBF[Global`color, Global`i$37686, Global`a3, 
     Global`a4] + (-(TBdeltaLorentz[Global`v1, Global`v4]*
       TBdeltaLorentz[Global`v2, Global`v3]) + 
     TBdeltaLorentz[Global`v1, Global`v2]*TBdeltaLorentz[Global`v3, 
       Global`v4])*TBF[Global`color, Global`i$37687, Global`a1, Global`a3]*
    TBF[Global`color, Global`i$37687, Global`a2, Global`a4] + 
   (-(TBdeltaLorentz[Global`v1, Global`v3]*TBdeltaLorentz[Global`v2, 
        Global`v4]) + TBdeltaLorentz[Global`v1, Global`v2]*
      TBdeltaLorentz[Global`v3, Global`v4])*TBF[Global`color, Global`i$37688, 
     Global`a1, Global`a4]*TBF[Global`color, Global`i$37688, Global`a2, 
     Global`a3])*Global`transProj[Global`p1, Global`mu, Global`v1]*
  Global`transProj[Global`p2, Global`nu, Global`v2]*
  Global`transProj[Global`p3, Global`rho, Global`v3]}
