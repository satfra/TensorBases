(* Created with the Wolfram Language : www.wolfram.com *)
{
 (((-(TBdeltaLorentz[Global`v1$2876, Global`v4$2885]*TBdeltaLorentz[
         Global`v2$2879, Global`v3$2882]) + 
      TBdeltaLorentz[Global`v1$2876, Global`v3$2882]*
       TBdeltaLorentz[Global`v2$2879, Global`v4$2885])*
     TBF[Global`color, Global`i$2888, Global`a1, Global`a2]*
     TBF[Global`color, Global`i$2888, Global`a3, Global`a4] + 
    (-(TBdeltaLorentz[Global`v1$2876, Global`v4$2885]*
        TBdeltaLorentz[Global`v2$2879, Global`v3$2882]) + 
      TBdeltaLorentz[Global`v1$2876, Global`v2$2879]*
       TBdeltaLorentz[Global`v3$2882, Global`v4$2885])*
     TBF[Global`color, Global`i$2891, Global`a1, Global`a3]*
     TBF[Global`color, Global`i$2891, Global`a2, Global`a4] + 
    (-(TBdeltaLorentz[Global`v1$2876, Global`v3$2882]*
        TBdeltaLorentz[Global`v2$2879, Global`v4$2885]) + 
      TBdeltaLorentz[Global`v1$2876, Global`v2$2879]*
       TBdeltaLorentz[Global`v3$2882, Global`v4$2885])*
     TBF[Global`color, Global`i$2894, Global`a1, Global`a4]*
     TBF[Global`color, Global`i$2894, Global`a2, Global`a3])*
   TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
   TBsp[Global`p3, Global`p3]*TBsp[Global`p4, Global`p4]*
   Global`transProj[Global`p1, Global`mu, Global`v1$2876]*
   Global`transProj[Global`p2, Global`nu, Global`v2$2879]*
   Global`transProj[Global`p3, Global`rho, Global`v3$2882]*
   Global`transProj[Global`p4, Global`sig, Global`v4$2885])/
  (3*Global`Nc^2*(-1 + Global`Nc^2)*
   (-(TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p4]^2*
      TBsp[Global`p3, Global`p3]) + TBsp[Global`p1, Global`p4]^2*
     (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p3, Global`p3]) + 3*TBsp[Global`p1, Global`p1]*
     TBsp[Global`p2, Global`p3]*TBsp[Global`p2, Global`p4]*
     TBsp[Global`p3, Global`p4] + TBsp[Global`p1, Global`p2]^2*
     TBsp[Global`p3, Global`p4]^2 - TBsp[Global`p1, Global`p1]*
     TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p4]^2 - 
    TBsp[Global`p1, Global`p4]*(TBsp[Global`p1, Global`p3]*
       (TBsp[Global`p2, Global`p3]*TBsp[Global`p2, Global`p4] - 
        3*TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p4]) + 
      TBsp[Global`p1, Global`p2]*(-3*TBsp[Global`p2, Global`p4]*
         TBsp[Global`p3, Global`p3] + TBsp[Global`p2, Global`p3]*
         TBsp[Global`p3, Global`p4])) - 
    (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p3]^2 + 
      (TBsp[Global`p1, Global`p2]^2 - 12*TBsp[Global`p1, Global`p1]*
         TBsp[Global`p2, Global`p2])*TBsp[Global`p3, Global`p3])*
     TBsp[Global`p4, Global`p4] + TBsp[Global`p1, Global`p3]^2*
     (TBsp[Global`p2, Global`p4]^2 - TBsp[Global`p2, Global`p2]*
       TBsp[Global`p4, Global`p4]) + TBsp[Global`p1, Global`p2]*
     TBsp[Global`p1, Global`p3]*
     (-(TBsp[Global`p2, Global`p4]*TBsp[Global`p3, Global`p4]) + 
      3*TBsp[Global`p2, Global`p3]*TBsp[Global`p4, Global`p4])))}
