(* Created with the Wolfram Language : www.wolfram.com *)
{{2/(3*(-1 + Global`Nc^2)), 0}, {0, 2/(-1 + Global`Nc^2)}}
