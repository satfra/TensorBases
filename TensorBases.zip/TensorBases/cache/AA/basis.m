(* Created with the Wolfram Language : www.wolfram.com *)
{(TBdeltaAdj[Global`color, Global`a1, Global`a2]*Global`transProj[-Global`p1, 
    Global`mu, Global`nu])/2, 
 (Global`longProj[-Global`p1, Global`mu, Global`nu]*
   TBdeltaAdj[Global`color, Global`a1, Global`a2])/2}
