(* Created with the Wolfram Language : www.wolfram.com *)
{{(3*(-1 + Global`Nc^2))/2, 0}, {0, (-1 + Global`Nc^2)/2}}
