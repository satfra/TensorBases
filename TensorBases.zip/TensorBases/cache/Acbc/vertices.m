(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  TBvec[Global`p2, Global`nu$1720]*Global`transProj[Global`p1, Global`mu, 
   Global`nu$1720], I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  TBvec[Global`p1, Global`mu]}
