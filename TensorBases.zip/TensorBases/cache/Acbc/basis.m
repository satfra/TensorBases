(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  TBvec[Global`p2, Global`mu], I*TBF[Global`color, Global`a1, Global`a2, 
   Global`a3]*(-TBvec[Global`p2, Global`mu] - TBvec[Global`p3, Global`mu])}
