(* Created with the Wolfram Language : www.wolfram.com *)
{(I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p1, Global`p1]*TBvec[Global`p2, Global`nu$1855]*
   Global`transProj[Global`p1, Global`mu, Global`nu$1855])/
  (Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p2]^2 - 
    TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])), 
 (I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBvec[Global`p1, Global`mu])/(Global`Nc*(-1 + Global`Nc^2)*
   TBsp[Global`p1, Global`p1])}
