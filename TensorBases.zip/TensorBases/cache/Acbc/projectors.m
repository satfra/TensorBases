(* Created with the Wolfram Language : www.wolfram.com *)
{(I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (TBsp[Global`p3, Global`p3]*TBvec[Global`p2, Global`mu] + 
    TBsp[Global`p2, Global`p3]*(TBvec[Global`p2, Global`mu] - 
      TBvec[Global`p3, Global`mu]) - TBsp[Global`p2, Global`p2]*
     TBvec[Global`p3, Global`mu]))/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p2, Global`p3]^2 - TBsp[Global`p2, Global`p2]*
     TBsp[Global`p3, Global`p3])), 
 (I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (TBsp[Global`p3, Global`p3]*TBvec[Global`p2, Global`mu] - 
    TBsp[Global`p2, Global`p3]*TBvec[Global`p3, Global`mu]))/
  (Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p2, Global`p3]^2 - 
    TBsp[Global`p2, Global`p2]*TBsp[Global`p3, Global`p3]))}
