(* Created with the Wolfram Language : www.wolfram.com *)
{{(2 - 3*Global`Nc^2)/(48*Global`Nc^2 - 48*Global`Nc^4), 
  1/(48*Global`Nc^2*(-1 + Global`Nc^2)), 0, 0, 
  -(24*Global`Nc - 24*Global`Nc^3)^(-1), 0, 
  -(12*Global`Nc*Global`Nf - 12*Global`Nc^3*Global`Nf)^(-1), 
  (24*Global`Nc*Global`Nf - 24*Global`Nc^3*Global`Nf)^(-1), 0, 0}, 
 {1/(48*Global`Nc^2*(-1 + Global`Nc^2)), 1/(48*(-1 + Global`Nc^2)), 0, 0, 
  -(24*Global`Nc - 24*Global`Nc^3)^(-1), 0, 
  -(12*Global`Nc*Global`Nf - 12*Global`Nc^3*Global`Nf)^(-1), 
  (24*Global`Nc*Global`Nf - 24*Global`Nc^3*Global`Nf)^(-1), 0, 0}, 
 {0, 0, (Global`Nf*(1 + 2*Global`Nf)*(-16 - 4*(3 + Global`Nc)*Global`Nf + 
     4*(3 + 2*Global`Nc)*Global`Nf^2 + (-13 + 3*Global`Nc)*Global`Nf^3 - 
     8*(1 + Global`Nc)*Global`Nf^4 + 4*(1 + Global`Nc)*Global`Nf^5))/
   (32*Global`Nc*(1 + Global`Nf)*(12 + 8*Global`Nf - 13*Global`Nf^2 + 
     6*Global`Nf^3 + 7*Global`Nf^4 - 2*Global`Nf^5 + 
     2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 3*Global`Nf^2 - 
       5*Global`Nf^3 + 2*Global`Nf^4) + Global`Nc*(4 - 8*Global`Nf - 
       15*Global`Nf^2 + 16*Global`Nf^3 - 7*Global`Nf^4 - 12*Global`Nf^5 + 
       4*Global`Nf^6))), 
  (Global`Nf*(Global`Nc^2*Global`Nf*(4 - 3*Global`Nf^2 + 2*Global`Nf^3) + 
     2*(4 + 4*Global`Nf + Global`Nf^2 + 7*Global`Nf^3 + Global`Nf^4 - 
       2*Global`Nf^5) - Global`Nc*(-8 - 4*Global`Nf + 22*Global`Nf^2 + 
       Global`Nf^3 - 12*Global`Nf^4 + 4*Global`Nf^5)))/
   (32*Global`Nc^2*(1 + Global`Nf)*(12 + 8*Global`Nf - 13*Global`Nf^2 + 
     6*Global`Nf^3 + 7*Global`Nf^4 - 2*Global`Nf^5 + 
     2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 3*Global`Nf^2 - 
       5*Global`Nf^3 + 2*Global`Nf^4) + Global`Nc*(4 - 8*Global`Nf - 
       15*Global`Nf^2 + 16*Global`Nf^3 - 7*Global`Nf^4 - 12*Global`Nf^5 + 
       4*Global`Nf^6))), 0, 
  (Global`Nf*(4 + 4*Global`Nf + (1 - 4*Global`Nc)*Global`Nf^2 + 
     7*Global`Nf^3 + (1 + 3*Global`Nc)*Global`Nf^4 - 
     2*(1 + Global`Nc)*Global`Nf^5))/(8*Global`Nc*(1 + Global`Nf)*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 0, 
  ((-1 + Global`Nc)*Global`Nf*(2 + 5*Global`Nf + 2*Global`Nf^2))/
   (16*Global`Nc^2*(12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 
     7*Global`Nf^4 - 2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*
      (-4 + 4*Global`Nf + 3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  (-4 - 8*Global`Nf + 3*Global`Nf^2 + 4*Global`Nf^3 - 4*Global`Nf^4)/
   (8*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  -1/8*(Global`Nf*(2 + 5*Global`Nf + 2*Global`Nf^2))/
    (Global`Nc*(12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 
      7*Global`Nf^4 - 2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*
       (-4 + 4*Global`Nf + 3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
      Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
        7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6)))}, 
 {0, 0, (Global`Nf*(Global`Nc^2*Global`Nf*(4 - 3*Global`Nf^2 + 
       2*Global`Nf^3) + 2*(4 + 4*Global`Nf + Global`Nf^2 + 7*Global`Nf^3 + 
       Global`Nf^4 - 2*Global`Nf^5) - Global`Nc*(-8 - 4*Global`Nf + 
       22*Global`Nf^2 + Global`Nf^3 - 12*Global`Nf^4 + 4*Global`Nf^5)))/
   (32*Global`Nc^2*(1 + Global`Nf)*(12 + 8*Global`Nf - 13*Global`Nf^2 + 
     6*Global`Nf^3 + 7*Global`Nf^4 - 2*Global`Nf^5 + 
     2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 3*Global`Nf^2 - 
       5*Global`Nf^3 + 2*Global`Nf^4) + Global`Nc*(4 - 8*Global`Nf - 
       15*Global`Nf^2 + 16*Global`Nf^3 - 7*Global`Nf^4 - 12*Global`Nf^5 + 
       4*Global`Nf^6))), 
  (Global`Nf*(4*Global`Nf*(-4 - 8*Global`Nf + Global`Nf^2 + 2*Global`Nf^3) + 
     4*Global`Nc*(4 + 8*Global`Nf + Global`Nf^2 + 4*Global`Nf^3 + 
       3*Global`Nf^4 - 2*Global`Nf^5) + Global`Nc^2*Global`Nf*
      (-20 - 24*Global`Nf + 5*Global`Nf^2 - 18*Global`Nf^3 - 20*Global`Nf^4 + 
       8*Global`Nf^5) + Global`Nc^3*Global`Nf*(-12 + 25*Global`Nf^2 - 
       6*Global`Nf^3 - 12*Global`Nf^4 + 8*Global`Nf^5)))/
   (96*Global`Nc^3*(1 + Global`Nf)*(12 + 8*Global`Nf - 13*Global`Nf^2 + 
     6*Global`Nf^3 + 7*Global`Nf^4 - 2*Global`Nf^5 + 
     2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 3*Global`Nf^2 - 
       5*Global`Nf^3 + 2*Global`Nf^4) + Global`Nc*(4 - 8*Global`Nf - 
       15*Global`Nf^2 + 16*Global`Nf^3 - 7*Global`Nf^4 - 12*Global`Nf^5 + 
       4*Global`Nf^6))), 0, 
  (Global`Nf*(2*Global`Nf*(-4 - 8*Global`Nf + Global`Nf^2 + 2*Global`Nf^3) + 
     Global`Nc*(-4 + 4*Global`Nf + 7*Global`Nf^2 + 3*Global`Nf^3 + 
       Global`Nf^4 - 2*Global`Nf^5) + Global`Nc^2*(-4*Global`Nf^2 + 
       3*Global`Nf^4 - 2*Global`Nf^5)))/(24*Global`Nc^2*(1 + Global`Nf)*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 0, 
  ((-1 + Global`Nc)*Global`Nf*(2 + Global`Nf)*
    (-2 + Global`Nc*(-1 + 2*Global`Nf)))/(16*Global`Nc^3*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  -1/8*((4 - 3*Global`Nf^2 + 2*Global`Nf^3)*
     (-2 + Global`Nc*(-1 + 2*Global`Nf)))/((-2 + Global`Nc)*Global`Nc^2*
     (-1 + Global`Nf)*(12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 
      7*Global`Nf^4 - 2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*
       (-4 + 4*Global`Nf + 3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
      Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
        7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  -1/8*(Global`Nf*(2 + Global`Nf)*(-2 + Global`Nc*(-1 + 2*Global`Nf)))/
    (Global`Nc^2*(12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 
      7*Global`Nf^4 - 2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*
       (-4 + 4*Global`Nf + 3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
      Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
        7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6)))}, 
 {-(24*Global`Nc - 24*Global`Nc^3)^(-1), 
  -(24*Global`Nc - 24*Global`Nc^3)^(-1), 0, 0, 1/(3*(-1 + Global`Nc^2)), 0, 
  1/(6*(-1 + Global`Nc^2)*Global`Nf), 
  (12*Global`Nf - 12*Global`Nc^2*Global`Nf)^(-1), 0, 0}, 
 {0, 0, (Global`Nf*(4 + 4*Global`Nf + (1 - 4*Global`Nc)*Global`Nf^2 + 
     7*Global`Nf^3 + (1 + 3*Global`Nc)*Global`Nf^4 - 
     2*(1 + Global`Nc)*Global`Nf^5))/(8*Global`Nc*(1 + Global`Nf)*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  (Global`Nf*(2*Global`Nf*(-4 - 8*Global`Nf + Global`Nf^2 + 2*Global`Nf^3) + 
     Global`Nc*(-4 + 4*Global`Nf + 7*Global`Nf^2 + 3*Global`Nf^3 + 
       Global`Nf^4 - 2*Global`Nf^5) + Global`Nc^2*(-4*Global`Nf^2 + 
       3*Global`Nf^4 - 2*Global`Nf^5)))/(24*Global`Nc^2*(1 + Global`Nf)*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 0, 
  (Global`Nf*(Global`Nc^3*Global`Nf^3*(4 - 3*Global`Nf^2 + 2*Global`Nf^3) - 
     Global`Nf*(-4 - 8*Global`Nf + Global`Nf^2 + 2*Global`Nf^3) + 
     Global`Nc*(8 + 4*Global`Nf - 6*Global`Nf^2 + Global`Nf^3 + 
       2*Global`Nf^4) + Global`Nc^2*Global`Nf*(-8 - 8*Global`Nf + 
       2*Global`Nf^2 - 6*Global`Nf^3 - 3*Global`Nf^4 + 2*Global`Nf^5)))/
   (6*(-1 + Global`Nc)*Global`Nc*(1 + Global`Nc)*(1 + Global`Nf)*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 0, 
  -1/4*(Global`Nf*(2 + Global`Nf)*(-1 + Global`Nc*Global`Nf))/
    (Global`Nc^2*(12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 
      7*Global`Nf^4 - 2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*
       (-4 + 4*Global`Nf + 3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
      Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
        7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  ((-1 + Global`Nc*Global`Nf)*(4 - 3*Global`Nf^2 + 2*Global`Nf^3))/
   (2*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf)*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  (Global`Nf*(2 + Global`Nf)*(-1 + Global`Nc*Global`Nf))/
   (2*(-1 + Global`Nc)*Global`Nc*(12 + 8*Global`Nf - 13*Global`Nf^2 + 
     6*Global`Nf^3 + 7*Global`Nf^4 - 2*Global`Nf^5 + 
     2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 3*Global`Nf^2 - 
       5*Global`Nf^3 + 2*Global`Nf^4) + Global`Nc*(4 - 8*Global`Nf - 
       15*Global`Nf^2 + 16*Global`Nf^3 - 7*Global`Nf^4 - 12*Global`Nf^5 + 
       4*Global`Nf^6)))}, 
 {-(12*Global`Nc*Global`Nf - 12*Global`Nc^3*Global`Nf)^(-1), 
  -(12*Global`Nc*Global`Nf - 12*Global`Nc^3*Global`Nf)^(-1), 0, 0, 
  1/(6*(-1 + Global`Nc^2)*Global`Nf), 0, 
  1/(3*(-1 + Global`Nc^2)*Global`Nf^2), 
  (6*Global`Nf^2 - 6*Global`Nc^2*Global`Nf^2)^(-1), 0, 0}, 
 {(24*Global`Nc*Global`Nf - 24*Global`Nc^3*Global`Nf)^(-1), 
  (24*Global`Nc*Global`Nf - 24*Global`Nc^3*Global`Nf)^(-1), 
  ((-1 + Global`Nc)*Global`Nf*(2 + 5*Global`Nf + 2*Global`Nf^2))/
   (16*Global`Nc^2*(12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 
     7*Global`Nf^4 - 2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*
      (-4 + 4*Global`Nf + 3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  ((-1 + Global`Nc)*Global`Nf*(2 + Global`Nf)*
    (-2 + Global`Nc*(-1 + 2*Global`Nf)))/(16*Global`Nc^3*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  (12*Global`Nf - 12*Global`Nc^2*Global`Nf)^(-1), 
  -1/4*(Global`Nf*(2 + Global`Nf)*(-1 + Global`Nc*Global`Nf))/
    (Global`Nc^2*(12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 
      7*Global`Nf^4 - 2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*
       (-4 + 4*Global`Nf + 3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
      Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
        7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  (6*Global`Nf^2 - 6*Global`Nc^2*Global`Nf^2)^(-1), 
  (-3*Global`Nf^3*(16 + 8*Global`Nf - 16*Global`Nf^2 - 5*Global`Nf^3 + 
      3*Global`Nf^4) + 3*Global`Nc*Global`Nf^4*(16 + 12*Global`Nf - 
      31*Global`Nf^2 - 11*Global`Nf^3 + 8*Global`Nf^4) - 
    3*Global`Nc^2*Global`Nf^3*(-16 + 8*Global`Nf^2 + 9*Global`Nf^3 - 
      11*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6) + 
    4*Global`Nc^5*Global`Nf^2*(16 - 16*Global`Nf - 24*Global`Nf^2 + 
      24*Global`Nf^3 + 9*Global`Nf^4 - 9*Global`Nf^5 - 7*Global`Nf^6 + 
      7*Global`Nf^7) - Global`Nc^3*(96 + 64*Global`Nf - 176*Global`Nf^2 - 
      48*Global`Nf^3 + 150*Global`Nf^4 + 36*Global`Nf^5 - 159*Global`Nf^6 - 
      49*Global`Nf^7 + 20*Global`Nf^8 + 12*Global`Nf^9) + 
    2*Global`Nc^4*(-16 + 32*Global`Nf + 72*Global`Nf^2 - 80*Global`Nf^3 - 
      21*Global`Nf^4 + 54*Global`Nf^5 + Global`Nf^6 - 62*Global`Nf^7 - 
      30*Global`Nf^8 + 14*Global`Nf^9))/(24*(-1 + Global`Nc)*Global`Nc^3*
    (1 + Global`Nc)*Global`Nf^2*(-4 + 3*Global`Nf^2 + 2*Global`Nf^3)*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  -1/4*((2 + Global`Nf)*(-1 + 2*Global`Nc*Global`Nf))/
    ((-2 + Global`Nc)*Global`Nc^2*(12 + 8*Global`Nf - 13*Global`Nf^2 + 
      6*Global`Nf^3 + 7*Global`Nf^4 - 2*Global`Nf^5 + 
      2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 3*Global`Nf^2 - 
        5*Global`Nf^3 + 2*Global`Nf^4) + Global`Nc*(4 - 8*Global`Nf - 
        15*Global`Nf^2 + 16*Global`Nf^3 - 7*Global`Nf^4 - 12*Global`Nf^5 + 
        4*Global`Nf^6))), 
  -1/4*(Global`Nf*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 
      3*Global`Nf^4 + 2*Global`Nc^2*Global`Nf^2*(4 - 4*Global`Nf - 
        3*Global`Nf^2 + 3*Global`Nf^3) + Global`Nc*(-4 + 16*Global`Nf + 
        15*Global`Nf^2 - 20*Global`Nf^3 - 7*Global`Nf^4 + 6*Global`Nf^5)))/
    (Global`Nc^2*(-4 + 3*Global`Nf^2 + 2*Global`Nf^3)*
     (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
      2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
        3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
      Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
        7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6)))}, 
 {0, 0, (-4 - 8*Global`Nf + 3*Global`Nf^2 + 4*Global`Nf^3 - 4*Global`Nf^4)/
   (8*(-2 + Global`Nc)*Global`Nc*(-1 + Global`Nf)*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  -1/8*((4 - 3*Global`Nf^2 + 2*Global`Nf^3)*
     (-2 + Global`Nc*(-1 + 2*Global`Nf)))/((-2 + Global`Nc)*Global`Nc^2*
     (-1 + Global`Nf)*(12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 
      7*Global`Nf^4 - 2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*
       (-4 + 4*Global`Nf + 3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
      Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
        7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 0, 
  ((-1 + Global`Nc*Global`Nf)*(4 - 3*Global`Nf^2 + 2*Global`Nf^3))/
   (2*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf)*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 0, 
  -1/4*((2 + Global`Nf)*(-1 + 2*Global`Nc*Global`Nf))/
    ((-2 + Global`Nc)*Global`Nc^2*(12 + 8*Global`Nf - 13*Global`Nf^2 + 
      6*Global`Nf^3 + 7*Global`Nf^4 - 2*Global`Nf^5 + 
      2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 3*Global`Nf^2 - 
        5*Global`Nf^3 + 2*Global`Nf^4) + Global`Nc*(4 - 8*Global`Nf - 
        15*Global`Nf^2 + 16*Global`Nf^3 - 7*Global`Nf^4 - 12*Global`Nf^5 + 
        4*Global`Nf^6))), ((-1 + 2*Global`Nc*Global`Nf)*
    (4 - 3*Global`Nf^2 + 2*Global`Nf^3))/(2*(-2 + Global`Nc)^2*
    (-1 + Global`Nc)*Global`Nc*(-1 + Global`Nf)*Global`Nf*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  ((2 + Global`Nf)*(-1 + 2*Global`Nc*Global`Nf))/
   (2*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6)))}, 
 {0, 0, -1/8*(Global`Nf*(2 + 5*Global`Nf + 2*Global`Nf^2))/
    (Global`Nc*(12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 
      7*Global`Nf^4 - 2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*
       (-4 + 4*Global`Nf + 3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
      Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
        7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  -1/8*(Global`Nf*(2 + Global`Nf)*(-2 + Global`Nc*(-1 + 2*Global`Nf)))/
    (Global`Nc^2*(12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 
      7*Global`Nf^4 - 2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*
       (-4 + 4*Global`Nf + 3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
      Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
        7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 0, 
  (Global`Nf*(2 + Global`Nf)*(-1 + Global`Nc*Global`Nf))/
   (2*(-1 + Global`Nc)*Global`Nc*(12 + 8*Global`Nf - 13*Global`Nf^2 + 
     6*Global`Nf^3 + 7*Global`Nf^4 - 2*Global`Nf^5 + 
     2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 3*Global`Nf^2 - 
       5*Global`Nf^3 + 2*Global`Nf^4) + Global`Nc*(4 - 8*Global`Nf - 
       15*Global`Nf^2 + 16*Global`Nf^3 - 7*Global`Nf^4 - 12*Global`Nf^5 + 
       4*Global`Nf^6))), 0, 
  -1/4*(Global`Nf*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 
      3*Global`Nf^4 + 2*Global`Nc^2*Global`Nf^2*(4 - 4*Global`Nf - 
        3*Global`Nf^2 + 3*Global`Nf^3) + Global`Nc*(-4 + 16*Global`Nf + 
        15*Global`Nf^2 - 20*Global`Nf^3 - 7*Global`Nf^4 + 6*Global`Nf^5)))/
    (Global`Nc^2*(-4 + 3*Global`Nf^2 + 2*Global`Nf^3)*
     (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
      2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
        3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
      Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
        7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  ((2 + Global`Nf)*(-1 + 2*Global`Nc*Global`Nf))/
   (2*(-2 + Global`Nc)*(-1 + Global`Nc)*Global`Nc*
    (12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 7*Global`Nf^4 - 
     2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*(-4 + 4*Global`Nf + 
       3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6))), 
  (Global`Nf*(-16 - 8*Global`Nf + 16*Global`Nf^2 + 5*Global`Nf^3 - 
     3*Global`Nf^4 + 4*Global`Nc^3*(-1 + Global`Nf)*Global`Nf^5 + 
     4*Global`Nc^2*Global`Nf*(2 + 2*Global`Nf - 3*Global`Nf^2 - 
       5*Global`Nf^3 + Global`Nf^5) + Global`Nc*(-8 + 16*Global`Nf + 
       18*Global`Nf^2 - 9*Global`Nf^3 - 3*Global`Nf^4 + 4*Global`Nf^5)))/
   (2*(-1 + Global`Nc)*Global`Nc*(1 + Global`Nc)*(-4 + 3*Global`Nf^2 + 
     2*Global`Nf^3)*(12 + 8*Global`Nf - 13*Global`Nf^2 + 6*Global`Nf^3 + 
     7*Global`Nf^4 - 2*Global`Nf^5 + 2*Global`Nc^2*Global`Nf^2*
      (-4 + 4*Global`Nf + 3*Global`Nf^2 - 5*Global`Nf^3 + 2*Global`Nf^4) + 
     Global`Nc*(4 - 8*Global`Nf - 15*Global`Nf^2 + 16*Global`Nf^3 - 
       7*Global`Nf^4 - 12*Global`Nf^5 + 4*Global`Nf^6)))}}
