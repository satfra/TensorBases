(* Created with the Wolfram Language : www.wolfram.com *)
{((I/4)*TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`flavor, Global`F1, Global`F2]*
   TBgamma[Global`mu$363249, Global`d1, Global`d2]*
   TBvec[Global`p1, Global`mu$363249])/(Global`Nc*Global`Nf*
   TBsp[Global`p1, Global`p1]), (TBdeltaDirac[Global`d1, Global`d2]*
   TBdeltaFund[Global`color, Global`A1, Global`A2]*
   TBdeltaFund[Global`flavor, Global`F1, Global`F2])/(4*Global`Nc*Global`Nf)}
