# TensorBases
TensorBases is a Mathematica package which provides common interaction bases used in functional computations, with a specific focus on QCD-related interactions.
