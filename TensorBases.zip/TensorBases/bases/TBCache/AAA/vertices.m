(* Created with the Wolfram Language : www.wolfram.com *)
{I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (TBdeltaLorentz[Global`nui, Global`rhoi]*(-TBvec[Global`p1, Global`mui] - 
     2*TBvec[Global`p2, Global`mui]) + 
   TBdeltaLorentz[Global`mui, Global`rhoi]*(2*TBvec[Global`p1, Global`nui] + 
     TBvec[Global`p2, Global`nui]) + TBdeltaLorentz[Global`mui, Global`nui]*
    (-TBvec[Global`p1, Global`rhoi] + TBvec[Global`p2, Global`rhoi]))*
  Global`transProj[Global`p1, Global`mu, Global`mui]*
  Global`transProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi]*
  Global`transProj[Global`p2, Global`nu, Global`nui], 
 I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (-TBvec[Global`p1, Global`mui] - 2*TBvec[Global`p2, Global`mui])*
  (2*TBvec[Global`p1, Global`nui] + TBvec[Global`p2, Global`nui])*
  (TBvec[Global`p1, Global`rhoi] - TBvec[Global`p2, Global`rhoi])*
  Global`transProj[Global`p1, Global`mu, Global`mui]*
  Global`transProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi]*
  Global`transProj[Global`p2, Global`nu, Global`nui], 
 I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (TBdeltaLorentz[Global`nui, Global`rhoi]*TBsp[Global`p1, Global`p1]*
    (-TBvec[Global`p1, Global`mui] - 2*TBvec[Global`p2, Global`mui]) + 
   TBdeltaLorentz[Global`mui, Global`rhoi]*TBsp[Global`p2, Global`p2]*
    (2*TBvec[Global`p1, Global`nui] + TBvec[Global`p2, Global`nui]) + 
   TBdeltaLorentz[Global`mui, Global`nui]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
    (-TBvec[Global`p1, Global`rhoi] + TBvec[Global`p2, Global`rhoi]))*
  Global`transProj[Global`p1, Global`mu, Global`mui]*
  Global`transProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi]*
  Global`transProj[Global`p2, Global`nu, Global`nui], 
 I*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (TBdeltaLorentz[Global`nui, Global`rhoi]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2])*(-TBvec[Global`p1, Global`mui] - 
     2*TBvec[Global`p2, Global`mui]) + 
   TBdeltaLorentz[Global`mui, Global`rhoi]*(-2*TBsp[Global`p1, Global`p2] - 
     TBsp[Global`p2, Global`p2])*(2*TBvec[Global`p1, Global`nui] + 
     TBvec[Global`p2, Global`nui]) + TBdeltaLorentz[Global`mui, Global`nui]*
    (-TBsp[Global`p1, Global`p1] + TBsp[Global`p2, Global`p2])*
    (-TBvec[Global`p1, Global`rhoi] + TBvec[Global`p2, Global`rhoi]))*
  Global`transProj[Global`p1, Global`mu, Global`mui]*
  Global`transProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi]*
  Global`transProj[Global`p2, Global`nu, Global`nui], 
 I*Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi]*
  TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (TBdeltaLorentz[Global`nui, Global`rhoi]*(-TBvec[Global`p1, Global`mui] - 
     2*TBvec[Global`p2, Global`mui]) + 
   TBdeltaLorentz[Global`mui, Global`rhoi]*(2*TBvec[Global`p1, Global`nui] + 
     TBvec[Global`p2, Global`nui]) + TBdeltaLorentz[Global`mui, Global`nui]*
    (-TBvec[Global`p1, Global`rhoi] + TBvec[Global`p2, Global`rhoi]))*
  Global`transProj[Global`p1, Global`mu, Global`mui]*
  Global`transProj[Global`p2, Global`nu, Global`nui], 
 I*Global`longProj[Global`p2, Global`nu, Global`nui]*
  TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (TBdeltaLorentz[Global`nui, Global`rhoi]*(-TBvec[Global`p1, Global`mui] - 
     2*TBvec[Global`p2, Global`mui]) + 
   TBdeltaLorentz[Global`mui, Global`rhoi]*(2*TBvec[Global`p1, Global`nui] + 
     TBvec[Global`p2, Global`nui]) + TBdeltaLorentz[Global`mui, Global`nui]*
    (-TBvec[Global`p1, Global`rhoi] + TBvec[Global`p2, Global`rhoi]))*
  Global`transProj[Global`p1, Global`mu, Global`mui]*
  Global`transProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi], 
 I*Global`longProj[Global`p1, Global`mu, Global`mui]*
  Global`longProj[Global`p2, Global`nu, Global`nui]*
  TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (TBdeltaLorentz[Global`nui, Global`rhoi]*(-TBvec[Global`p1, Global`mui] - 
     2*TBvec[Global`p2, Global`mui]) + 
   TBdeltaLorentz[Global`mui, Global`rhoi]*(2*TBvec[Global`p1, Global`nui] + 
     TBvec[Global`p2, Global`nui]) + TBdeltaLorentz[Global`mui, Global`nui]*
    (-TBvec[Global`p1, Global`rhoi] + TBvec[Global`p2, Global`rhoi]))*
  Global`transProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi], 
 I*Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi]*
  Global`longProj[Global`p2, Global`nu, Global`nui]*
  TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (TBdeltaLorentz[Global`nui, Global`rhoi]*(-TBvec[Global`p1, Global`mui] - 
     2*TBvec[Global`p2, Global`mui]) + 
   TBdeltaLorentz[Global`mui, Global`rhoi]*(2*TBvec[Global`p1, Global`nui] + 
     TBvec[Global`p2, Global`nui]) + TBdeltaLorentz[Global`mui, Global`nui]*
    (-TBvec[Global`p1, Global`rhoi] + TBvec[Global`p2, Global`rhoi]))*
  Global`transProj[Global`p1, Global`mu, Global`mui], 
 I*Global`longProj[Global`p1, Global`mu, Global`mui]*
  Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi]*
  TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (TBdeltaLorentz[Global`nui, Global`rhoi]*(-TBvec[Global`p1, Global`mui] - 
     2*TBvec[Global`p2, Global`mui]) + 
   TBdeltaLorentz[Global`mui, Global`rhoi]*(2*TBvec[Global`p1, Global`nui] + 
     TBvec[Global`p2, Global`nui]) + TBdeltaLorentz[Global`mui, Global`nui]*
    (-TBvec[Global`p1, Global`rhoi] + TBvec[Global`p2, Global`rhoi]))*
  Global`transProj[Global`p2, Global`nu, Global`nui], 
 I*Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi]*
  TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (-TBvec[Global`p1, Global`mui] - 2*TBvec[Global`p2, Global`mui])*
  (2*TBvec[Global`p1, Global`nui] + TBvec[Global`p2, Global`nui])*
  (TBvec[Global`p1, Global`rhoi] - TBvec[Global`p2, Global`rhoi])*
  Global`transProj[Global`p1, Global`mu, Global`mui]*
  Global`transProj[Global`p2, Global`nu, Global`nui], 
 I*Global`longProj[Global`p2, Global`nu, Global`nui]*
  TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (-TBvec[Global`p1, Global`mui] - 2*TBvec[Global`p2, Global`mui])*
  (2*TBvec[Global`p1, Global`nui] + TBvec[Global`p2, Global`nui])*
  (TBvec[Global`p1, Global`rhoi] - TBvec[Global`p2, Global`rhoi])*
  Global`transProj[Global`p1, Global`mu, Global`mui]*
  Global`transProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi], 
 I*Global`longProj[Global`p1, Global`mu, Global`mui]*
  TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (-TBvec[Global`p1, Global`mui] - 2*TBvec[Global`p2, Global`mui])*
  (2*TBvec[Global`p1, Global`nui] + TBvec[Global`p2, Global`nui])*
  (TBvec[Global`p1, Global`rhoi] - TBvec[Global`p2, Global`rhoi])*
  Global`transProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi]*
  Global`transProj[Global`p2, Global`nu, Global`nui], 
 I*Global`longProj[Global`p1, Global`mu, Global`mui]*
  Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi]*
  Global`longProj[Global`p2, Global`nu, Global`nui]*
  TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (-TBvec[Global`p1, Global`mui] - 2*TBvec[Global`p2, Global`mui])*
  (2*TBvec[Global`p1, Global`nui] + TBvec[Global`p2, Global`nui])*
  (TBvec[Global`p1, Global`rhoi] - TBvec[Global`p2, Global`rhoi]), 
 I*Global`longProj[Global`p1, Global`mu, Global`mui]*
  TBF[Global`color, Global`a1, Global`a2, Global`a3]*
  (TBdeltaLorentz[Global`nui, Global`rhoi]*TBsp[Global`p1, Global`p1]*
    (-TBvec[Global`p1, Global`mui] - 2*TBvec[Global`p2, Global`mui]) + 
   TBdeltaLorentz[Global`mui, Global`rhoi]*TBsp[Global`p2, Global`p2]*
    (2*TBvec[Global`p1, Global`nui] + TBvec[Global`p2, Global`nui]) + 
   TBdeltaLorentz[Global`mui, Global`nui]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
    (-TBvec[Global`p1, Global`rhoi] + TBvec[Global`p2, Global`rhoi]))*
  Global`transProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi]*
  Global`transProj[Global`p2, Global`nu, Global`nui]}
