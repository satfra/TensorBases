(* Created with the Wolfram Language : www.wolfram.com *)
{((I/32)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (4*(TBsp[Global`p1, Global`p1] + TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(-TBsp[Global`p1, Global`p2]^2 + 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (TBsp[Global`p1, Global`p1]^3*TBsp[Global`p2, Global`p2] + 
      2*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]^2*TBsp[Global`p1, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + 5*TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(4*TBsp[Global`p1, Global`p2]^3 + 
        12*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2] + 
        5*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2]^2 + 
        TBsp[Global`p2, Global`p2]^3))*
     (TBdeltaLorentz[Global`nui$8281, Global`rhoi$8284]*
       (TBvec[Global`p1, Global`mui$8278] + 
        2*TBvec[Global`p2, Global`mui$8278]) - 
      TBdeltaLorentz[Global`mui$8278, Global`rhoi$8284]*
       (2*TBvec[Global`p1, Global`nui$8281] + TBvec[Global`p2, 
         Global`nui$8281]) + TBdeltaLorentz[Global`mui$8278, Global`nui$8281]*
       (TBvec[Global`p1, Global`rhoi$8284] - TBvec[Global`p2, 
         Global`rhoi$8284]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$8278]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$8284]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$8281] - (TBsp[Global`p1, Global`p1]^2 + 
      4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
       (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
      2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
      TBsp[Global`p2, Global`p2]^2)*(TBsp[Global`p1, Global`p1]^3*
       TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p1, Global`p2]^2*
       TBsp[Global`p2, Global`p2]*(2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]^2*
       TBsp[Global`p1, Global`p2]*(2*TBsp[Global`p1, Global`p2] + 
        5*TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]*
       (4*TBsp[Global`p1, Global`p2]^3 + 12*TBsp[Global`p1, Global`p2]^2*
         TBsp[Global`p2, Global`p2] + 5*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p2, Global`p2]^2 + TBsp[Global`p2, Global`p2]^3))*
     (TBvec[Global`p1, Global`mui$8298] + 
      2*TBvec[Global`p2, Global`mui$8298])*
     (2*TBvec[Global`p1, Global`nui$8301] + TBvec[Global`p2, 
       Global`nui$8301])*(TBvec[Global`p1, Global`rhoi$8304] - 
      TBvec[Global`p2, Global`rhoi$8304])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$8298]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$8304]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$8301] + 6*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (TBsp[Global`p1, Global`p1]^3*TBsp[Global`p2, Global`p2] + 
      2*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]^2*TBsp[Global`p1, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + 5*TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(4*TBsp[Global`p1, Global`p2]^3 + 
        12*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2] + 
        5*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2]^2 + 
        TBsp[Global`p2, Global`p2]^3))*
     (TBdeltaLorentz[Global`nui$8321, Global`rhoi$8324]*
       TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$8318] + 
        2*TBvec[Global`p2, Global`mui$8318]) - 
      TBdeltaLorentz[Global`mui$8318, Global`rhoi$8324]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$8321] + 
        TBvec[Global`p2, Global`nui$8321]) + 
      TBdeltaLorentz[Global`mui$8318, Global`nui$8321]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(TBvec[Global`p1, Global`rhoi$8324] - 
        TBvec[Global`p2, Global`rhoi$8324]))*Global`transProj[Global`p1, 
      Global`mu, Global`mui$8318]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$8324]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$8321] + 2*(TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2])*(TBsp[Global`p1, Global`p1] - 
      TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p1] + 
      TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
     (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
     (-TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*
     (TBdeltaLorentz[Global`nui$8341, Global`rhoi$8344]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
       (TBvec[Global`p1, Global`mui$8338] + 
        2*TBvec[Global`p2, Global`mui$8338]) + 
      TBdeltaLorentz[Global`mui$8338, Global`rhoi$8344]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
       (2*TBvec[Global`p1, Global`nui$8341] + TBvec[Global`p2, 
         Global`nui$8341]) - TBdeltaLorentz[Global`mui$8338, Global`nui$8341]*
       (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
       (TBvec[Global`p1, Global`rhoi$8344] - TBvec[Global`p2, 
         Global`rhoi$8344]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$8338]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$8344]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$8341]))/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2*(TBsp[Global`p1, Global`p1]^2 + 
     4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
     2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
     TBsp[Global`p2, Global`p2]^2)^2), 
 ((I/128)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (-4*(1 - Global`Nc^2)*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (TBsp[Global`p1, Global`p1]^3*TBsp[Global`p2, Global`p2] + 
      2*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]^2*TBsp[Global`p1, Global`p2]*
       (2*TBsp[Global`p1, Global`p2] + 5*TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(4*TBsp[Global`p1, Global`p2]^3 + 
        12*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2] + 
        5*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2]^2 + 
        TBsp[Global`p2, Global`p2]^3))*
     (-(TBdeltaLorentz[Global`nui$6405, Global`rhoi$6408]*
        (TBvec[Global`p1, Global`mui$6402] + 
         2*TBvec[Global`p2, Global`mui$6402])) + 
      TBdeltaLorentz[Global`mui$6402, Global`rhoi$6408]*
       (2*TBvec[Global`p1, Global`nui$6405] + TBvec[Global`p2, 
         Global`nui$6405]) + TBdeltaLorentz[Global`mui$6402, Global`nui$6405]*
       (-TBvec[Global`p1, Global`rhoi$6408] + TBvec[Global`p2, 
         Global`rhoi$6408]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$6402]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$6408]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$6405] + (1 - Global`Nc)*(1 + Global`Nc)*
     (TBsp[Global`p1, Global`p1]^2 + 4*TBsp[Global`p1, Global`p2]^2 + 
      TBsp[Global`p1, Global`p1]*(2*TBsp[Global`p1, Global`p2] - 
        TBsp[Global`p2, Global`p2]) + 2*TBsp[Global`p1, Global`p2]*
       TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p2]^2)*
     (3*TBsp[Global`p1, Global`p1]^2*TBsp[Global`p2, Global`p2] + 
      2*TBsp[Global`p1, Global`p2]^2*(TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]*
       (2*TBsp[Global`p1, Global`p2]^2 + 8*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p2, Global`p2] + 3*TBsp[Global`p2, Global`p2]^2))*
     (TBvec[Global`p1, Global`mui$6422] + 
      2*TBvec[Global`p2, Global`mui$6422])*
     (2*TBvec[Global`p1, Global`nui$6425] + TBvec[Global`p2, 
       Global`nui$6425])*(TBvec[Global`p1, Global`rhoi$6428] - 
      TBvec[Global`p2, Global`rhoi$6428])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$6422]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$6428]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$6425] + 2*(1 - Global`Nc)*(1 + Global`Nc)*
     (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p1]^2*
       TBsp[Global`p2, Global`p2] + 8*TBsp[Global`p1, Global`p2]^2*
       (TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(8*TBsp[Global`p1, Global`p2]^2 + 
        10*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
        TBsp[Global`p2, Global`p2]^2))*
     (-(TBdeltaLorentz[Global`nui$6445, Global`rhoi$6448]*
        TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$6442] + 
         2*TBvec[Global`p2, Global`mui$6442])) + 
      TBdeltaLorentz[Global`mui$6442, Global`rhoi$6448]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$6445] + 
        TBvec[Global`p2, Global`nui$6445]) + 
      TBdeltaLorentz[Global`mui$6442, Global`nui$6445]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(-TBvec[Global`p1, Global`rhoi$6448] + 
        TBvec[Global`p2, Global`rhoi$6448]))*Global`transProj[Global`p1, 
      Global`mu, Global`mui$6442]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$6448]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$6445] - 2*(1 - Global`Nc)*(1 + Global`Nc)*
     (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
     (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
     (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
     (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*
     (-(TBdeltaLorentz[Global`nui$6465, Global`rhoi$6468]*
        (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
        (TBvec[Global`p1, Global`mui$6462] + 
         2*TBvec[Global`p2, Global`mui$6462])) - 
      TBdeltaLorentz[Global`mui$6462, Global`rhoi$6468]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
       (2*TBvec[Global`p1, Global`nui$6465] + TBvec[Global`p2, 
         Global`nui$6465]) + TBdeltaLorentz[Global`mui$6462, Global`nui$6465]*
       (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
       (TBvec[Global`p1, Global`rhoi$6468] - TBvec[Global`p2, 
         Global`rhoi$6468]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$6462]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$6468]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$6465]))/((-1 + Global`Nc)*Global`Nc*(1 + Global`Nc)*
   (-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p2]^2 - 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])^3*
   (TBsp[Global`p1, Global`p1]^2 + 4*TBsp[Global`p1, Global`p2]^2 + 
    TBsp[Global`p1, Global`p1]*(2*TBsp[Global`p1, Global`p2] - 
      TBsp[Global`p2, Global`p2]) + 2*TBsp[Global`p1, Global`p2]*
     TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p2]^2)), 
 ((-1/64*I)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (-12*(TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p1]^3*
       TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p1, Global`p2]^2*
       TBsp[Global`p2, Global`p2]*(2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]^2*
       TBsp[Global`p1, Global`p2]*(2*TBsp[Global`p1, Global`p2] + 
        5*TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]*
       (4*TBsp[Global`p1, Global`p2]^3 + 12*TBsp[Global`p1, Global`p2]^2*
         TBsp[Global`p2, Global`p2] + 5*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p2, Global`p2]^2 + TBsp[Global`p2, Global`p2]^3))*
     (TBdeltaLorentz[Global`nui$6819, Global`rhoi$6822]*
       (TBvec[Global`p1, Global`mui$6816] + 
        2*TBvec[Global`p2, Global`mui$6816]) - 
      TBdeltaLorentz[Global`mui$6816, Global`rhoi$6822]*
       (2*TBvec[Global`p1, Global`nui$6819] + TBvec[Global`p2, 
         Global`nui$6819]) + TBdeltaLorentz[Global`mui$6816, Global`nui$6819]*
       (TBvec[Global`p1, Global`rhoi$6822] - TBvec[Global`p2, 
         Global`rhoi$6822]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$6816]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$6822]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$6819] - (TBsp[Global`p1, Global`p1]^2 + 
      4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
       (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
      2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
      TBsp[Global`p2, Global`p2]^2)*(TBsp[Global`p1, Global`p1]^2*
       TBsp[Global`p2, Global`p2] + 8*TBsp[Global`p1, Global`p2]^2*
       (TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(8*TBsp[Global`p1, Global`p2]^2 + 
        10*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
        TBsp[Global`p2, Global`p2]^2))*(TBvec[Global`p1, Global`mui$6836] + 
      2*TBvec[Global`p2, Global`mui$6836])*
     (2*TBvec[Global`p1, Global`nui$6839] + TBvec[Global`p2, 
       Global`nui$6839])*(TBvec[Global`p1, Global`rhoi$6842] - 
      TBvec[Global`p2, Global`rhoi$6842])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$6836]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$6842]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$6839] + 2*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (2*TBsp[Global`p1, Global`p1]^3 + 3*TBsp[Global`p1, Global`p1]^2*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
      3*TBsp[Global`p1, Global`p1]*(12*TBsp[Global`p1, Global`p2]^2 + 
        12*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
        TBsp[Global`p2, Global`p2]^2) + 2*(16*TBsp[Global`p1, Global`p2]^3 + 
        18*TBsp[Global`p1, Global`p2]^2*TBsp[Global`p2, Global`p2] + 
        3*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2]^2 + 
        TBsp[Global`p2, Global`p2]^3))*
     (TBdeltaLorentz[Global`nui$6859, Global`rhoi$6862]*
       TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$6856] + 
        2*TBvec[Global`p2, Global`mui$6856]) - 
      TBdeltaLorentz[Global`mui$6856, Global`rhoi$6862]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$6859] + 
        TBvec[Global`p2, Global`nui$6859]) + 
      TBdeltaLorentz[Global`mui$6856, Global`nui$6859]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(TBvec[Global`p1, Global`rhoi$6862] - 
        TBvec[Global`p2, Global`rhoi$6862]))*Global`transProj[Global`p1, 
      Global`mu, Global`mui$6856]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$6862]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$6859] + 6*(TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2])*(TBsp[Global`p1, Global`p1] - 
      TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(-TBsp[Global`p1, Global`p2]^2 + 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (TBdeltaLorentz[Global`nui$6879, Global`rhoi$6882]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
       (TBvec[Global`p1, Global`mui$6876] + 
        2*TBvec[Global`p2, Global`mui$6876]) + 
      TBdeltaLorentz[Global`mui$6876, Global`rhoi$6882]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
       (2*TBvec[Global`p1, Global`nui$6879] + TBvec[Global`p2, 
         Global`nui$6879]) - TBdeltaLorentz[Global`mui$6876, Global`nui$6879]*
       (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
       (TBvec[Global`p1, Global`rhoi$6882] - TBvec[Global`p2, 
         Global`rhoi$6882]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$6876]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$6882]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$6879]))/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2*(TBsp[Global`p1, Global`p1]^2 + 
     4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
     2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
     TBsp[Global`p2, Global`p2]^2)^2), 
 ((I/64)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (4*(TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
     (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
     (TBsp[Global`p1, Global`p1] + TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (-(TBdeltaLorentz[Global`nui$5204, Global`rhoi$5207]*
        (TBvec[Global`p1, Global`mui$5201] + 
         2*TBvec[Global`p2, Global`mui$5201])) + 
      TBdeltaLorentz[Global`mui$5201, Global`rhoi$5207]*
       (2*TBvec[Global`p1, Global`nui$5204] + TBvec[Global`p2, 
         Global`nui$5204]) + TBdeltaLorentz[Global`mui$5201, Global`nui$5204]*
       (-TBvec[Global`p1, Global`rhoi$5207] + TBvec[Global`p2, 
         Global`rhoi$5207]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$5201]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$5207]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$5204] - (TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2])*(TBsp[Global`p1, Global`p1] - 
      TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p1]^2 + 
      4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
       (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
      2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
      TBsp[Global`p2, Global`p2]^2)*(TBvec[Global`p1, Global`mui$5221] + 
      2*TBvec[Global`p2, Global`mui$5221])*
     (2*TBvec[Global`p1, Global`nui$5224] + TBvec[Global`p2, 
       Global`nui$5224])*(TBvec[Global`p1, Global`rhoi$5227] - 
      TBvec[Global`p2, Global`rhoi$5227])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$5221]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$5227]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$5224] - 6*(TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2])*(TBsp[Global`p1, Global`p1] - 
      TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (-(TBdeltaLorentz[Global`nui$5244, Global`rhoi$5247]*
        TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$5241] + 
         2*TBvec[Global`p2, Global`mui$5241])) + 
      TBdeltaLorentz[Global`mui$5241, Global`rhoi$5247]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$5244] + 
        TBvec[Global`p2, Global`nui$5244]) + 
      TBdeltaLorentz[Global`mui$5241, Global`nui$5244]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(-TBvec[Global`p1, Global`rhoi$5247] + 
        TBvec[Global`p2, Global`rhoi$5247]))*Global`transProj[Global`p1, 
      Global`mu, Global`mui$5241]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$5247]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$5244] + 2*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (2*TBsp[Global`p1, Global`p1]^3 + TBsp[Global`p1, Global`p1]^2*
       (6*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
      TBsp[Global`p1, Global`p1]*(4*TBsp[Global`p1, Global`p2]^2 - 
        4*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] - 
        TBsp[Global`p2, Global`p2]^2) + 2*TBsp[Global`p2, Global`p2]*
       (2*TBsp[Global`p1, Global`p2]^2 + 3*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p2]^2))*
     (-(TBdeltaLorentz[Global`nui$5264, Global`rhoi$5267]*
        (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])*
        (TBvec[Global`p1, Global`mui$5261] + 
         2*TBvec[Global`p2, Global`mui$5261])) - 
      TBdeltaLorentz[Global`mui$5261, Global`rhoi$5267]*
       (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
       (2*TBvec[Global`p1, Global`nui$5264] + TBvec[Global`p2, 
         Global`nui$5264]) + TBdeltaLorentz[Global`mui$5261, Global`nui$5264]*
       (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])*
       (TBvec[Global`p1, Global`rhoi$5267] - TBvec[Global`p2, 
         Global`rhoi$5267]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$5261]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$5267]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$5264]))/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2*(TBsp[Global`p1, Global`p1]^2 + 
     4*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      (2*TBsp[Global`p1, Global`p2] - TBsp[Global`p2, Global`p2]) + 
     2*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
     TBsp[Global`p2, Global`p2]^2)^2), 
 ((-1/8*I)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
    TBsp[Global`p2, Global`p2])*
   (4*Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi$4419]*
     (-(TBdeltaLorentz[Global`nui$4416, Global`rhoi$4419]*
        (TBvec[Global`p1, Global`mui$4413] + 
         2*TBvec[Global`p2, Global`mui$4413])) + 
      TBdeltaLorentz[Global`mui$4413, Global`rhoi$4419]*
       (2*TBvec[Global`p1, Global`nui$4416] + TBvec[Global`p2, 
         Global`nui$4416]) + TBdeltaLorentz[Global`mui$4413, Global`nui$4416]*
       (-TBvec[Global`p1, Global`rhoi$4419] + TBvec[Global`p2, 
         Global`rhoi$4419]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$4413]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$4416] + (Global`longProj[-Global`p1 - Global`p2, Global`rho, 
       Global`rhoi$4519]*TBsp[Global`p1, Global`p2]*
      (TBvec[Global`p1, Global`mui$4513] + 
       2*TBvec[Global`p2, Global`mui$4513])*
      (2*TBvec[Global`p1, Global`nui$4516] + TBvec[Global`p2, 
        Global`nui$4516])*(TBvec[Global`p1, Global`rhoi$4519] - 
       TBvec[Global`p2, Global`rhoi$4519])*Global`transProj[Global`p1, 
       Global`mu, Global`mui$4513]*Global`transProj[Global`p2, Global`nu, 
       Global`nui$4516])/(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])))/
  (Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] - 
     TBsp[Global`p2, Global`p2])^2), 
 ((-1/8*I)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p2, Global`p2]*
   (4*Global`longProj[Global`p2, Global`nu, Global`nui$4423]*
     (-(TBdeltaLorentz[Global`nui$4423, Global`rhoi$4426]*
        (TBvec[Global`p1, Global`mui$4420] + 
         2*TBvec[Global`p2, Global`mui$4420])) + 
      TBdeltaLorentz[Global`mui$4420, Global`rhoi$4426]*
       (2*TBvec[Global`p1, Global`nui$4423] + TBvec[Global`p2, 
         Global`nui$4423]) + TBdeltaLorentz[Global`mui$4420, Global`nui$4423]*
       (-TBvec[Global`p1, Global`rhoi$4426] + TBvec[Global`p2, 
         Global`rhoi$4426]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$4420]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$4426] + (Global`longProj[Global`p2, Global`nu, 
       Global`nui$4523]*(TBsp[Global`p1, Global`p1] + 
       TBsp[Global`p1, Global`p2])*(TBvec[Global`p1, Global`mui$4520] + 
       2*TBvec[Global`p2, Global`mui$4520])*
      (2*TBvec[Global`p1, Global`nui$4523] + TBvec[Global`p2, 
        Global`nui$4523])*(TBvec[Global`p1, Global`rhoi$4526] - 
       TBvec[Global`p2, Global`rhoi$4526])*Global`transProj[Global`p1, 
       Global`mu, Global`mui$4520]*Global`transProj[-Global`p1 - Global`p2, 
       Global`rho, Global`rhoi$4526])/(-TBsp[Global`p1, Global`p2]^2 + 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])))/
  (Global`Nc*(-1 + Global`Nc^2)*(2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])^2), 
 (I*Global`longProj[Global`p1, Global`mu, Global`mui$4449]*
   Global`longProj[Global`p2, Global`nu, Global`nui$4452]*
   TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
   (TBdeltaLorentz[Global`nui$4452, Global`rhoi$4455]*
     (TBvec[Global`p1, Global`mui$4449] + 
      2*TBvec[Global`p2, Global`mui$4449]) - 
    TBdeltaLorentz[Global`mui$4449, Global`rhoi$4455]*
     (2*TBvec[Global`p1, Global`nui$4452] + TBvec[Global`p2, 
       Global`nui$4452]) + TBdeltaLorentz[Global`mui$4449, Global`nui$4452]*
     (TBvec[Global`p1, Global`rhoi$4455] - TBvec[Global`p2, 
       Global`rhoi$4455]))*Global`transProj[-Global`p1 - Global`p2, 
    Global`rho, Global`rhoi$4455])/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
    TBsp[Global`p2, Global`p2])*(-TBsp[Global`p1, Global`p2]^2 + 
    TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])), 
 (I*Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi$3354]*
   Global`longProj[Global`p2, Global`nu, Global`nui$3351]*
   TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
    2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
   (TBdeltaLorentz[Global`nui$3351, Global`rhoi$3354]*
     (TBvec[Global`p1, Global`mui$3348] + 
      2*TBvec[Global`p2, Global`mui$3348]) - 
    TBdeltaLorentz[Global`mui$3348, Global`rhoi$3354]*
     (2*TBvec[Global`p1, Global`nui$3351] + TBvec[Global`p2, 
       Global`nui$3351]) + TBdeltaLorentz[Global`mui$3348, Global`nui$3351]*
     (TBvec[Global`p1, Global`rhoi$3354] - TBvec[Global`p2, 
       Global`rhoi$3354]))*Global`transProj[Global`p1, Global`mu, 
    Global`mui$3348])/(Global`Nc*(-1 + Global`Nc^2)*
   TBsp[Global`p1, Global`p1]*(-TBsp[Global`p1, Global`p2]^2 + 
    TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])), 
 (I*Global`longProj[Global`p1, Global`mu, Global`mui$3128]*
   Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi$3134]*
   TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p1, Global`p1]*(TBsp[Global`p1, Global`p1] + 
    2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
   (TBdeltaLorentz[Global`nui$3131, Global`rhoi$3134]*
     (TBvec[Global`p1, Global`mui$3128] + 
      2*TBvec[Global`p2, Global`mui$3128]) - 
    TBdeltaLorentz[Global`mui$3128, Global`rhoi$3134]*
     (2*TBvec[Global`p1, Global`nui$3131] + TBvec[Global`p2, 
       Global`nui$3131]) + TBdeltaLorentz[Global`mui$3128, Global`nui$3131]*
     (TBvec[Global`p1, Global`rhoi$3134] - TBvec[Global`p2, 
       Global`rhoi$3134]))*Global`transProj[Global`p2, Global`nu, 
    Global`nui$3131])/(Global`Nc*(-1 + Global`Nc^2)*
   TBsp[Global`p2, Global`p2]*(-TBsp[Global`p1, Global`p2]^2 + 
    TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])), 
 ((I/32)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
    TBsp[Global`p2, Global`p2])*
   (4*Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi$2956]*
     TBsp[Global`p1, Global`p2]*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (-(TBdeltaLorentz[Global`nui$2953, Global`rhoi$2956]*
        (TBvec[Global`p1, Global`mui$2950] + 
         2*TBvec[Global`p2, Global`mui$2950])) + 
      TBdeltaLorentz[Global`mui$2950, Global`rhoi$2956]*
       (2*TBvec[Global`p1, Global`nui$2953] + TBvec[Global`p2, 
         Global`nui$2953]) + TBdeltaLorentz[Global`mui$2950, Global`nui$2953]*
       (-TBvec[Global`p1, Global`rhoi$2956] + TBvec[Global`p2, 
         Global`rhoi$2956]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$2950]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$2953] + Global`longProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$3056]*(TBsp[Global`p1, Global`p2]^2 + 
      2*TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
     (TBvec[Global`p1, Global`mui$3050] + 
      2*TBvec[Global`p2, Global`mui$3050])*
     (2*TBvec[Global`p1, Global`nui$3053] + TBvec[Global`p2, 
       Global`nui$3053])*(TBvec[Global`p1, Global`rhoi$3056] - 
      TBvec[Global`p2, Global`rhoi$3056])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$3050]*Global`transProj[Global`p2, Global`nu, 
      Global`nui$3053]))/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])^2*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2), 
 ((-1/32*I)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p2, Global`p2]*
   (4*Global`longProj[Global`p2, Global`nu, Global`nui$2760]*
     (TBsp[Global`p1, Global`p1] + TBsp[Global`p1, Global`p2])*
     (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*
     (-(TBdeltaLorentz[Global`nui$2760, Global`rhoi$2763]*
        (TBvec[Global`p1, Global`mui$2757] + 
         2*TBvec[Global`p2, Global`mui$2757])) + 
      TBdeltaLorentz[Global`mui$2757, Global`rhoi$2763]*
       (2*TBvec[Global`p1, Global`nui$2760] + TBvec[Global`p2, 
         Global`nui$2760]) + TBdeltaLorentz[Global`mui$2757, Global`nui$2760]*
       (-TBvec[Global`p1, Global`rhoi$2763] + TBvec[Global`p2, 
         Global`rhoi$2763]))*Global`transProj[Global`p1, Global`mu, 
      Global`mui$2757]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
      Global`rhoi$2763] - Global`longProj[Global`p2, Global`nu, 
      Global`nui$2861]*(3*TBsp[Global`p1, Global`p1]^2 + 
      TBsp[Global`p1, Global`p2]^2 + 2*TBsp[Global`p1, Global`p1]*
       (3*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]))*
     (TBvec[Global`p1, Global`mui$2858] + 
      2*TBvec[Global`p2, Global`mui$2858])*
     (2*TBvec[Global`p1, Global`nui$2861] + TBvec[Global`p2, 
       Global`nui$2861])*(TBvec[Global`p1, Global`rhoi$2864] - 
      TBvec[Global`p2, Global`rhoi$2864])*Global`transProj[Global`p1, 
      Global`mu, Global`mui$2858]*Global`transProj[-Global`p1 - Global`p2, 
      Global`rho, Global`rhoi$2864]))/(Global`Nc*(-1 + Global`Nc^2)*
   (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])^2*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2), 
 ((I/32)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   (Global`longProj[Global`p1, Global`mu, Global`mui$2811]*
     (4*TBsp[Global`p1, Global`p2]^4 + 2*TBsp[Global`p1, Global`p1]^3*
       TBsp[Global`p2, Global`p2] - 4*TBsp[Global`p1, Global`p1]*
       TBsp[Global`p1, Global`p2]^2*(TBsp[Global`p1, Global`p2] + 
        3*TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]^2*
       (TBsp[Global`p1, Global`p2]^2 + 10*TBsp[Global`p1, Global`p2]*
         TBsp[Global`p2, Global`p2] + 11*TBsp[Global`p2, Global`p2]^2))*
     (TBvec[Global`p1, Global`mui$2811] + 
      2*TBvec[Global`p2, Global`mui$2811])*
     (2*TBvec[Global`p1, Global`nui$2814] + TBvec[Global`p2, 
       Global`nui$2814])*(TBvec[Global`p1, Global`rhoi$2817] - 
      TBvec[Global`p2, Global`rhoi$2817])*Global`transProj[
      -Global`p1 - Global`p2, Global`rho, Global`rhoi$2817]*
     Global`transProj[Global`p2, Global`nu, Global`nui$2814] + 
    4*Global`longProj[Global`p1, Global`mu, Global`mui$2851]*
     (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*(TBsp[Global`p1, Global`p2] + 
        3*TBsp[Global`p2, Global`p2]))*
     (-(TBdeltaLorentz[Global`nui$2854, Global`rhoi$2857]*
        TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$2851] + 
         2*TBvec[Global`p2, Global`mui$2851])) + 
      TBdeltaLorentz[Global`mui$2851, Global`rhoi$2857]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$2854] + 
        TBvec[Global`p2, Global`nui$2854]) + 
      TBdeltaLorentz[Global`mui$2851, Global`nui$2854]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(-TBvec[Global`p1, Global`rhoi$2857] + 
        TBvec[Global`p2, Global`rhoi$2857]))*Global`transProj[
      -Global`p1 - Global`p2, Global`rho, Global`rhoi$2857]*
     Global`transProj[Global`p2, Global`nu, Global`nui$2854]))/
  (Global`Nc*(-1 + Global`Nc^2)*TBsp[Global`p1, Global`p1]*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])^2*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])^2), 
 (I*Global`longProj[Global`p1, Global`mu, Global`mui$2490]*
   Global`longProj[-Global`p1 - Global`p2, Global`rho, Global`rhoi$2496]*
   Global`longProj[Global`p2, Global`nu, Global`nui$2493]*
   TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
    TBsp[Global`p2, Global`p2])*(TBvec[Global`p1, Global`mui$2490] + 
    2*TBvec[Global`p2, Global`mui$2490])*
   (2*TBvec[Global`p1, Global`nui$2493] + TBvec[Global`p2, Global`nui$2493])*
   (TBvec[Global`p1, Global`rhoi$2496] - TBvec[Global`p2, Global`rhoi$2496]))/
  (Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2])^2*
   (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])^2*
   (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])^2), 
 ((I/8)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   ((Global`longProj[Global`p1, Global`mu, Global`mui$2444]*
      (-2*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
        (TBsp[Global`p1, Global`p2] + 3*TBsp[Global`p2, Global`p2]))*
      (TBvec[Global`p1, Global`mui$2444] + 
       2*TBvec[Global`p2, Global`mui$2444])*
      (2*TBvec[Global`p1, Global`nui$2447] + TBvec[Global`p2, 
        Global`nui$2447])*(TBvec[Global`p1, Global`rhoi$2450] - 
       TBvec[Global`p2, Global`rhoi$2450])*Global`transProj[
       -Global`p1 - Global`p2, Global`rho, Global`rhoi$2450]*
      Global`transProj[Global`p2, Global`nu, Global`nui$2447])/
     (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2]) - 4*Global`longProj[Global`p1, Global`mu, 
      Global`mui$2484]*(-(TBdeltaLorentz[Global`nui$2487, Global`rhoi$2490]*
        TBsp[Global`p1, Global`p1]*(TBvec[Global`p1, Global`mui$2484] + 
         2*TBvec[Global`p2, Global`mui$2484])) + 
      TBdeltaLorentz[Global`mui$2484, Global`rhoi$2490]*
       TBsp[Global`p2, Global`p2]*(2*TBvec[Global`p1, Global`nui$2487] + 
        TBvec[Global`p2, Global`nui$2487]) + 
      TBdeltaLorentz[Global`mui$2484, Global`nui$2487]*
       (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])*(-TBvec[Global`p1, Global`rhoi$2490] + 
        TBvec[Global`p2, Global`rhoi$2490]))*Global`transProj[
      -Global`p1 - Global`p2, Global`rho, Global`rhoi$2490]*
     Global`transProj[Global`p2, Global`nu, Global`nui$2487]))/
  (Global`Nc*(-1 + Global`Nc^2)*TBsp[Global`p1, Global`p1]*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])^2)}
