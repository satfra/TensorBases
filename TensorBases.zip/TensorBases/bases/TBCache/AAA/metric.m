(* Created with the Wolfram Language : www.wolfram.com *)
{{(4*Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p2]^2 - 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
    (3*TBsp[Global`p1, Global`p1]^2 + TBsp[Global`p1, Global`p2]^2 + 
     6*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] + 
     3*TBsp[Global`p2, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      (6*TBsp[Global`p1, Global`p2] + 8*TBsp[Global`p2, Global`p2])))/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), (-16*Global`Nc*(-1 + Global`Nc^2)*
    (TBsp[Global`p1, Global`p1] + TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])^2)/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), (-8*Global`Nc*(-1 + Global`Nc^2)*
    (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])*(-4*TBsp[Global`p1, Global`p1]^2*
      TBsp[Global`p2, Global`p2] + TBsp[Global`p1, Global`p2]^2*
      (TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]) + 
     TBsp[Global`p1, Global`p1]*(TBsp[Global`p1, Global`p2]^2 - 
       7*TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2] - 
       4*TBsp[Global`p2, Global`p2]^2)))/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])), 
  (8*Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2])*(TBsp[Global`p1, Global`p1] - 
     TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])*(-TBsp[Global`p1, Global`p2]^2 + 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]))/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(-16*Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] + 
     TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])*
    (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])^2)/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])), 
  (64*Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])^3)/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), (32*Global`Nc*(-1 + Global`Nc^2)*
    (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])^3)/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])), 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0, 0}, 
 {(-8*Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p2]^2 - 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
    (-4*TBsp[Global`p1, Global`p1]^2*TBsp[Global`p2, Global`p2] + 
     TBsp[Global`p1, Global`p2]^2*(TBsp[Global`p1, Global`p2] + 
       TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]*
      (TBsp[Global`p1, Global`p2]^2 - 7*TBsp[Global`p1, Global`p2]*
        TBsp[Global`p2, Global`p2] - 4*TBsp[Global`p2, Global`p2]^2)))/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), (32*Global`Nc*(-1 + Global`Nc^2)*
    (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])^3)/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])), 
  (16*Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p2]^2 - 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
    (TBsp[Global`p1, Global`p2]^4 + 3*TBsp[Global`p1, Global`p1]*
      TBsp[Global`p1, Global`p2]*TBsp[Global`p2, Global`p2]*
      (TBsp[Global`p1, Global`p1] + TBsp[Global`p2, Global`p2]) + 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
      (TBsp[Global`p1, Global`p1]^2 + 3*TBsp[Global`p1, Global`p1]*
        TBsp[Global`p2, Global`p2] + TBsp[Global`p2, Global`p2]^2)))/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {(8*Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2])*(TBsp[Global`p1, Global`p1] - 
     TBsp[Global`p2, Global`p2])*(2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])*(-TBsp[Global`p1, Global`p2]^2 + 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]))/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), 0, 0, 
  (16*(-1 + Global`Nc)*Global`Nc*(1 + Global`Nc)*
    (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p1]^3*
      TBsp[Global`p2, Global`p2] + 2*TBsp[Global`p1, Global`p2]^2*
      TBsp[Global`p2, Global`p2]*(2*TBsp[Global`p1, Global`p2] + 
       TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]^2*
      TBsp[Global`p1, Global`p2]*(2*TBsp[Global`p1, Global`p2] + 
       5*TBsp[Global`p2, Global`p2]) + TBsp[Global`p1, Global`p1]*
      (4*TBsp[Global`p1, Global`p2]^3 + 12*TBsp[Global`p1, Global`p2]^2*
        TBsp[Global`p2, Global`p2] + 5*TBsp[Global`p1, Global`p2]*
        TBsp[Global`p2, Global`p2]^2 + TBsp[Global`p2, Global`p2]^3)))/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, -((Global`Nc*(-1 + Global`Nc^2)*
     (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])^2*
     (TBsp[Global`p1, Global`p2]^2 + 2*TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2]))/(TBsp[Global`p1, Global`p1]*
     TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]))), 0, 0, 0, 
  0, (4*Global`Nc*(-1 + Global`Nc^2)*TBsp[Global`p1, Global`p2]*
    (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])^2*
    (-TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2]))/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])), 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, -((Global`Nc*(-1 + Global`Nc^2)*
     (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])^2*
     (3*TBsp[Global`p1, Global`p1]^2 + TBsp[Global`p1, Global`p2]^2 + 
      2*TBsp[Global`p1, Global`p1]*(3*TBsp[Global`p1, Global`p2] + 
        TBsp[Global`p2, Global`p2])))/(TBsp[Global`p1, Global`p1]*
     TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]))), 0, 0, 0, 
  0, (-4*Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] + 
     TBsp[Global`p1, Global`p2])*(2*TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])^2*(-TBsp[Global`p1, Global`p2]^2 + 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]))/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), 0, 0, 0}, 
 {0, 0, 0, 0, 0, 0, (Global`Nc*(-1 + Global`Nc^2)*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])*(TBsp[Global`p1, Global`p2]^2 - 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]))/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]), 0, 0, 0, 0, 0, 0, 
  0}, {0, 0, 0, 0, 0, 0, 0, (Global`Nc*(-1 + Global`Nc^2)*
    TBsp[Global`p1, Global`p1]*(TBsp[Global`p1, Global`p2]^2 - 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]))/
   (TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])), 0, 0, 0, 0, 
  0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 
  (Global`Nc*(-1 + Global`Nc^2)*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2]))/(TBsp[Global`p1, Global`p1]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), 0, 0, 0, 0, 0}, 
 {0, 0, 0, 0, (4*Global`Nc*(-1 + Global`Nc^2)*TBsp[Global`p1, Global`p2]*
    (TBsp[Global`p1, Global`p1] - TBsp[Global`p2, Global`p2])^2*
    (-TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2]))/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])), 0, 0, 0, 0, 
  (-16*Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] - 
      TBsp[Global`p2, Global`p2])^2*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])^2)/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), 0, 0, 0, 0}, 
 {0, 0, 0, 0, 0, (-4*Global`Nc*(-1 + Global`Nc^2)*
    (TBsp[Global`p1, Global`p1] + TBsp[Global`p1, Global`p2])*
    (2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])^2*
    (-TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2]))/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])), 0, 0, 0, 0, 
  (-16*Global`Nc*(-1 + Global`Nc^2)*(2*TBsp[Global`p1, Global`p2] + 
      TBsp[Global`p2, Global`p2])^2*(TBsp[Global`p1, Global`p2]^2 - 
      TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])^2)/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2])), 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  0, (-16*Global`Nc*(-1 + Global`Nc^2)*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])^2*
    (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
       TBsp[Global`p2, Global`p2])^2)/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])), 0, 
  (-4*Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2])^2*(-TBsp[Global`p1, Global`p2]^2 + 
     TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2])*
    (-2*TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      (TBsp[Global`p1, Global`p2] + 3*TBsp[Global`p2, Global`p2])))/
   (TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
     TBsp[Global`p2, Global`p2]))}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
  -((Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] + 
       2*TBsp[Global`p1, Global`p2])^2*(TBsp[Global`p1, Global`p1] - 
       TBsp[Global`p2, Global`p2])^2*(2*TBsp[Global`p1, Global`p2] + 
       TBsp[Global`p2, Global`p2])^2)/(TBsp[Global`p1, Global`p1]*
     TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2]))), 0}, 
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (-4*Global`Nc*(-1 + Global`Nc^2)*
    (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2])^2*
    (-TBsp[Global`p1, Global`p2]^2 + TBsp[Global`p1, Global`p1]*
      TBsp[Global`p2, Global`p2])*(-2*TBsp[Global`p1, Global`p2]^2 + 
     TBsp[Global`p1, Global`p1]*(TBsp[Global`p1, Global`p2] + 
       3*TBsp[Global`p2, Global`p2])))/(TBsp[Global`p1, Global`p1]*
    TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
     2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])), 0, 
  -((Global`Nc*(-1 + Global`Nc^2)*(TBsp[Global`p1, Global`p1] + 
       2*TBsp[Global`p1, Global`p2])^2*
     ((TBsp[Global`p1, Global`p1] - 2*TBsp[Global`p1, Global`p2])^2*
       TBsp[Global`p1, Global`p2]^2 + 2*TBsp[Global`p1, Global`p1]*
       (TBsp[Global`p1, Global`p1] - TBsp[Global`p1, Global`p2])*
       (TBsp[Global`p1, Global`p1] + 6*TBsp[Global`p1, Global`p2])*
       TBsp[Global`p2, Global`p2] + 11*TBsp[Global`p1, Global`p1]^2*
       TBsp[Global`p2, Global`p2]^2))/(TBsp[Global`p1, Global`p1]*
     TBsp[Global`p2, Global`p2]*(TBsp[Global`p1, Global`p1] + 
      2*TBsp[Global`p1, Global`p2] + TBsp[Global`p2, Global`p2])))}}
