(* Created with the Wolfram Language : www.wolfram.com *)
{((-1/4*I)*TBF[Global`color, Global`a1, Global`a2, Global`a3]*
   TBsp[Global`p1, Global`p1]*TBsp[Global`p2, Global`p2]*
   (TBsp[Global`p1, Global`p1] + 2*TBsp[Global`p1, Global`p2] + 
    TBsp[Global`p2, Global`p2])*
   (TBdeltaLorentz[Global`nui$2095, Global`rhoi$2098]*
     (TBvec[Global`p1, Global`mui$2092] + 
      2*TBvec[Global`p2, Global`mui$2092]) - 
    TBdeltaLorentz[Global`mui$2092, Global`rhoi$2098]*
     (2*TBvec[Global`p1, Global`nui$2095] + TBvec[Global`p2, 
       Global`nui$2095]) + TBdeltaLorentz[Global`mui$2092, Global`nui$2095]*
     (TBvec[Global`p1, Global`rhoi$2098] - TBvec[Global`p2, 
       Global`rhoi$2098]))*Global`transProj[Global`p1, Global`mu, 
    Global`mui$2092]*Global`transProj[-Global`p1 - Global`p2, Global`rho, 
    Global`rhoi$2098]*Global`transProj[Global`p2, Global`nu, 
    Global`nui$2095])/(Global`Nc*(-1 + Global`Nc^2)*
   (TBsp[Global`p1, Global`p2]^2 - TBsp[Global`p1, Global`p1]*
     TBsp[Global`p2, Global`p2])*(3*TBsp[Global`p1, Global`p1]^2 + 
    TBsp[Global`p1, Global`p2]^2 + 6*TBsp[Global`p1, Global`p2]*
     TBsp[Global`p2, Global`p2] + 3*TBsp[Global`p2, Global`p2]^2 + 
    TBsp[Global`p1, Global`p1]*(6*TBsp[Global`p1, Global`p2] + 
      8*TBsp[Global`p2, Global`p2])))}
